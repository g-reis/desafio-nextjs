"use strict";
self["webpackHotUpdate_N_E"]("pages/data",{

/***/ "./pages/data.js":
/*!***********************!*\
  !*** ./pages/data.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Data; }
/* harmony export */ });
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-cookie */ "./node_modules/react-cookie/es6/index.js");
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-phone-number-input/input */ "./node_modules/react-phone-number-input/input/index.js");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-phone-number-input/style.css */ "./node_modules/react-phone-number-input/style.css");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\data.js",
    _s = $RefreshSig$();










var __N_SSP = true;
function Data(_ref) {
  _s();

  var _this = this;

  var users = _ref.users,
      user = _ref.user,
      tels = _ref.tels,
      token = _ref.token;
  var router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();

  var _useCookies = (0,react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies)(["user"]),
      _useCookies2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__.default)(_useCookies, 3),
      cookie = _useCookies2[0],
      setCookie = _useCookies2[1],
      removeCookie = _useCookies2[2];

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewUser = _useState[0],
      setShowModalNewUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewPhone = _useState2[0],
      setShowModalNewPhone = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      invalidPassword = _useState3[0],
      setInvalidPassword = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalEditUser = _useState4[0],
      setShowModalEditUser = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalEditPhone = _useState5[0],
      setShowModalEditPhone = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(users),
      localUsers = _useState6[0],
      setLocalUsers = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(tels),
      localTels = _useState7[0],
      setLocalTels = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phone = _useState8[0],
      setPhone = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      userToEdit = _useState9[0],
      setUserToEdit = _useState9[1];

  var _useState10 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phoneToEdit = _useState10[0],
      setPhoneToEdit = _useState10[1];

  var onClickSair = /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(event) {
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              console.log("Sair");
              removeCookie("user");
              router.push('/');

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onClickSair(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  function reloadTels() {
    return _reloadTels.apply(this, arguments);
  }

  function _reloadTels() {
    _reloadTels = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee6() {
      var resTel;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee6$(_context6) {
        while (1) {
          switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return fetch('http://localhost:1337/user-data?users_permissions_user.id=' + user.userid, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              resTel = _context6.sent;
              _context6.t0 = setLocalTels;
              _context6.next = 6;
              return resTel.json();

            case 6:
              _context6.t1 = _context6.sent;
              (0, _context6.t0)(_context6.t1);

            case 8:
            case "end":
              return _context6.stop();
          }
        }
      }, _callee6);
    }));
    return _reloadTels.apply(this, arguments);
  }

  function reloadUsers() {
    return _reloadUsers.apply(this, arguments);
  }

  function _reloadUsers() {
    _reloadUsers = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee7() {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee7$(_context7) {
        while (1) {
          switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return fetch('http://localhost:1337/users', {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              res = _context7.sent;

              if (!(res.status == 200)) {
                _context7.next = 9;
                break;
              }

              _context7.t0 = setLocalUsers;
              _context7.next = 7;
              return res.json();

            case 7:
              _context7.t1 = _context7.sent;
              (0, _context7.t0)(_context7.t1);

            case 9:
            case "end":
              return _context7.stop();
          }
        }
      }, _callee7);
    }));
    return _reloadUsers.apply(this, arguments);
  }

  var editPhone = /*#__PURE__*/function () {
    var _ref3 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              event.preventDefault();
              _context2.next = 3;
              return fetch('http://localhost:1337/user-data/' + event.target.phoneIdHidden.value, {
                body: JSON.stringify({
                  password: event.target.password.value
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'PUT'
              });

            case 3:
              res = _context2.sent;

              if (res.status == 200) {
                setShowModalEditUser(false);
                reloadTels();
              }

            case 5:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function editPhone(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var addNewPhone = /*#__PURE__*/function () {
    var _ref4 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              event.preventDefault();
              console.log(event.target.phone);
              _context3.next = 4;
              return fetch('http://localhost:1337/user-data', {
                body: JSON.stringify({
                  nome: event.target.name.value,
                  telefone: event.target.phone.value,
                  users_permissions_user: {
                    id: user.userid
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 4:
              res = _context3.sent;

              if (res.status == 200) {
                reloadTels();
                setShowModalNewPhone(false);
              }

            case 6:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function addNewPhone(_x3) {
      return _ref4.apply(this, arguments);
    };
  }();

  function deletePhone(_x4) {
    return _deletePhone.apply(this, arguments);
  }

  function _deletePhone() {
    _deletePhone = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee8(phoneID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee8$(_context8) {
        while (1) {
          switch (_context8.prev = _context8.next) {
            case 0:
              _context8.next = 2;
              return fetch('http://localhost:1337/user-data/' + phoneID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context8.sent;

              if (res.status == 200) {
                reloadTels();
              }

            case 4:
            case "end":
              return _context8.stop();
          }
        }
      }, _callee8);
    }));
    return _deletePhone.apply(this, arguments);
  }

  var editUser = /*#__PURE__*/function () {
    var _ref5 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              event.preventDefault();
              _context4.next = 3;
              return fetch('http://localhost:1337/users/' + event.target.useridHidden.value, {
                body: JSON.stringify({
                  password: event.target.password.value
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'PUT'
              });

            case 3:
              res = _context4.sent;
              if (res.status == 200) setShowModalEditUser(false);

            case 5:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function editUser(_x5) {
      return _ref5.apply(this, arguments);
    };
  }();

  var addNewUser = /*#__PURE__*/function () {
    var _ref6 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              event.preventDefault();

              if (!(event.target.password.value !== event.target.passwordrepeat.value)) {
                _context5.next = 4;
                break;
              }

              setInvalidPassword(true);
              return _context5.abrupt("return");

            case 4:
              _context5.next = 6;
              return fetch('http://localhost:1337/users', {
                body: JSON.stringify({
                  username: event.target.username.value,
                  email: event.target.email.value,
                  password: event.target.password.value,
                  confirmed: true,
                  blocked: false,
                  role: {
                    id: 1
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 6:
              res = _context5.sent;

              if (res.status == 201) {
                reloadUsers();
                setShowModalNewUser(false);
              }

            case 8:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5);
    }));

    return function addNewUser(_x6) {
      return _ref6.apply(this, arguments);
    };
  }();

  function deleteUser(_x7) {
    return _deleteUser.apply(this, arguments);
  }

  function _deleteUser() {
    _deleteUser = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee9(userID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee9$(_context9) {
        while (1) {
          switch (_context9.prev = _context9.next) {
            case 0:
              _context9.next = 2;
              return fetch('http://localhost:1337/users/' + userID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context9.sent;

              if (res.status == 200) {
                reloadUsers();
              }

            case 4:
            case "end":
              return _context9.stop();
          }
        }
      }, _callee9);
    }));
    return _deleteUser.apply(this, arguments);
  }

  console.log(users);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        children: "Desafio - Area Restrita"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 196,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 195,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex bg-gray-50",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-between w-full flex justfy-between p-3",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
          children: ["Bem vindo, ", user.username, "!!!"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 200,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
          onClick: onClickSair,
          className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
          children: "Sair"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 199,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 198,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex flex-row",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              setUserToEdit({
                username: '',
                email: '',
                id: ''
              });
              setShowModalNewUser(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Usu\xE1rio"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 208,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 207,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome de Usu\xE1rio"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 221,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "E-mail"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 224,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 227,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 230,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 220,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 219,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localUsers.map(function (usr, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                        className: "flex items-center",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "flex-shrink-0 h-10 w-10",
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: "2",
                              d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 245,
                              columnNumber: 65
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 244,
                            columnNumber: 61
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 243,
                          columnNumber: 57
                        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "ml-3",
                          children: usr.username
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 248,
                          columnNumber: 57
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 242,
                        columnNumber: 53
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 241,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.email
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 251,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                        href: "javascript:void(0)",
                        onClick: function onClick() {
                          setUserToEdit(usr);
                          setShowModalEditUser(true);
                        },
                        children: "Editar"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 252,
                        columnNumber: 106
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 252,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.username == user.username ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            return deleteUser(usr.id);
                          },
                          children: "Excluir"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 256,
                          columnNumber: 148
                        }, _this)
                      }, void 0, false)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 256,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 240,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 235,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 218,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 217,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 206,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              setPhoneToEdit({
                telefone: '',
                nome: '',
                id: ''
              });
              setPhone(null);
              setShowModalNewPhone(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Telefone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 271,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 270,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 287,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Telefone"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 290,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 293,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 296,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 286,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 285,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localTels.map(function (tel, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: tel.nome
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 307,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: tel.telefone
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 308,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                        href: "javascript:void(0)",
                        onClick: function onClick() {
                          setPhoneToEdit(tel);
                          setPhone(tel.telefone);
                          setShowModalEditPhone(true);
                        },
                        children: "Editar"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 309,
                        columnNumber: 106
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 309,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                        href: "javascript:void(0)",
                        onClick: function onClick() {
                          return deletePhone(tel.id);
                        },
                        children: "Excluir"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 315,
                        columnNumber: 106
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 315,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 306,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 301,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 284,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 283,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 269,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 13
    }, this), showModalNewUser || showModalEditUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewUser ? 'Novo Usuário' : null, showModalEditUser ? 'Editar Usuário' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 334,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 333,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: showModalNewUser ? addNewUser : editUser,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "username",
                    className: "mb-3 block text-gray-700",
                    children: "Nome de Usu\xE1rio:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 342,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "username",
                    value: userToEdit.username,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome de Usu\xE1rio",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 343,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 341,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "email",
                    className: "mb-3 block text-gray-700",
                    children: "E-mail:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 348,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "email",
                    id: "email",
                    value: userToEdit.email,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "E-mail",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 349,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 347,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "flex flex-row",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "mr-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "password",
                        className: "mb-3 block text-gray-700",
                        children: "Senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 357,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "password",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Senha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 358,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 356,
                      columnNumber: 49
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "ml-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "passwordrepeat",
                        className: "mb-3 block text-gray-700",
                        children: "Repita a senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 363,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "passwordrepeat",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Repita a enha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 364,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 362,
                      columnNumber: 49
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 355,
                    columnNumber: 45
                  }, this), invalidPassword ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "mt-1 text-red-400",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                      href: "#",
                      children: "As senhas digitadas s\xE3o diferentes"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 371,
                      columnNumber: 53
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 370,
                    columnNumber: 49
                  }, this) : null]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 354,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                  type: "hidden",
                  id: "useridHidden",
                  value: userToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 374,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      setShowModalNewUser(false);
                      setShowModalEditUser(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 376,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    type: "submit",
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 380,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 375,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 340,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 339,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 332,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 331,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 330,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 387,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null, showModalNewPhone || showModalEditPhone ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewPhone ? 'Novo Telefone' : null, showModalEditPhone ? 'Editar Telefone' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 398,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 397,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: showModalNewPhone ? addNewPhone : editPhone,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "name",
                    className: "mb-3 block text-gray-700",
                    children: "Nome:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 406,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "name",
                    value: phoneToEdit.nome,
                    onChange: phoneToEdit.nome,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 407,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 405,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "phone",
                    className: "mb-3 block text-gray-700",
                    children: "Telefone:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 412,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__.default, {
                    id: "phone",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Telefone",
                    value: phone,
                    country: "BR",
                    onChange: setPhone
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 413,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 411,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                  type: "hidden",
                  id: "phoneIdHidden",
                  value: phoneToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 419,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      setShowModalNewPhone(false);
                      setShowModalEditPhone(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 421,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 425,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 420,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 404,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 403,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 396,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 395,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 394,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 432,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null]
  }, void 0, true);
}

_s(Data, "B6/YLcTC4jCMCb1WxjnN03pgVmY=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter, react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies];
});

_c = Data;

var _c;

$RefreshReg$(_c, "Data");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZGF0YS43ZThjNzdmNmZhZjJkOGQ2N2Y0YS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBRWUsU0FBU0ssSUFBVCxPQUE0QztBQUFBOztBQUFBOztBQUFBLE1BQTVCQyxLQUE0QixRQUE1QkEsS0FBNEI7QUFBQSxNQUFyQkMsSUFBcUIsUUFBckJBLElBQXFCO0FBQUEsTUFBZkMsSUFBZSxRQUFmQSxJQUFlO0FBQUEsTUFBVEMsS0FBUyxRQUFUQSxLQUFTO0FBQ3ZELE1BQU1DLE1BQU0sR0FBR1Isc0RBQVMsRUFBeEI7O0FBRUEsb0JBQTBDQyx3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXBEO0FBQUE7QUFBQSxNQUFPUSxNQUFQO0FBQUEsTUFBZUMsU0FBZjtBQUFBLE1BQTBCQyxZQUExQjs7QUFDQSxrQkFBZ0RaLCtDQUFRLENBQUMsS0FBRCxDQUF4RDtBQUFBLE1BQU9hLGdCQUFQO0FBQUEsTUFBeUJDLG1CQUF6Qjs7QUFDQSxtQkFBa0RkLCtDQUFRLENBQUMsS0FBRCxDQUExRDtBQUFBLE1BQU9lLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBOENoQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEQ7QUFBQSxNQUFPaUIsZUFBUDtBQUFBLE1BQXdCQyxrQkFBeEI7O0FBQ0EsbUJBQWtEbEIsK0NBQVEsQ0FBQyxLQUFELENBQTFEO0FBQUEsTUFBT21CLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBb0RwQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBNUQ7QUFBQSxNQUFPcUIsa0JBQVA7QUFBQSxNQUEyQkMscUJBQTNCOztBQUNBLG1CQUFvQ3RCLCtDQUFRLENBQUNLLEtBQUQsQ0FBNUM7QUFBQSxNQUFPa0IsVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBa0N4QiwrQ0FBUSxDQUFDTyxJQUFELENBQTFDO0FBQUEsTUFBT2tCLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQTBCMUIsK0NBQVEsRUFBbEM7QUFBQSxNQUFPMkIsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsbUJBQW9DNUIsK0NBQVEsRUFBNUM7QUFBQSxNQUFPNkIsVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxvQkFBc0M5QiwrQ0FBUSxFQUE5QztBQUFBLE1BQU8rQixXQUFQO0FBQUEsTUFBb0JDLGNBQXBCOztBQUVBLE1BQU1DLFdBQVc7QUFBQSxzWEFBRyxpQkFBTUMsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2hCQyxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0F4QixjQUFBQSxZQUFZLENBQUMsTUFBRCxDQUFaO0FBQ0FILGNBQUFBLE1BQU0sQ0FBQzRCLElBQVAsQ0FBWSxHQUFaOztBQUhnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYSixXQUFXO0FBQUE7QUFBQTtBQUFBLEtBQWpCOztBQWZ1RCxXQXFCeENLLFVBckJ3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx3WEFxQnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ3lCQyxLQUFLLENBQ3RCLCtEQUErRGpDLElBQUksQ0FBQ2tDLE1BRDlDLEVBRXRCO0FBQ0lDLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBSUlrQyxnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGc0IsQ0FEOUI7O0FBQUE7QUFDVUMsY0FBQUEsTUFEVjtBQUFBLDZCQVdJakIsWUFYSjtBQUFBO0FBQUEscUJBV3VCaUIsTUFBTSxDQUFDQyxJQUFQLEVBWHZCOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQXJCdUQ7QUFBQTtBQUFBOztBQUFBLFdBbUN4Q0MsV0FuQ3dDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQW1DdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JOLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0lFLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBSUlrQyxnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFBQSxvQkFVUUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FWdEI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsNkJBV1F2QixhQVhSO0FBQUE7QUFBQSxxQkFXNEJzQixHQUFHLENBQUNGLElBQUosRUFYNUI7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBbkN1RDtBQUFBO0FBQUE7O0FBbUR2RCxNQUFNSSxTQUFTO0FBQUEsc1hBQUcsa0JBQU1kLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2RBLGNBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQURjO0FBQUEscUJBRUlWLEtBQUssQ0FDbkIscUNBQXFDTCxLQUFLLENBQUNnQixNQUFOLENBQWFDLGFBQWIsQ0FBMkJDLEtBRDdDLEVBRW5CO0FBQ0lDLGdCQUFBQSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2pCQyxrQkFBQUEsUUFBUSxFQUFFdEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFhTSxRQUFiLENBQXNCSjtBQURmLGlCQUFmLENBRFY7QUFJSVgsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLGtDQUFnQixrQkFEWDtBQUVMLG1DQUFpQixZQUFZakM7QUFGeEIsaUJBSmI7QUFRSWtDLGdCQUFBQSxNQUFNLEVBQUU7QUFSWixlQUZtQixDQUZUOztBQUFBO0FBRVJJLGNBQUFBLEdBRlE7O0FBZWQsa0JBQUlBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CM0IsZ0JBQUFBLG9CQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQWtCLGdCQUFBQSxVQUFVO0FBQ2I7O0FBbEJhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVRVLFNBQVM7QUFBQTtBQUFBO0FBQUEsS0FBZjs7QUFzQkEsTUFBTVMsV0FBVztBQUFBLHNYQUFHLGtCQUFNdkIsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEJBLGNBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQUNBZCxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsS0FBSyxDQUFDZ0IsTUFBTixDQUFhdkIsS0FBekI7QUFGZ0I7QUFBQSxxQkFHRVksS0FBSyxDQUNuQixpQ0FEbUIsRUFFbkI7QUFDSWMsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJHLGtCQUFBQSxJQUFJLEVBQUV4QixLQUFLLENBQUNnQixNQUFOLENBQWFTLElBQWIsQ0FBa0JQLEtBRFA7QUFFakJRLGtCQUFBQSxRQUFRLEVBQUUxQixLQUFLLENBQUNnQixNQUFOLENBQWF2QixLQUFiLENBQW1CeUIsS0FGWjtBQUdqQlMsa0JBQUFBLHNCQUFzQixFQUFFO0FBQ3BCQyxvQkFBQUEsRUFBRSxFQUFFeEQsSUFBSSxDQUFDa0M7QUFEVztBQUhQLGlCQUFmLENBRFY7QUFRSUMsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLGtDQUFnQixrQkFEWDtBQUVMLG1DQUFpQixZQUFZakM7QUFGeEIsaUJBUmI7QUFhSWtDLGdCQUFBQSxNQUFNLEVBQUU7QUFiWixlQUZtQixDQUhQOztBQUFBO0FBR1ZJLGNBQUFBLEdBSFU7O0FBcUJoQixrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ1Z0QixnQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNIOztBQXhCZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYeUMsV0FBVztBQUFBO0FBQUE7QUFBQSxLQUFqQjs7QUF6RXVELFdBb0d4Q00sV0FwR3dDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQW9HdkQsa0JBQTJCQyxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNzQnpCLEtBQUssQ0FDbkIscUNBQXFDeUIsT0FEbEIsRUFFbkI7QUFDSXZCLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBS0lrQyxnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ2I7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FwR3VEO0FBQUE7QUFBQTs7QUFxSHZELE1BQU0yQixRQUFRO0FBQUEsc1hBQUcsa0JBQU0vQixLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNiQSxjQUFBQSxLQUFLLENBQUNlLGNBQU47QUFEYTtBQUFBLHFCQUVLVixLQUFLLENBQ25CLGlDQUFpQ0wsS0FBSyxDQUFDZ0IsTUFBTixDQUFhZ0IsWUFBYixDQUEwQmQsS0FEeEMsRUFFbkI7QUFDSUMsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJDLGtCQUFBQSxRQUFRLEVBQUV0QixLQUFLLENBQUNnQixNQUFOLENBQWFNLFFBQWIsQ0FBc0JKO0FBRGYsaUJBQWYsQ0FEVjtBQUlJWCxnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVlqQztBQUZ4QixpQkFKYjtBQVFJa0MsZ0JBQUFBLE1BQU0sRUFBRTtBQVJaLGVBRm1CLENBRlY7O0FBQUE7QUFFUEksY0FBQUEsR0FGTztBQWViLGtCQUFJQSxHQUFHLENBQUNDLE1BQUosSUFBYyxHQUFsQixFQUNJM0Isb0JBQW9CLENBQUMsS0FBRCxDQUFwQjs7QUFoQlM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBUjZDLFFBQVE7QUFBQTtBQUFBO0FBQUEsS0FBZDs7QUFtQkEsTUFBTUUsVUFBVTtBQUFBLHNYQUFHLGtCQUFNakMsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDZkEsY0FBQUEsS0FBSyxDQUFDZSxjQUFOOztBQURlLG9CQUVYZixLQUFLLENBQUNnQixNQUFOLENBQWFNLFFBQWIsQ0FBc0JKLEtBQXRCLEtBQWdDbEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFha0IsY0FBYixDQUE0QmhCLEtBRmpEO0FBQUE7QUFBQTtBQUFBOztBQUdYbEMsY0FBQUEsa0JBQWtCLENBQUMsSUFBRCxDQUFsQjtBQUhXOztBQUFBO0FBQUE7QUFBQSxxQkFNR3FCLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0ljLGdCQUFBQSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2pCYyxrQkFBQUEsUUFBUSxFQUFFbkMsS0FBSyxDQUFDZ0IsTUFBTixDQUFhbUIsUUFBYixDQUFzQmpCLEtBRGY7QUFFakJrQixrQkFBQUEsS0FBSyxFQUFFcEMsS0FBSyxDQUFDZ0IsTUFBTixDQUFhb0IsS0FBYixDQUFtQmxCLEtBRlQ7QUFHakJJLGtCQUFBQSxRQUFRLEVBQUV0QixLQUFLLENBQUNnQixNQUFOLENBQWFNLFFBQWIsQ0FBc0JKLEtBSGY7QUFJakJtQixrQkFBQUEsU0FBUyxFQUFFLElBSk07QUFLakJDLGtCQUFBQSxPQUFPLEVBQUUsS0FMUTtBQU1qQkMsa0JBQUFBLElBQUksRUFBRTtBQUFFWCxvQkFBQUEsRUFBRSxFQUFFO0FBQU47QUFOVyxpQkFBZixDQURWO0FBU0lyQixnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVlqQztBQUZ4QixpQkFUYjtBQWNJa0MsZ0JBQUFBLE1BQU0sRUFBRTtBQWRaLGVBRm1CLENBTlI7O0FBQUE7QUFNVEksY0FBQUEsR0FOUzs7QUF5QmYsa0JBQUlBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CRixnQkFBQUEsV0FBVztBQUNYL0IsZ0JBQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDSDs7QUE1QmM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBVnFELFVBQVU7QUFBQTtBQUFBO0FBQUEsS0FBaEI7O0FBeEl1RCxXQXVLeENPLFVBdkt3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx3WEF1S3ZELGtCQUEwQkMsTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JwQyxLQUFLLENBQ25CLGlDQUFpQ29DLE1BRGQsRUFFbkI7QUFDSWxDLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBS0lrQyxnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJGLGdCQUFBQSxXQUFXO0FBQ2Q7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0F2S3VEO0FBQUE7QUFBQTs7QUF3THZEVixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWS9CLEtBQVo7QUFDQSxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGtEQUFEO0FBQUEsNkJBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFJSTtBQUFLLGVBQVMsRUFBQyxpQkFBZjtBQUFBLDZCQUNJO0FBQUssaUJBQVMsRUFBQyxnREFBZjtBQUFBLGdDQUNJO0FBQUEsb0NBQWtCQyxJQUFJLENBQUMrRCxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFFSTtBQUFRLGlCQUFPLEVBQUVwQyxXQUFqQjtBQUE4QixtQkFBUyxFQUFDLHdEQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkosZUFXSTtBQUFLLGVBQVMsRUFBQyxlQUFmO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsS0FBZjtBQUFBLGlDQUNJO0FBQVEsbUJBQU8sRUFBRSxtQkFBTTtBQUNuQkgsY0FBQUEsYUFBYSxDQUFDO0FBQ1Z1QyxnQkFBQUEsUUFBUSxFQUFFLEVBREE7QUFFVkMsZ0JBQUFBLEtBQUssRUFBRSxFQUZHO0FBR1ZSLGdCQUFBQSxFQUFFLEVBQUU7QUFITSxlQUFELENBQWI7QUFLQWhELGNBQUFBLG1CQUFtQixDQUFDLElBQUQsQ0FBbkI7QUFDSCxhQVBEO0FBT0cscUJBQVMsRUFBQyx3REFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFXSTtBQUFLLG1CQUFTLEVBQUMsK0NBQWY7QUFBQSxpQ0FDSTtBQUFPLHFCQUFTLEVBQUMscUNBQWpCO0FBQUEsb0NBQ0k7QUFBTyx1QkFBUyxFQUFDLFlBQWpCO0FBQUEscUNBQ0k7QUFBQSx3Q0FDSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESixlQUlJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQUpKLGVBT0k7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBKLGVBVUk7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFpQkk7QUFBTyx1QkFBUyxFQUFDLG1DQUFqQjtBQUFBLHdCQUdRUyxVQUFVLENBQUNxRCxHQUFYLENBQWUsVUFBQ0MsR0FBRCxFQUFNQyxLQUFOO0FBQUEsb0NBQ1g7QUFBQSx5Q0FDSTtBQUFBLDRDQUNJO0FBQUksK0JBQVMsRUFBQyw2QkFBZDtBQUFBLDZDQUNJO0FBQUssaUNBQVMsRUFBQyxtQkFBZjtBQUFBLGdEQUNJO0FBQUssbUNBQVMsRUFBQyx5QkFBZjtBQUFBLGlEQUNJO0FBQUssaUNBQUssRUFBQyw0QkFBWDtBQUF3QyxnQ0FBSSxFQUFDLE1BQTdDO0FBQW9ELG1DQUFPLEVBQUMsV0FBNUQ7QUFBd0Usa0NBQU0sRUFBQyxjQUEvRTtBQUFBLG1EQUNJO0FBQU0sMkNBQWEsRUFBQyxPQUFwQjtBQUE0Qiw0Q0FBYyxFQUFDLE9BQTNDO0FBQW1ELHlDQUFXLEVBQUMsR0FBL0Q7QUFBbUUsK0JBQUMsRUFBQztBQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREosZUFNSTtBQUFLLG1DQUFTLEVBQUMsTUFBZjtBQUFBLG9DQUF1QkQsR0FBRyxDQUFDUjtBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFXSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSxnQ0FBMERRLEdBQUcsQ0FBQ1A7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFYSixlQVlJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBLDZDQUF5RDtBQUFHLDRCQUFJLEVBQUMsb0JBQVI7QUFBNkIsK0JBQU8sRUFBRSxtQkFBTTtBQUNqR3hDLDBCQUFBQSxhQUFhLENBQUMrQyxHQUFELENBQWI7QUFDQXpELDBCQUFBQSxvQkFBb0IsQ0FBQyxJQUFELENBQXBCO0FBQ0gseUJBSHdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBWkosZUFnQkk7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsZ0NBQTBEeUQsR0FBRyxDQUFDUixRQUFKLElBQWdCL0QsSUFBSSxDQUFDK0QsUUFBckIsR0FBZ0MsSUFBaEMsZ0JBQXVDO0FBQUEsK0NBQUU7QUFBRyw4QkFBSSxFQUFDLG9CQUFSO0FBQTZCLGlDQUFPLEVBQUU7QUFBQSxtQ0FBTUssVUFBVSxDQUFDRyxHQUFHLENBQUNmLEVBQUwsQ0FBaEI7QUFBQSwyQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBRjtBQUFqRztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWhCSjtBQUFBLHFCQUFRLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlDQURXO0FBQUEsZUFBZjtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUFnRUk7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsS0FBZjtBQUFBLGlDQUNJO0FBQVEsbUJBQU8sRUFDWCxtQkFBTTtBQUNGOUIsY0FBQUEsY0FBYyxDQUFDO0FBQ1g0QixnQkFBQUEsUUFBUSxFQUFFLEVBREM7QUFFWEYsZ0JBQUFBLElBQUksRUFBRSxFQUZLO0FBR1hJLGdCQUFBQSxFQUFFLEVBQUU7QUFITyxlQUFELENBQWQ7QUFLQWxDLGNBQUFBLFFBQVEsQ0FBQyxJQUFELENBQVI7QUFDQVosY0FBQUEsb0JBQW9CLENBQUMsSUFBRCxDQUFwQjtBQUNILGFBVEw7QUFVRSxxQkFBUyxFQUFDLHdEQVZaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQWNJO0FBQUssbUJBQVMsRUFBQywrQ0FBZjtBQUFBLGlDQUNJO0FBQU8scUJBQVMsRUFBQyxxQ0FBakI7QUFBQSxvQ0FDSTtBQUFPLHVCQUFTLEVBQUMsWUFBakI7QUFBQSxxQ0FDSTtBQUFBLHdDQUNJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURKLGVBSUk7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSkosZUFPSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFVSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQWlCSTtBQUFPLHVCQUFTLEVBQUMsbUNBQWpCO0FBQUEsd0JBR1FTLFNBQVMsQ0FBQ21ELEdBQVYsQ0FBYyxVQUFDRyxHQUFELEVBQU1ELEtBQU47QUFBQSxvQ0FDVjtBQUFBLHlDQUNJO0FBQUEsNENBQ0k7QUFBSSwrQkFBUyxFQUFDLDZCQUFkO0FBQUEsZ0NBQTZDQyxHQUFHLENBQUNyQjtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBRUk7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsZ0NBQTBEcUIsR0FBRyxDQUFDbkI7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGSixlQUdJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBLDZDQUF5RDtBQUFHLDRCQUFJLEVBQUMsb0JBQVI7QUFBNkIsK0JBQU8sRUFBRSxtQkFBTTtBQUNqRzVCLDBCQUFBQSxjQUFjLENBQUMrQyxHQUFELENBQWQ7QUFDQW5ELDBCQUFBQSxRQUFRLENBQUNtRCxHQUFHLENBQUNuQixRQUFMLENBQVI7QUFDQXRDLDBCQUFBQSxxQkFBcUIsQ0FBQyxJQUFELENBQXJCO0FBQ0gseUJBSndEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSEosZUFTSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSw2Q0FBeUQ7QUFBRyw0QkFBSSxFQUFDLG9CQUFSO0FBQTZCLCtCQUFPLEVBQUU7QUFBQSxpQ0FBTXlDLFdBQVcsQ0FBQ2dCLEdBQUcsQ0FBQ2pCLEVBQUwsQ0FBakI7QUFBQSx5QkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFUSjtBQUFBLHFCQUFRLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlDQURVO0FBQUEsZUFBZDtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBaEVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVhKLEVBc0lLakQsZ0JBQWdCLElBQUlNLGlCQUFwQixnQkFDRztBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyx1SEFBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyx3Q0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxzR0FBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQywwRkFBZjtBQUFBLHFDQUNJO0FBQU0seUJBQVMsRUFBQyxlQUFoQjtBQUFBLDJCQUNLTixnQkFBZ0IsR0FBRyxjQUFILEdBQW9CLElBRHpDLEVBRUtNLGlCQUFpQixHQUFHLGdCQUFILEdBQXNCLElBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFPSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSxxQ0FDSTtBQUFNLHdCQUFRLEVBQUVOLGdCQUFnQixHQUFHc0QsVUFBSCxHQUFnQkYsUUFBaEQ7QUFBQSx3Q0FDSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQU8sMkJBQU8sRUFBQyxVQUFmO0FBQTBCLDZCQUFTLEVBQUMsMEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBRUk7QUFBTyx3QkFBSSxFQUFDLE1BQVo7QUFBbUIsc0JBQUUsRUFBQyxVQUF0QjtBQUFpQyx5QkFBSyxFQUFFcEMsVUFBVSxDQUFDd0MsUUFBbkQ7QUFBNkQsNEJBQVEsRUFBRXZDLGFBQXZFO0FBQ0ksNkJBQVMsRUFBQywwRUFEZDtBQUVJLCtCQUFXLEVBQUMsb0JBRmhCO0FBRWtDLDRCQUFRLEVBQUUsQ0FBQ1gsaUJBRjdDO0FBRWdFLDRCQUFRLEVBQUVBO0FBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURKLGVBT0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsT0FBZjtBQUF1Qiw2QkFBUyxFQUFDLDBCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxPQUFaO0FBQW9CLHNCQUFFLEVBQUMsT0FBdkI7QUFBK0IseUJBQUssRUFBRVUsVUFBVSxDQUFDeUMsS0FBakQ7QUFBd0QsNEJBQVEsRUFBRXhDLGFBQWxFO0FBQ0ksNkJBQVMsRUFBQywwRUFEZDtBQUVJLCtCQUFXLEVBQUMsUUFGaEI7QUFFeUIsNEJBQVEsRUFBRSxDQUFDWCxpQkFGcEM7QUFFdUQsNEJBQVEsRUFBRUE7QUFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFjSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQUssNkJBQVMsRUFBQyxlQUFmO0FBQUEsNENBQ0k7QUFBSywrQkFBUyxFQUFDLE1BQWY7QUFBQSw4Q0FDSTtBQUFPLCtCQUFPLEVBQUMsVUFBZjtBQUEwQixpQ0FBUyxFQUFDLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFESixlQUVJO0FBQU8sNEJBQUksRUFBQyxVQUFaO0FBQXVCLDBCQUFFLEVBQUMsVUFBMUI7QUFDSSxpQ0FBUyxFQUFDLDBFQURkO0FBRUksbUNBQVcsRUFBQyxPQUZoQjtBQUV3QixnQ0FBUTtBQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFESixlQU9JO0FBQUssK0JBQVMsRUFBQyxNQUFmO0FBQUEsOENBQ0k7QUFBTywrQkFBTyxFQUFDLGdCQUFmO0FBQWdDLGlDQUFTLEVBQUMsMEJBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURKLGVBRUk7QUFBTyw0QkFBSSxFQUFDLFVBQVo7QUFBdUIsMEJBQUUsRUFBQyxnQkFBMUI7QUFDSSxpQ0FBUyxFQUFDLDBFQURkO0FBRUksbUNBQVcsRUFBQyxlQUZoQjtBQUVnQyxnQ0FBUTtBQUZ4QztBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosRUFlS0YsZUFBZSxnQkFDWjtBQUFLLDZCQUFTLEVBQUMsbUJBQWY7QUFBQSwyQ0FDSTtBQUFHLDBCQUFJLEVBQUMsR0FBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRFksR0FHSCxJQWxCakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWRKLGVBa0NJO0FBQU8sc0JBQUksRUFBQyxRQUFaO0FBQXFCLG9CQUFFLEVBQUMsY0FBeEI7QUFBdUMsdUJBQUssRUFBRVksVUFBVSxDQUFDaUM7QUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQ0osZUFtQ0k7QUFBSywyQkFBUyxFQUFDLHdGQUFmO0FBQUEsMENBQ0k7QUFBUSwyQkFBTyxFQUFFLG1CQUFNO0FBQ25CaEQsc0JBQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDQU0sc0JBQUFBLG9CQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDSCxxQkFIRDtBQUdHLDZCQUFTLEVBQUMsMkRBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFLSTtBQUFRLHdCQUFJLEVBQUMsUUFBYjtBQUFzQiw2QkFBUyxFQUFDLHdEQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQTBESTtBQUFLLGlCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBMURKO0FBQUEsb0JBREgsR0E2REcsSUFuTVIsRUFzTUtMLGlCQUFpQixJQUFJTSxrQkFBckIsZ0JBQ0c7QUFBQSw4QkFDSTtBQUFLLGlCQUFTLEVBQUMsdUhBQWY7QUFBQSwrQkFDSTtBQUFLLG1CQUFTLEVBQUMsd0NBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsc0dBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsMEZBQWY7QUFBQSxxQ0FDSTtBQUFNLHlCQUFTLEVBQUMsZUFBaEI7QUFBQSwyQkFDS04saUJBQWlCLEdBQUcsZUFBSCxHQUFxQixJQUQzQyxFQUVLTSxrQkFBa0IsR0FBRyxpQkFBSCxHQUF1QixJQUY5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBT0k7QUFBSyx1QkFBUyxFQUFDLHdCQUFmO0FBQUEscUNBQ0k7QUFBTSx3QkFBUSxFQUFFTixpQkFBaUIsR0FBRzBDLFdBQUgsR0FBaUJULFNBQWxEO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsTUFBZjtBQUFzQiw2QkFBUyxFQUFDLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsTUFBdEI7QUFBNkIseUJBQUssRUFBRWpCLFdBQVcsQ0FBQzJCLElBQWhEO0FBQXNELDRCQUFRLEVBQUUzQixXQUFXLENBQUMyQixJQUE1RTtBQUNJLDZCQUFTLEVBQUMsMEVBRGQ7QUFFSSwrQkFBVyxFQUFDLE1BRmhCO0FBRXVCLDRCQUFRO0FBRi9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURKLGVBT0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsT0FBZjtBQUF1Qiw2QkFBUyxFQUFDLDBCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJLDhEQUFDLG1FQUFEO0FBQVksc0JBQUUsRUFBQyxPQUFmO0FBQXVCLDZCQUFTLEVBQUMsMEVBQWpDO0FBQ0ksK0JBQVcsRUFBQyxVQURoQjtBQUVJLHlCQUFLLEVBQUUvQixLQUZYO0FBR0ksMkJBQU8sRUFBQyxJQUhaO0FBSUksNEJBQVEsRUFBRUM7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQSixlQWVJO0FBQU8sc0JBQUksRUFBQyxRQUFaO0FBQXFCLG9CQUFFLEVBQUMsZUFBeEI7QUFBd0MsdUJBQUssRUFBRUcsV0FBVyxDQUFDK0I7QUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFmSixlQWdCSTtBQUFLLDJCQUFTLEVBQUMsd0ZBQWY7QUFBQSwwQ0FDSTtBQUFRLDJCQUFPLEVBQUUsbUJBQU07QUFDbkI5QyxzQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNBTSxzQkFBQUEscUJBQXFCLENBQUMsS0FBRCxDQUFyQjtBQUNILHFCQUhEO0FBR0csNkJBQVMsRUFBQywyREFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUtJO0FBQVEsNkJBQVMsRUFBQyx3REFBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUF1Q0k7QUFBSyxpQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQXZDSjtBQUFBLG9CQURILEdBMENHLElBaFBSO0FBQUEsa0JBREo7QUFvUEg7O0dBN2F1QmxCO1VBQ0xILG9EQUUyQkM7OztLQUh0QkUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZGF0YS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgeyB1c2VDb29raWVzIH0gZnJvbSBcInJlYWN0LWNvb2tpZVwiXHJcbmltcG9ydCBQaG9uZUlucHV0IGZyb20gJ3JlYWN0LXBob25lLW51bWJlci1pbnB1dC9pbnB1dCdcclxuaW1wb3J0ICdyZWFjdC1waG9uZS1udW1iZXItaW5wdXQvc3R5bGUuY3NzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGF0YSh7IHVzZXJzLCB1c2VyLCB0ZWxzLCB0b2tlbiB9KSB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAgIGNvbnN0IFtjb29raWUsIHNldENvb2tpZSwgcmVtb3ZlQ29va2llXSA9IHVzZUNvb2tpZXMoW1widXNlclwiXSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxOZXdVc2VyLCBzZXRTaG93TW9kYWxOZXdVc2VyXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbE5ld1Bob25lLCBzZXRTaG93TW9kYWxOZXdQaG9uZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtpbnZhbGlkUGFzc3dvcmQsIHNldEludmFsaWRQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxFZGl0VXNlciwgc2V0U2hvd01vZGFsRWRpdFVzZXJdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbc2hvd01vZGFsRWRpdFBob25lLCBzZXRTaG93TW9kYWxFZGl0UGhvbmVdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbbG9jYWxVc2Vycywgc2V0TG9jYWxVc2Vyc10gPSB1c2VTdGF0ZSh1c2VycylcclxuICAgIGNvbnN0IFtsb2NhbFRlbHMsIHNldExvY2FsVGVsc10gPSB1c2VTdGF0ZSh0ZWxzKVxyXG4gICAgY29uc3QgW3Bob25lLCBzZXRQaG9uZV0gPSB1c2VTdGF0ZSgpXHJcbiAgICBjb25zdCBbdXNlclRvRWRpdCwgc2V0VXNlclRvRWRpdF0gPSB1c2VTdGF0ZSgpO1xyXG4gICAgY29uc3QgW3Bob25lVG9FZGl0LCBzZXRQaG9uZVRvRWRpdF0gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICAgIGNvbnN0IG9uQ2xpY2tTYWlyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiU2FpclwiKVxyXG4gICAgICAgIHJlbW92ZUNvb2tpZShcInVzZXJcIilcclxuICAgICAgICByb3V0ZXIucHVzaCgnLycpXHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcmVsb2FkVGVscygpIHtcclxuICAgICAgICBjb25zdCByZXNUZWwgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGE/dXNlcnNfcGVybWlzc2lvbnNfdXNlci5pZD0nICsgdXNlci51c2VyaWQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICBzZXRMb2NhbFRlbHMoYXdhaXQgcmVzVGVsLmpzb24oKSlcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZWxvYWRVc2VycygpIHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICBzZXRMb2NhbFVzZXJzKGF3YWl0IHJlcy5qc29uKCkpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBlZGl0UGhvbmUgPSBhc3luYyBldmVudCA9PiB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YS8nICsgZXZlbnQudGFyZ2V0LnBob25lSWRIaWRkZW4udmFsdWUsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUFVUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0VXNlcihmYWxzZSlcclxuICAgICAgICAgICAgcmVsb2FkVGVscygpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhZGROZXdQaG9uZSA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgY29uc29sZS5sb2coZXZlbnQudGFyZ2V0LnBob25lKVxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YScsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICBub21lOiBldmVudC50YXJnZXQubmFtZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB0ZWxlZm9uZTogZXZlbnQudGFyZ2V0LnBob25lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJzX3Blcm1pc3Npb25zX3VzZXI6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXIudXNlcmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHJlbG9hZFRlbHMoKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZShmYWxzZSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUGhvbmUocGhvbmVJRCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YS8nICsgcGhvbmVJRCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJ1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVGVscygpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGVkaXRVc2VyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2Vycy8nICsgZXZlbnQudGFyZ2V0LnVzZXJpZEhpZGRlbi52YWx1ZSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQVVQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0VXNlcihmYWxzZSlcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhZGROZXdVc2VyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlICE9PSBldmVudC50YXJnZXQucGFzc3dvcmRyZXBlYXQudmFsdWUpIHtcclxuICAgICAgICAgICAgc2V0SW52YWxpZFBhc3N3b3JkKHRydWUpXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTogZXZlbnQudGFyZ2V0LnVzZXJuYW1lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiBldmVudC50YXJnZXQuZW1haWwudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGV2ZW50LnRhcmdldC5wYXNzd29yZC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBjb25maXJtZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcm9sZTogeyBpZDogMSB9XHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDEpIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKHVzZXJJRCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzLycgKyB1c2VySUQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURSdcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHJlbG9hZFVzZXJzKClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc29sZS5sb2codXNlcnMpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPkRlc2FmaW8gLSBBcmVhIFJlc3RyaXRhPC90aXRsZT5cclxuICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGZsZXgganVzdGZ5LWJldHdlZW4gcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmVtIHZpbmRvLCB7dXNlci51c2VybmFtZX0hISE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrU2Fpcn0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+U2FpcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXNlclRvRWRpdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcm5hbWU6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogJydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPk5vdm8gVXN1w6FyaW88L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNSBib3JkZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWUgZGUgVXN1w6FyaW9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFLW1haWxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGJvZHkgY2xhc3NOYW1lPVwiYmctd2hpdGUgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxVc2Vycy5tYXAoKHVzciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT1cInsgaW5kZXggfVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LXNocmluay0wIGgtMTAgdy0xMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZUxpbmVjYXA9XCJyb3VuZFwiIHN0cm9rZUxpbmVqb2luPVwicm91bmRcIiBzdHJva2VXaWR0aD1cIjJcIiBkPVwiTTE2IDdhNCA0IDAgMTEtOCAwIDQgNCAwIDAxOCAwek0xMiAxNGE3IDcgMCAwMC03IDdoMTRhNyA3IDAgMDAtNy03elwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWwtM1wiPnt1c3IudXNlcm5hbWV9PC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj57dXNyLmVtYWlsfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+PGEgaHJlZj0namF2YXNjcmlwdDp2b2lkKDApJyBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVc2VyVG9FZGl0KHVzcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRVc2VyKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PkVkaXRhcjwvYT48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt1c3IudXNlcm5hbWUgPT0gdXNlci51c2VybmFtZSA/IG51bGwgOiA8PjxhIGhyZWY9J2phdmFzY3JpcHQ6dm9pZCgwKScgb25DbGljaz17KCkgPT4gZGVsZXRlVXNlcih1c3IuaWQpfT5FeGNsdWlyPC9hPjwvPn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuXHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBob25lVG9FZGl0KHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGVsZWZvbmU6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub21lOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZShudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1Bob25lKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+Tm92byBUZWxlZm9uZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01IGJvcmRlciBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9tZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFRlbGVmb25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsVGVscy5tYXAoKHRlbCwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyIGtleT1cInsgaW5kZXggfVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+e3RlbC5ub21lfTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3RlbC50ZWxlZm9uZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPjxhIGhyZWY9J2phdmFzY3JpcHQ6dm9pZCgwKScgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGhvbmVUb0VkaXQodGVsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGhvbmUodGVsLnRlbGVmb25lKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFBob25lKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfT5FZGl0YXI8L2E+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPSdqYXZhc2NyaXB0OnZvaWQoMCknIG9uQ2xpY2s9eygpID0+IGRlbGV0ZVBob25lKHRlbC5pZCl9PkV4Y2x1aXI8L2E+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGJvZHk+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTW9kYWwgTmV3VXNlciAqL31cclxuICAgICAgICAgICAge3Nob3dNb2RhbE5ld1VzZXIgfHwgc2hvd01vZGFsRWRpdFVzZXIgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwianVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGZsZXggb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIGZpeGVkIGluc2V0LTAgei01MCBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1hdXRvIG15LTIgbXgtYXV0byBtYXgtdy0zeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCB3LWZ1bGwgYmctd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcC01IGJvcmRlci1iIGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsTmV3VXNlciA/ICdOb3ZvIFVzdcOhcmlvJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsRWRpdFVzZXIgPyAnRWRpdGFyIFVzdcOhcmlvJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiBmbGV4LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3Nob3dNb2RhbE5ld1VzZXIgPyBhZGROZXdVc2VyIDogZWRpdFVzZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJ1c2VybmFtZVwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPk5vbWUgZGUgVXN1w6FyaW86PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cInVzZXJuYW1lXCIgdmFsdWU9e3VzZXJUb0VkaXQudXNlcm5hbWV9IG9uQ2hhbmdlPXtzZXRVc2VyVG9FZGl0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZGUgVXN1w6FyaW9cIiByZXF1aXJlZD17IXNob3dNb2RhbEVkaXRVc2VyfSBkaXNhYmxlZD17c2hvd01vZGFsRWRpdFVzZXJ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiZW1haWxcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5FLW1haWw6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cImVtYWlsXCIgaWQ9XCJlbWFpbFwiIHZhbHVlPXt1c2VyVG9FZGl0LmVtYWlsfSBvbkNoYW5nZT17c2V0VXNlclRvRWRpdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJFLW1haWxcIiByZXF1aXJlZD17IXNob3dNb2RhbEVkaXRVc2VyfSBkaXNhYmxlZD17c2hvd01vZGFsRWRpdFVzZXJ9IC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbWItNic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtci0yJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5TZW5oYTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZW5oYVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbWwtMic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkcmVwZWF0XCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+UmVwaXRhIGEgc2VuaGE6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBpZD1cInBhc3N3b3JkcmVwZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmVwaXRhIGEgZW5oYVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnZhbGlkUGFzc3dvcmQgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1yZWQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiPkFzIHNlbmhhcyBkaWdpdGFkYXMgc8OjbyBkaWZlcmVudGVzPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT0naGlkZGVuJyBpZD0ndXNlcmlkSGlkZGVuJyB2YWx1ZT17dXNlclRvRWRpdC5pZH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdCBib3JkZXItc29saWQgYm9yZGVyLWJsdWVHcmF5LTIwMCByb3VuZGVkLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsTmV3VXNlcihmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFVzZXIoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0gY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIG14LTIgZm9udC1ib2xkXCI+RmVjaGFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiB0eXBlPSdzdWJtaXQnIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPlNhbHZhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktMjUgZml4ZWQgaW5zZXQtMCB6LTQwIGJnLWJsYWNrXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IG51bGx9XHJcblxyXG4gICAgICAgICAgICB7LyogTW9kYWwgTmV3UGhvbmUgKi99XHJcbiAgICAgICAgICAgIHtzaG93TW9kYWxOZXdQaG9uZSB8fCBzaG93TW9kYWxFZGl0UGhvbmUgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwianVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGZsZXggb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIGZpeGVkIGluc2V0LTAgei01MCBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1hdXRvIG15LTIgbXgtYXV0byBtYXgtdy0zeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCB3LWZ1bGwgYmctd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcC01IGJvcmRlci1iIGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsTmV3UGhvbmUgPyAnTm92byBUZWxlZm9uZScgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dNb2RhbEVkaXRQaG9uZSA/ICdFZGl0YXIgVGVsZWZvbmUnIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC02IGZsZXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17c2hvd01vZGFsTmV3UGhvbmUgPyBhZGROZXdQaG9uZSA6IGVkaXRQaG9uZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cIm5hbWVcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5Ob21lOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJuYW1lXCIgdmFsdWU9e3Bob25lVG9FZGl0Lm5vbWV9IG9uQ2hhbmdlPXtwaG9uZVRvRWRpdC5ub21lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWVcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+VGVsZWZvbmU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmVJbnB1dCBpZD1cInBob25lXCIgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUZWxlZm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRyeT1cIkJSXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFBob25lfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT0naGlkZGVuJyBpZD0ncGhvbmVJZEhpZGRlbicgdmFsdWU9e3Bob25lVG9FZGl0LmlkfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10IGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZShmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFBob25lKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBteC0yIGZvbnQtYm9sZFwiPkZlY2hhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+U2FsdmFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3BhY2l0eS0yNSBmaXhlZCBpbnNldC0wIHotNDAgYmctYmxhY2tcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoY3R4LCByZXEpIHtcclxuICAgIGlmICghY3R4LnJlcS5jb29raWVzLnVzZXIpXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcmVkaXJlY3Q6IHtcclxuICAgICAgICAgICAgICAgIHBlcm1hbmVudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBkZXN0aW5hdGlvbjogXCIvXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHByb3BzOiB7fSxcclxuICAgICAgICB9O1xyXG4gICAgY29uc3QgdG9rZW4gPSBKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS50b2tlblxyXG4gICAgY29uc3QgdXNlcmlkID0gSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcikudXNlcmlkXHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzJyxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBpZiAocmVzLnN0YXR1cyAhPSAyMDApIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICByZWRpcmVjdDoge1xyXG4gICAgICAgICAgICAgICAgcGVybWFuZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uOiBcIi9sb2dpblwiLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm9wczoge30sXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCByZXNUZWwgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YT91c2Vyc19wZXJtaXNzaW9uc191c2VyLmlkPScgKyB1c2VyaWQsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgY29uc3QgdXNlcnMgPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICBjb25zdCB0ZWxzID0gYXdhaXQgcmVzVGVsLmpzb24oKVxyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpXHJcbiAgICBjb25zb2xlLmxvZyhKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS50b2tlbilcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgcHJvcHM6IHtcclxuICAgICAgICAgICAgdXNlcnMsXHJcbiAgICAgICAgICAgIHVzZXIsXHJcbiAgICAgICAgICAgIHRlbHMsXHJcbiAgICAgICAgICAgIHRva2VuXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICB9XHJcbn0iXSwibmFtZXMiOlsiSGVhZCIsInVzZVN0YXRlIiwidXNlUm91dGVyIiwidXNlQ29va2llcyIsIlBob25lSW5wdXQiLCJEYXRhIiwidXNlcnMiLCJ1c2VyIiwidGVscyIsInRva2VuIiwicm91dGVyIiwiY29va2llIiwic2V0Q29va2llIiwicmVtb3ZlQ29va2llIiwic2hvd01vZGFsTmV3VXNlciIsInNldFNob3dNb2RhbE5ld1VzZXIiLCJzaG93TW9kYWxOZXdQaG9uZSIsInNldFNob3dNb2RhbE5ld1Bob25lIiwiaW52YWxpZFBhc3N3b3JkIiwic2V0SW52YWxpZFBhc3N3b3JkIiwic2hvd01vZGFsRWRpdFVzZXIiLCJzZXRTaG93TW9kYWxFZGl0VXNlciIsInNob3dNb2RhbEVkaXRQaG9uZSIsInNldFNob3dNb2RhbEVkaXRQaG9uZSIsImxvY2FsVXNlcnMiLCJzZXRMb2NhbFVzZXJzIiwibG9jYWxUZWxzIiwic2V0TG9jYWxUZWxzIiwicGhvbmUiLCJzZXRQaG9uZSIsInVzZXJUb0VkaXQiLCJzZXRVc2VyVG9FZGl0IiwicGhvbmVUb0VkaXQiLCJzZXRQaG9uZVRvRWRpdCIsIm9uQ2xpY2tTYWlyIiwiZXZlbnQiLCJjb25zb2xlIiwibG9nIiwicHVzaCIsInJlbG9hZFRlbHMiLCJmZXRjaCIsInVzZXJpZCIsImhlYWRlcnMiLCJtZXRob2QiLCJyZXNUZWwiLCJqc29uIiwicmVsb2FkVXNlcnMiLCJyZXMiLCJzdGF0dXMiLCJlZGl0UGhvbmUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInBob25lSWRIaWRkZW4iLCJ2YWx1ZSIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwicGFzc3dvcmQiLCJhZGROZXdQaG9uZSIsIm5vbWUiLCJuYW1lIiwidGVsZWZvbmUiLCJ1c2Vyc19wZXJtaXNzaW9uc191c2VyIiwiaWQiLCJkZWxldGVQaG9uZSIsInBob25lSUQiLCJlZGl0VXNlciIsInVzZXJpZEhpZGRlbiIsImFkZE5ld1VzZXIiLCJwYXNzd29yZHJlcGVhdCIsInVzZXJuYW1lIiwiZW1haWwiLCJjb25maXJtZWQiLCJibG9ja2VkIiwicm9sZSIsImRlbGV0ZVVzZXIiLCJ1c2VySUQiLCJtYXAiLCJ1c3IiLCJpbmRleCIsInRlbCJdLCJzb3VyY2VSb290IjoiIn0=