"use strict";
self["webpackHotUpdate_N_E"]("pages/data",{

/***/ "./pages/data.js":
/*!***********************!*\
  !*** ./pages/data.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Data; }
/* harmony export */ });
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-cookie */ "./node_modules/react-cookie/es6/index.js");
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-phone-number-input/input */ "./node_modules/react-phone-number-input/input/index.js");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-phone-number-input/style.css */ "./node_modules/react-phone-number-input/style.css");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\data.js",
    _s = $RefreshSig$();










var __N_SSP = true;
function Data(_ref) {
  _s();

  var _this = this;

  var users = _ref.users,
      user = _ref.user,
      tels = _ref.tels,
      token = _ref.token;
  var router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();

  var _useCookies = (0,react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies)(["user"]),
      _useCookies2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__.default)(_useCookies, 3),
      cookie = _useCookies2[0],
      setCookie = _useCookies2[1],
      removeCookie = _useCookies2[2];

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewUser = _useState[0],
      setShowModalNewUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewPhone = _useState2[0],
      setShowModalNewPhone = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      invalidPassword = _useState3[0],
      setInvalidPassword = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalEditUser = _useState4[0],
      setShowModalEditUser = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(users),
      localUsers = _useState5[0],
      setLocalUsers = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(tels),
      localTels = _useState6[0],
      setLocalTels = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phone = _useState7[0],
      setPhone = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      userToEdit = _useState8[0],
      setUserToEdit = _useState8[1];

  var onClickSair = /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(event) {
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              console.log("Sair");
              removeCookie("user");
              router.push('/');

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onClickSair(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  function reloadTels() {
    return _reloadTels.apply(this, arguments);
  }

  function _reloadTels() {
    _reloadTels = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5() {
      var resTel;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return fetch('http://localhost:1337/user-data?users_permissions_user.id=' + user.userid, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              resTel = _context5.sent;
              _context5.t0 = setLocalTels;
              _context5.next = 6;
              return resTel.json();

            case 6:
              _context5.t1 = _context5.sent;
              (0, _context5.t0)(_context5.t1);

            case 8:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5);
    }));
    return _reloadTels.apply(this, arguments);
  }

  function reloadUsers() {
    return _reloadUsers.apply(this, arguments);
  }

  function _reloadUsers() {
    _reloadUsers = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee6() {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee6$(_context6) {
        while (1) {
          switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return fetch('http://localhost:1337/users', {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              res = _context6.sent;

              if (!(res.status == 200)) {
                _context6.next = 9;
                break;
              }

              _context6.t0 = setLocalUsers;
              _context6.next = 7;
              return res.json();

            case 7:
              _context6.t1 = _context6.sent;
              (0, _context6.t0)(_context6.t1);

            case 9:
            case "end":
              return _context6.stop();
          }
        }
      }, _callee6);
    }));
    return _reloadUsers.apply(this, arguments);
  }

  var addNewPhone = /*#__PURE__*/function () {
    var _ref3 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              event.preventDefault();
              _context2.next = 3;
              return fetch('http://localhost:1337/user-data', {
                body: JSON.stringify({
                  nome: event.target.name.value,
                  telefone: event.target.phone.value,
                  users_permissions_user: {
                    id: user.userid
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 3:
              res = _context2.sent;

              if (res.status == 200) {
                reloadTels();
                setShowModalNewPhone(false);
              }

            case 5:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function addNewPhone(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  function deletePhone(_x3) {
    return _deletePhone.apply(this, arguments);
  }

  function _deletePhone() {
    _deletePhone = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee7(phoneID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee7$(_context7) {
        while (1) {
          switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return fetch('http://localhost:1337/user-data/' + phoneID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context7.sent;

              if (res.status == 200) {
                reloadTels();
              }

            case 4:
            case "end":
              return _context7.stop();
          }
        }
      }, _callee7);
    }));
    return _deletePhone.apply(this, arguments);
  }

  var editUser = /*#__PURE__*/function () {
    var _ref4 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              event.preventDefault();
              _context3.next = 3;
              return fetch('http://localhost:1337/users', {
                body: JSON.stringify({
                  username: event.target.username.value,
                  email: event.target.email.value,
                  password: event.target.password.value,
                  confirmed: true,
                  blocked: false,
                  role: {
                    id: 1
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'PUT'
              });

            case 3:
              res = _context3.sent;

            case 4:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function editUser(_x4) {
      return _ref4.apply(this, arguments);
    };
  }();

  var addNewUser = /*#__PURE__*/function () {
    var _ref5 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              event.preventDefault();

              if (!(event.target.password.value !== event.target.passwordrepeat.value)) {
                _context4.next = 4;
                break;
              }

              setInvalidPassword(true);
              return _context4.abrupt("return");

            case 4:
              _context4.next = 6;
              return fetch('http://localhost:1337/users', {
                body: JSON.stringify({
                  username: event.target.username.value,
                  email: event.target.email.value,
                  password: event.target.password.value,
                  confirmed: true,
                  blocked: false,
                  role: {
                    id: 1
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 6:
              res = _context4.sent;

              if (res.status == 201) {
                reloadUsers();
                setShowModalNewUser(false);
              }

            case 8:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function addNewUser(_x5) {
      return _ref5.apply(this, arguments);
    };
  }();

  function deleteUser(_x6) {
    return _deleteUser.apply(this, arguments);
  }

  function _deleteUser() {
    _deleteUser = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee8(userID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee8$(_context8) {
        while (1) {
          switch (_context8.prev = _context8.next) {
            case 0:
              _context8.next = 2;
              return fetch('http://localhost:1337/users/' + userID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context8.sent;

              if (res.status == 200) {
                reloadUsers();
              }

            case 4:
            case "end":
              return _context8.stop();
          }
        }
      }, _callee8);
    }));
    return _deleteUser.apply(this, arguments);
  }

  console.log(users);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        children: "Desafio - Area Restrita"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 174,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 173,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex bg-gray-50",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-between w-full flex justfy-between p-3",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
          children: ["Bem vindo, ", user.username, "!!!"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 178,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
          onClick: onClickSair,
          className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
          children: "Sair"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 179,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 177,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 176,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex flex-row",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              setUserToEdit({
                username: '',
                email: ''
              });
              setShowModalNewUser(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Usu\xE1rio"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 186,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome de Usu\xE1rio"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 198,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "E-mail"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 201,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 204,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 207,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 197,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 196,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localUsers.map(function (usr, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                        className: "flex items-center",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "flex-shrink-0 h-10 w-10",
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: "2",
                              d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 222,
                              columnNumber: 65
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 221,
                            columnNumber: 61
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 220,
                          columnNumber: 57
                        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "ml-3",
                          children: usr.username
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 225,
                          columnNumber: 57
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 219,
                        columnNumber: 53
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 218,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.email
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 228,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                        href: "javascript:void(0)",
                        onClick: function onClick() {
                          setUserToEdit(usr);
                          setShowModalEditUser(true);
                        },
                        children: "Editar"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 229,
                        columnNumber: 106
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 229,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.username == user.username ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            return deleteUser(usr.id);
                          },
                          children: "Excluir"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 233,
                          columnNumber: 148
                        }, _this)
                      }, void 0, false)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 233,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 217,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 212,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 195,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 194,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 184,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              setPhone(null);
              setShowModalNewPhone(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Telefone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 248,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 247,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 259,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Telefone"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 262,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 265,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 268,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 258,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 257,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localTels.map(function (tel, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: tel.nome
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 279,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: tel.telefone
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 280,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: "Editar"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 281,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                        href: "javascript:void(0)",
                        onClick: function onClick() {
                          return deletePhone(tel.id);
                        },
                        children: "Excluir"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 282,
                        columnNumber: 106
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 282,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 278,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 273,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 256,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 255,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 246,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 183,
      columnNumber: 13
    }, this), showModalNewUser || showModalEditUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewUser ? 'Novo Usuário' : null, showModalEditUser ? 'Editar Usuário' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 301,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 300,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: showModalNewUser ? addNewUser : editUser,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "username",
                    className: "mb-3 block text-gray-700",
                    children: "Nome de Usu\xE1rio:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 309,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "username",
                    value: userToEdit.username,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome de Usu\xE1rio",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 310,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 308,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "email",
                    className: "mb-3 block text-gray-700",
                    children: "E-mail:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 315,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "email",
                    id: "email",
                    value: userToEdit.email,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "E-mail",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 316,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 314,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "flex flex-row",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "mr-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "password",
                        className: "mb-3 block text-gray-700",
                        children: "Senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 324,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "password",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Senha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 325,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 323,
                      columnNumber: 49
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "ml-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "passwordrepeat",
                        className: "mb-3 block text-gray-700",
                        children: "Repita a senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 330,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "passwordrepeat",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Repita a enha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 331,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 329,
                      columnNumber: 49
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 322,
                    columnNumber: 45
                  }, this), invalidPassword ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "mt-1 text-red-400",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                      href: "#",
                      children: "As senhas digitadas s\xE3o diferentes"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 338,
                      columnNumber: 53
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 337,
                    columnNumber: 49
                  }, this) : null]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 321,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                  type: "hidden",
                  value: userToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 341,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      setShowModalNewUser(false);
                      setShowModalEditUser(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 343,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    type: "submit",
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 347,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 342,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 307,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 306,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 299,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 298,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 297,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 354,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null, showModalNewPhone ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: "Novo Telefone"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 365,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 364,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: addNewPhone,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "name",
                    className: "mb-3 block text-gray-700",
                    children: "Nome:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 372,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "name",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 373,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 371,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "phone",
                    className: "mb-3 block text-gray-700",
                    children: "Telefone:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 378,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__.default, {
                    id: "phone",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Telefone",
                    value: phone,
                    country: "BR",
                    onChange: setPhone
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 379,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 377,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      return setShowModalNewPhone(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 387,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 388,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 386,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 370,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 369,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 363,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 362,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 361,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 395,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null]
  }, void 0, true);
}

_s(Data, "K8/+6wtGffPSyGcAgGtShLYcz58=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter, react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies];
});

_c = Data;

var _c;

$RefreshReg$(_c, "Data");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZGF0YS5mOTczMmFhNmZmMmMxYzNiODhiZS5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBRWUsU0FBU0ssSUFBVCxPQUE0QztBQUFBOztBQUFBOztBQUFBLE1BQTVCQyxLQUE0QixRQUE1QkEsS0FBNEI7QUFBQSxNQUFyQkMsSUFBcUIsUUFBckJBLElBQXFCO0FBQUEsTUFBZkMsSUFBZSxRQUFmQSxJQUFlO0FBQUEsTUFBVEMsS0FBUyxRQUFUQSxLQUFTO0FBQ3ZELE1BQU1DLE1BQU0sR0FBR1Isc0RBQVMsRUFBeEI7O0FBRUEsb0JBQTBDQyx3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXBEO0FBQUE7QUFBQSxNQUFPUSxNQUFQO0FBQUEsTUFBZUMsU0FBZjtBQUFBLE1BQTBCQyxZQUExQjs7QUFDQSxrQkFBZ0RaLCtDQUFRLENBQUMsS0FBRCxDQUF4RDtBQUFBLE1BQU9hLGdCQUFQO0FBQUEsTUFBeUJDLG1CQUF6Qjs7QUFDQSxtQkFBa0RkLCtDQUFRLENBQUMsS0FBRCxDQUExRDtBQUFBLE1BQU9lLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBOENoQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEQ7QUFBQSxNQUFPaUIsZUFBUDtBQUFBLE1BQXdCQyxrQkFBeEI7O0FBQ0EsbUJBQWtEbEIsK0NBQVEsQ0FBQyxLQUFELENBQTFEO0FBQUEsTUFBT21CLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBb0NwQiwrQ0FBUSxDQUFDSyxLQUFELENBQTVDO0FBQUEsTUFBT2dCLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBQ0EsbUJBQWtDdEIsK0NBQVEsQ0FBQ08sSUFBRCxDQUExQztBQUFBLE1BQU9nQixTQUFQO0FBQUEsTUFBa0JDLFlBQWxCOztBQUNBLG1CQUEwQnhCLCtDQUFRLEVBQWxDO0FBQUEsTUFBT3lCLEtBQVA7QUFBQSxNQUFjQyxRQUFkOztBQUNBLG1CQUFvQzFCLCtDQUFRLEVBQTVDO0FBQUEsTUFBTzJCLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBRUEsTUFBTUMsV0FBVztBQUFBLHNYQUFHLGlCQUFNQyxLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEJDLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQXBCLGNBQUFBLFlBQVksQ0FBQyxNQUFELENBQVo7QUFDQUgsY0FBQUEsTUFBTSxDQUFDd0IsSUFBUCxDQUFZLEdBQVo7O0FBSGdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVhKLFdBQVc7QUFBQTtBQUFBO0FBQUEsS0FBakI7O0FBYnVELFdBbUJ4Q0ssVUFuQndDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHdYQW1CdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDeUJDLEtBQUssQ0FDdEIsK0RBQStEN0IsSUFBSSxDQUFDOEIsTUFEOUMsRUFFdEI7QUFDSUMsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLG1DQUFpQixZQUFZN0I7QUFEeEIsaUJBRGI7QUFJSThCLGdCQUFBQSxNQUFNLEVBQUU7QUFKWixlQUZzQixDQUQ5Qjs7QUFBQTtBQUNVQyxjQUFBQSxNQURWO0FBQUEsNkJBV0lmLFlBWEo7QUFBQTtBQUFBLHFCQVd1QmUsTUFBTSxDQUFDQyxJQUFQLEVBWHZCOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQW5CdUQ7QUFBQTtBQUFBOztBQUFBLFdBaUN4Q0MsV0FqQ3dDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQWlDdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JOLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0lFLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWTdCO0FBRHhCLGlCQURiO0FBSUk4QixnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFBQSxvQkFVUUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FWdEI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsNkJBV1FyQixhQVhSO0FBQUE7QUFBQSxxQkFXNEJvQixHQUFHLENBQUNGLElBQUosRUFYNUI7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBakN1RDtBQUFBO0FBQUE7O0FBZ0R2RCxNQUFNSSxXQUFXO0FBQUEsc1hBQUcsa0JBQU1kLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2hCQSxjQUFBQSxLQUFLLENBQUNlLGNBQU47QUFEZ0I7QUFBQSxxQkFFRVYsS0FBSyxDQUNuQixpQ0FEbUIsRUFFbkI7QUFDSVcsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJDLGtCQUFBQSxJQUFJLEVBQUVuQixLQUFLLENBQUNvQixNQUFOLENBQWFDLElBQWIsQ0FBa0JDLEtBRFA7QUFFakJDLGtCQUFBQSxRQUFRLEVBQUV2QixLQUFLLENBQUNvQixNQUFOLENBQWF6QixLQUFiLENBQW1CMkIsS0FGWjtBQUdqQkUsa0JBQUFBLHNCQUFzQixFQUFFO0FBQ3BCQyxvQkFBQUEsRUFBRSxFQUFFakQsSUFBSSxDQUFDOEI7QUFEVztBQUhQLGlCQUFmLENBRFY7QUFRSUMsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLGtDQUFnQixrQkFEWDtBQUVMLG1DQUFpQixZQUFZN0I7QUFGeEIsaUJBUmI7QUFhSThCLGdCQUFBQSxNQUFNLEVBQUU7QUFiWixlQUZtQixDQUZQOztBQUFBO0FBRVZJLGNBQUFBLEdBRlU7O0FBb0JoQixrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ1ZsQixnQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNIOztBQXZCZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYNEIsV0FBVztBQUFBO0FBQUE7QUFBQSxLQUFqQjs7QUFoRHVELFdBMEV4Q1ksV0ExRXdDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQTBFdkQsa0JBQTJCQyxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNzQnRCLEtBQUssQ0FDbkIscUNBQXFDc0IsT0FEbEIsRUFFbkI7QUFDSXBCLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWTdCO0FBRHhCLGlCQURiO0FBS0k4QixnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ2I7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0ExRXVEO0FBQUE7QUFBQTs7QUEyRnZELE1BQU13QixRQUFRO0FBQUEsc1hBQUcsa0JBQU01QixLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNiQSxjQUFBQSxLQUFLLENBQUNlLGNBQU47QUFEYTtBQUFBLHFCQUVLVixLQUFLLENBQ25CLDZCQURtQixFQUVuQjtBQUNJVyxnQkFBQUEsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNqQlcsa0JBQUFBLFFBQVEsRUFBRTdCLEtBQUssQ0FBQ29CLE1BQU4sQ0FBYVMsUUFBYixDQUFzQlAsS0FEZjtBQUVqQlEsa0JBQUFBLEtBQUssRUFBRTlCLEtBQUssQ0FBQ29CLE1BQU4sQ0FBYVUsS0FBYixDQUFtQlIsS0FGVDtBQUdqQlMsa0JBQUFBLFFBQVEsRUFBRS9CLEtBQUssQ0FBQ29CLE1BQU4sQ0FBYVcsUUFBYixDQUFzQlQsS0FIZjtBQUlqQlUsa0JBQUFBLFNBQVMsRUFBRSxJQUpNO0FBS2pCQyxrQkFBQUEsT0FBTyxFQUFFLEtBTFE7QUFNakJDLGtCQUFBQSxJQUFJLEVBQUU7QUFBRVQsb0JBQUFBLEVBQUUsRUFBRTtBQUFOO0FBTlcsaUJBQWYsQ0FEVjtBQVNJbEIsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLGtDQUFnQixrQkFEWDtBQUVMLG1DQUFpQixZQUFZN0I7QUFGeEIsaUJBVGI7QUFjSThCLGdCQUFBQSxNQUFNLEVBQUU7QUFkWixlQUZtQixDQUZWOztBQUFBO0FBRVBJLGNBQUFBLEdBRk87O0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBUmdCLFFBQVE7QUFBQTtBQUFBO0FBQUEsS0FBZDs7QUF1QkEsTUFBTU8sVUFBVTtBQUFBLHNYQUFHLGtCQUFNbkMsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDZkEsY0FBQUEsS0FBSyxDQUFDZSxjQUFOOztBQURlLG9CQUVYZixLQUFLLENBQUNvQixNQUFOLENBQWFXLFFBQWIsQ0FBc0JULEtBQXRCLEtBQWdDdEIsS0FBSyxDQUFDb0IsTUFBTixDQUFhZ0IsY0FBYixDQUE0QmQsS0FGakQ7QUFBQTtBQUFBO0FBQUE7O0FBR1hsQyxjQUFBQSxrQkFBa0IsQ0FBQyxJQUFELENBQWxCO0FBSFc7O0FBQUE7QUFBQTtBQUFBLHFCQU1HaUIsS0FBSyxDQUNuQiw2QkFEbUIsRUFFbkI7QUFDSVcsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJXLGtCQUFBQSxRQUFRLEVBQUU3QixLQUFLLENBQUNvQixNQUFOLENBQWFTLFFBQWIsQ0FBc0JQLEtBRGY7QUFFakJRLGtCQUFBQSxLQUFLLEVBQUU5QixLQUFLLENBQUNvQixNQUFOLENBQWFVLEtBQWIsQ0FBbUJSLEtBRlQ7QUFHakJTLGtCQUFBQSxRQUFRLEVBQUUvQixLQUFLLENBQUNvQixNQUFOLENBQWFXLFFBQWIsQ0FBc0JULEtBSGY7QUFJakJVLGtCQUFBQSxTQUFTLEVBQUUsSUFKTTtBQUtqQkMsa0JBQUFBLE9BQU8sRUFBRSxLQUxRO0FBTWpCQyxrQkFBQUEsSUFBSSxFQUFFO0FBQUVULG9CQUFBQSxFQUFFLEVBQUU7QUFBTjtBQU5XLGlCQUFmLENBRFY7QUFTSWxCLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxrQ0FBZ0Isa0JBRFg7QUFFTCxtQ0FBaUIsWUFBWTdCO0FBRnhCLGlCQVRiO0FBY0k4QixnQkFBQUEsTUFBTSxFQUFFO0FBZFosZUFGbUIsQ0FOUjs7QUFBQTtBQU1USSxjQUFBQSxHQU5TOztBQXlCZixrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJGLGdCQUFBQSxXQUFXO0FBQ1gzQixnQkFBQUEsbUJBQW1CLENBQUMsS0FBRCxDQUFuQjtBQUNIOztBQTVCYztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFWbUQsVUFBVTtBQUFBO0FBQUE7QUFBQSxLQUFoQjs7QUFsSHVELFdBaUp4Q0UsVUFqSndDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHdYQWlKdkQsa0JBQTBCQyxNQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNzQmpDLEtBQUssQ0FDbkIsaUNBQWlDaUMsTUFEZCxFQUVuQjtBQUNJL0IsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLG1DQUFpQixZQUFZN0I7QUFEeEIsaUJBRGI7QUFLSThCLGdCQUFBQSxNQUFNLEVBQUU7QUFMWixlQUZtQixDQUQzQjs7QUFBQTtBQUNVSSxjQUFBQSxHQURWOztBQVlJLGtCQUFJQSxHQUFHLENBQUNDLE1BQUosSUFBYyxHQUFsQixFQUF1QjtBQUNuQkYsZ0JBQUFBLFdBQVc7QUFDZDs7QUFkTDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQWpKdUQ7QUFBQTtBQUFBOztBQWtLdkRWLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZM0IsS0FBWjtBQUNBLHNCQUNJO0FBQUEsNEJBQ0ksOERBQUMsa0RBQUQ7QUFBQSw2QkFDSTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFESixlQUlJO0FBQUssZUFBUyxFQUFDLGlCQUFmO0FBQUEsNkJBQ0k7QUFBSyxpQkFBUyxFQUFDLGdEQUFmO0FBQUEsZ0NBQ0k7QUFBQSxvQ0FBa0JDLElBQUksQ0FBQ3FELFFBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQUVJO0FBQVEsaUJBQU8sRUFBRTlCLFdBQWpCO0FBQThCLG1CQUFTLEVBQUMsd0RBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFKSixlQVdJO0FBQUssZUFBUyxFQUFDLGVBQWY7QUFBQSw4QkFDSTtBQUFLLGlCQUFTLEVBQUMsV0FBZjtBQUFBLGdDQUNJO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsaUNBQ0k7QUFBUSxtQkFBTyxFQUFFLG1CQUFNO0FBQ25CRCxjQUFBQSxhQUFhLENBQUM7QUFDVitCLGdCQUFBQSxRQUFRLEVBQUUsRUFEQTtBQUVWQyxnQkFBQUEsS0FBSyxFQUFFO0FBRkcsZUFBRCxDQUFiO0FBSUE5QyxjQUFBQSxtQkFBbUIsQ0FBQyxJQUFELENBQW5CO0FBQ0gsYUFORDtBQU1HLHFCQUFTLEVBQUMsd0RBTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBVUk7QUFBSyxtQkFBUyxFQUFDLCtDQUFmO0FBQUEsaUNBQ0k7QUFBTyxxQkFBUyxFQUFDLHFDQUFqQjtBQUFBLG9DQUNJO0FBQU8sdUJBQVMsRUFBQyxZQUFqQjtBQUFBLHFDQUNJO0FBQUEsd0NBQ0k7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREosZUFJSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKSixlQU9JO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQSixlQVVJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBaUJJO0FBQU8sdUJBQVMsRUFBQyxtQ0FBakI7QUFBQSx3QkFHUU8sVUFBVSxDQUFDZ0QsR0FBWCxDQUFlLFVBQUNDLEdBQUQsRUFBTUMsS0FBTjtBQUFBLG9DQUNYO0FBQUEseUNBQ0k7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNkJBQWQ7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsbUJBQWY7QUFBQSxnREFDSTtBQUFLLG1DQUFTLEVBQUMseUJBQWY7QUFBQSxpREFDSTtBQUFLLGlDQUFLLEVBQUMsNEJBQVg7QUFBd0MsZ0NBQUksRUFBQyxNQUE3QztBQUFvRCxtQ0FBTyxFQUFDLFdBQTVEO0FBQXdFLGtDQUFNLEVBQUMsY0FBL0U7QUFBQSxtREFDSTtBQUFNLDJDQUFhLEVBQUMsT0FBcEI7QUFBNEIsNENBQWMsRUFBQyxPQUEzQztBQUFtRCx5Q0FBVyxFQUFDLEdBQS9EO0FBQW1FLCtCQUFDLEVBQUM7QUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURKLGVBTUk7QUFBSyxtQ0FBUyxFQUFDLE1BQWY7QUFBQSxvQ0FBdUJELEdBQUcsQ0FBQ1g7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBV0k7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsZ0NBQTBEVyxHQUFHLENBQUNWO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBWEosZUFZSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSw2Q0FBeUQ7QUFBRyw0QkFBSSxFQUFDLG9CQUFSO0FBQTZCLCtCQUFPLEVBQUUsbUJBQU07QUFDakdoQywwQkFBQUEsYUFBYSxDQUFDMEMsR0FBRCxDQUFiO0FBQ0FsRCwwQkFBQUEsb0JBQW9CLENBQUMsSUFBRCxDQUFwQjtBQUNILHlCQUh3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVpKLGVBZ0JJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBLGdDQUEwRGtELEdBQUcsQ0FBQ1gsUUFBSixJQUFnQnJELElBQUksQ0FBQ3FELFFBQXJCLEdBQWdDLElBQWhDLGdCQUF1QztBQUFBLCtDQUFFO0FBQUcsOEJBQUksRUFBQyxvQkFBUjtBQUE2QixpQ0FBTyxFQUFFO0FBQUEsbUNBQU1RLFVBQVUsQ0FBQ0csR0FBRyxDQUFDZixFQUFMLENBQWhCO0FBQUEsMkJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUY7QUFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFoQko7QUFBQSxxQkFBUSxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixpQ0FEVztBQUFBLGVBQWY7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBK0RJO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsZ0NBQ0k7QUFBSyxtQkFBUyxFQUFDLEtBQWY7QUFBQSxpQ0FDSTtBQUFRLG1CQUFPLEVBQ1gsbUJBQU07QUFDRjdCLGNBQUFBLFFBQVEsQ0FBQyxJQUFELENBQVI7QUFDQVYsY0FBQUEsb0JBQW9CLENBQUMsSUFBRCxDQUFwQjtBQUNILGFBSkw7QUFLRSxxQkFBUyxFQUFDLHdEQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQVNJO0FBQUssbUJBQVMsRUFBQywrQ0FBZjtBQUFBLGlDQUNJO0FBQU8scUJBQVMsRUFBQyxxQ0FBakI7QUFBQSxvQ0FDSTtBQUFPLHVCQUFTLEVBQUMsWUFBakI7QUFBQSxxQ0FDSTtBQUFBLHdDQUNJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURKLGVBSUk7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSkosZUFPSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFVSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQWlCSTtBQUFPLHVCQUFTLEVBQUMsbUNBQWpCO0FBQUEsd0JBR1FPLFNBQVMsQ0FBQzhDLEdBQVYsQ0FBYyxVQUFDRyxHQUFELEVBQU1ELEtBQU47QUFBQSxvQ0FDVjtBQUFBLHlDQUNJO0FBQUEsNENBQ0k7QUFBSSwrQkFBUyxFQUFDLDZCQUFkO0FBQUEsZ0NBQTZDQyxHQUFHLENBQUN2QjtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBRUk7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsZ0NBQTBEdUIsR0FBRyxDQUFDbkI7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGSixlQUdJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFISixlQUlJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBLDZDQUF5RDtBQUFHLDRCQUFJLEVBQUMsb0JBQVI7QUFBNkIsK0JBQU8sRUFBRTtBQUFBLGlDQUFNRyxXQUFXLENBQUNnQixHQUFHLENBQUNqQixFQUFMLENBQWpCO0FBQUEseUJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSko7QUFBQSxxQkFBUSxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixpQ0FEVTtBQUFBLGVBQWQ7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQS9ESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFYSixFQTJISzFDLGdCQUFnQixJQUFJTSxpQkFBcEIsZ0JBQ0c7QUFBQSw4QkFDSTtBQUFLLGlCQUFTLEVBQUMsdUhBQWY7QUFBQSwrQkFDSTtBQUFLLG1CQUFTLEVBQUMsd0NBQWY7QUFBQSxpQ0FDSTtBQUFLLHFCQUFTLEVBQUMsc0dBQWY7QUFBQSxvQ0FDSTtBQUFLLHVCQUFTLEVBQUMsMEZBQWY7QUFBQSxxQ0FDSTtBQUFNLHlCQUFTLEVBQUMsZUFBaEI7QUFBQSwyQkFDS04sZ0JBQWdCLEdBQUcsY0FBSCxHQUFvQixJQUR6QyxFQUVLTSxpQkFBaUIsR0FBRyxnQkFBSCxHQUFzQixJQUY1QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBT0k7QUFBSyx1QkFBUyxFQUFDLHdCQUFmO0FBQUEscUNBQ0k7QUFBTSx3QkFBUSxFQUFFTixnQkFBZ0IsR0FBR29ELFVBQUgsR0FBZ0JQLFFBQWhEO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsVUFBZjtBQUEwQiw2QkFBUyxFQUFDLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsVUFBdEI7QUFBaUMseUJBQUssRUFBRS9CLFVBQVUsQ0FBQ2dDLFFBQW5EO0FBQTZELDRCQUFRLEVBQUUvQixhQUF2RTtBQUNJLDZCQUFTLEVBQUMsMEVBRGQ7QUFFSSwrQkFBVyxFQUFDLG9CQUZoQjtBQUVrQyw0QkFBUSxFQUFFLENBQUNULGlCQUY3QztBQUVnRSw0QkFBUSxFQUFFQTtBQUYxRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESixlQU9JO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBdUIsNkJBQVMsRUFBQywwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFPLHdCQUFJLEVBQUMsT0FBWjtBQUFvQixzQkFBRSxFQUFDLE9BQXZCO0FBQStCLHlCQUFLLEVBQUVRLFVBQVUsQ0FBQ2lDLEtBQWpEO0FBQXdELDRCQUFRLEVBQUVoQyxhQUFsRTtBQUNJLDZCQUFTLEVBQUMsMEVBRGQ7QUFFSSwrQkFBVyxFQUFDLFFBRmhCO0FBRXlCLDRCQUFRLEVBQUUsQ0FBQ1QsaUJBRnBDO0FBRXVELDRCQUFRLEVBQUVBO0FBRmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBKLGVBY0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFLLDZCQUFTLEVBQUMsZUFBZjtBQUFBLDRDQUNJO0FBQUssK0JBQVMsRUFBQyxNQUFmO0FBQUEsOENBQ0k7QUFBTywrQkFBTyxFQUFDLFVBQWY7QUFBMEIsaUNBQVMsRUFBQywwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREosZUFFSTtBQUFPLDRCQUFJLEVBQUMsVUFBWjtBQUF1QiwwQkFBRSxFQUFDLFVBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsT0FGaEI7QUFFd0IsZ0NBQVE7QUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREosZUFPSTtBQUFLLCtCQUFTLEVBQUMsTUFBZjtBQUFBLDhDQUNJO0FBQU8sK0JBQU8sRUFBQyxnQkFBZjtBQUFnQyxpQ0FBUyxFQUFDLDBCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFESixlQUVJO0FBQU8sNEJBQUksRUFBQyxVQUFaO0FBQXVCLDBCQUFFLEVBQUMsZ0JBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsZUFGaEI7QUFFZ0MsZ0NBQVE7QUFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLEVBZUtGLGVBQWUsZ0JBQ1o7QUFBSyw2QkFBUyxFQUFDLG1CQUFmO0FBQUEsMkNBQ0k7QUFBRywwQkFBSSxFQUFDLEdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURZLEdBR0gsSUFsQmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFkSixlQWtDSTtBQUFPLHNCQUFJLEVBQUMsUUFBWjtBQUFxQix1QkFBSyxFQUFFVSxVQUFVLENBQUM0QjtBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWxDSixlQW1DSTtBQUFLLDJCQUFTLEVBQUMsd0ZBQWY7QUFBQSwwQ0FDSTtBQUFRLDJCQUFPLEVBQUUsbUJBQU07QUFDbkJ6QyxzQkFBQUEsbUJBQW1CLENBQUMsS0FBRCxDQUFuQjtBQUNBTSxzQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNILHFCQUhEO0FBR0csNkJBQVMsRUFBQywyREFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUtJO0FBQVEsd0JBQUksRUFBQyxRQUFiO0FBQXNCLDZCQUFTLEVBQUMsd0RBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBMERJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0ExREo7QUFBQSxvQkFESCxHQTZERyxJQXhMUixFQTJMS0wsaUJBQWlCLGdCQUNkO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLHVIQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHNHQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBGQUFmO0FBQUEscUNBQ0k7QUFBTSx5QkFBUyxFQUFDLGVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQU1JO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLHFDQUNJO0FBQU0sd0JBQVEsRUFBRTZCLFdBQWhCO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsTUFBZjtBQUFzQiw2QkFBUyxFQUFDLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsTUFBdEI7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxNQUZoQjtBQUV1Qiw0QkFBUTtBQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESixlQU9JO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBdUIsNkJBQVMsRUFBQywwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSSw4REFBQyxtRUFBRDtBQUFZLHNCQUFFLEVBQUMsT0FBZjtBQUF1Qiw2QkFBUyxFQUFDLDBFQUFqQztBQUNJLCtCQUFXLEVBQUMsVUFEaEI7QUFFSSx5QkFBSyxFQUFFbkIsS0FGWDtBQUdJLDJCQUFPLEVBQUMsSUFIWjtBQUlJLDRCQUFRLEVBQUVDO0FBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFnQkk7QUFBSywyQkFBUyxFQUFDLHdGQUFmO0FBQUEsMENBQ0k7QUFBUSwyQkFBTyxFQUFFO0FBQUEsNkJBQU1WLG9CQUFvQixDQUFDLEtBQUQsQ0FBMUI7QUFBQSxxQkFBakI7QUFBb0QsNkJBQVMsRUFBQywyREFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFRLDZCQUFTLEVBQUMsd0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBbUNJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FuQ0o7QUFBQSxvQkFEYyxHQXNDZCxJQWpPUjtBQUFBLGtCQURKO0FBcU9IOztHQXhZdUJaO1VBQ0xILG9EQUUyQkM7OztLQUh0QkUiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvZGF0YS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgeyB1c2VDb29raWVzIH0gZnJvbSBcInJlYWN0LWNvb2tpZVwiXHJcbmltcG9ydCBQaG9uZUlucHV0IGZyb20gJ3JlYWN0LXBob25lLW51bWJlci1pbnB1dC9pbnB1dCdcclxuaW1wb3J0ICdyZWFjdC1waG9uZS1udW1iZXItaW5wdXQvc3R5bGUuY3NzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGF0YSh7IHVzZXJzLCB1c2VyLCB0ZWxzLCB0b2tlbiB9KSB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG5cclxuICAgIGNvbnN0IFtjb29raWUsIHNldENvb2tpZSwgcmVtb3ZlQ29va2llXSA9IHVzZUNvb2tpZXMoW1widXNlclwiXSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxOZXdVc2VyLCBzZXRTaG93TW9kYWxOZXdVc2VyXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbE5ld1Bob25lLCBzZXRTaG93TW9kYWxOZXdQaG9uZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtpbnZhbGlkUGFzc3dvcmQsIHNldEludmFsaWRQYXNzd29yZF0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxFZGl0VXNlciwgc2V0U2hvd01vZGFsRWRpdFVzZXJdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbbG9jYWxVc2Vycywgc2V0TG9jYWxVc2Vyc10gPSB1c2VTdGF0ZSh1c2VycylcclxuICAgIGNvbnN0IFtsb2NhbFRlbHMsIHNldExvY2FsVGVsc10gPSB1c2VTdGF0ZSh0ZWxzKVxyXG4gICAgY29uc3QgW3Bob25lLCBzZXRQaG9uZV0gPSB1c2VTdGF0ZSgpXHJcbiAgICBjb25zdCBbdXNlclRvRWRpdCwgc2V0VXNlclRvRWRpdF0gPSB1c2VTdGF0ZSgpO1xyXG5cclxuICAgIGNvbnN0IG9uQ2xpY2tTYWlyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGNvbnNvbGUubG9nKFwiU2FpclwiKVxyXG4gICAgICAgIHJlbW92ZUNvb2tpZShcInVzZXJcIilcclxuICAgICAgICByb3V0ZXIucHVzaCgnLycpXHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcmVsb2FkVGVscygpIHtcclxuICAgICAgICBjb25zdCByZXNUZWwgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGE/dXNlcnNfcGVybWlzc2lvbnNfdXNlci5pZD0nICsgdXNlci51c2VyaWQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICBzZXRMb2NhbFRlbHMoYXdhaXQgcmVzVGVsLmpzb24oKSlcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZWxvYWRVc2VycygpIHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICBzZXRMb2NhbFVzZXJzKGF3YWl0IHJlcy5qc29uKCkpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIGNvbnN0IGFkZE5ld1Bob25lID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGEnLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgbm9tZTogZXZlbnQudGFyZ2V0Lm5hbWUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsZWZvbmU6IGV2ZW50LnRhcmdldC5waG9uZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB1c2Vyc19wZXJtaXNzaW9uc191c2VyOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlkOiB1c2VyLnVzZXJpZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICByZWxvYWRUZWxzKClcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsTmV3UGhvbmUoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVBob25lKHBob25lSUQpIHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGEvJyArIHBob25lSUQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURSdcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHJlbG9hZFRlbHMoKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBlZGl0VXNlciA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMnLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcm5hbWU6IGV2ZW50LnRhcmdldC51c2VybmFtZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBlbWFpbDogZXZlbnQudGFyZ2V0LmVtYWlsLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlybWVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHJvbGU6IHsgaWQ6IDEgfVxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BVVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhZGROZXdVc2VyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlICE9PSBldmVudC50YXJnZXQucGFzc3dvcmRyZXBlYXQudmFsdWUpIHtcclxuICAgICAgICAgICAgc2V0SW52YWxpZFBhc3N3b3JkKHRydWUpXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTogZXZlbnQudGFyZ2V0LnVzZXJuYW1lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiBldmVudC50YXJnZXQuZW1haWwudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGV2ZW50LnRhcmdldC5wYXNzd29yZC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBjb25maXJtZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcm9sZTogeyBpZDogMSB9XHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDEpIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVVc2VyKHVzZXJJRCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzLycgKyB1c2VySUQsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0RFTEVURSdcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHJlbG9hZFVzZXJzKClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc29sZS5sb2codXNlcnMpXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPkRlc2FmaW8gLSBBcmVhIFJlc3RyaXRhPC90aXRsZT5cclxuICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGZsZXgganVzdGZ5LWJldHdlZW4gcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPHNwYW4+QmVtIHZpbmRvLCB7dXNlci51c2VybmFtZX0hISE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrU2Fpcn0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+U2FpcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXNlclRvRWRpdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdXNlcm5hbWU6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgfX0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+Tm92byBVc3XDoXJpbzwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01IGJvcmRlciBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9tZSBkZSBVc3XDoXJpb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEUtbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFVzZXJzLm1hcCgodXNyLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PVwieyBpbmRleCB9XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgaC0xMCB3LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTYgN2E0IDQgMCAxMS04IDAgNCA0IDAgMDE4IDB6TTEyIDE0YTcgNyAwIDAwLTcgN2gxNGE3IDcgMCAwMC03LTd6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0zXCI+e3Vzci51c2VybmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt1c3IuZW1haWx9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPSdqYXZhc2NyaXB0OnZvaWQoMCknIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVzZXJUb0VkaXQodXNyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFVzZXIodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+RWRpdGFyPC9hPjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3Vzci51c2VybmFtZSA9PSB1c2VyLnVzZXJuYW1lID8gbnVsbCA6IDw+PGEgaHJlZj0namF2YXNjcmlwdDp2b2lkKDApJyBvbkNsaWNrPXsoKSA9PiBkZWxldGVVc2VyKHVzci5pZCl9PkV4Y2x1aXI8L2E+PC8+fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGhvbmUobnVsbClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZSh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPk5vdm8gVGVsZWZvbmU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNSBib3JkZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUZWxlZm9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFRlbHMubWFwKCh0ZWwsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9XCJ7IGluZGV4IH1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcFwiPnt0ZWwubm9tZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt0ZWwudGVsZWZvbmV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj5FZGl0YXI8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPjxhIGhyZWY9J2phdmFzY3JpcHQ6dm9pZCgwKScgb25DbGljaz17KCkgPT4gZGVsZXRlUGhvbmUodGVsLmlkKX0+RXhjbHVpcjwvYT48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBOZXdVc2VyICovfVxyXG4gICAgICAgICAgICB7c2hvd01vZGFsTmV3VXNlciB8fCBzaG93TW9kYWxFZGl0VXNlciA/IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZmxleCBvdmVyZmxvdy14LWhpZGRlbiBvdmVyZmxvdy15LWF1dG8gZml4ZWQgaW5zZXQtMCB6LTUwIG91dGxpbmUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWF1dG8gbXktMiBteC1hdXRvIG1heC13LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMCByb3VuZGVkLWxnIHNoYWRvdy1sZyByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIHctZnVsbCBiZy13aGl0ZSBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBwLTUgYm9yZGVyLWIgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC10XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93TW9kYWxOZXdVc2VyID8gJ05vdm8gVXN1w6FyaW8nIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93TW9kYWxFZGl0VXNlciA/ICdFZGl0YXIgVXN1w6FyaW8nIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC02IGZsZXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17c2hvd01vZGFsTmV3VXNlciA/IGFkZE5ld1VzZXIgOiBlZGl0VXNlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXJuYW1lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+Tm9tZSBkZSBVc3XDoXJpbzo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwidXNlcm5hbWVcIiB2YWx1ZT17dXNlclRvRWRpdC51c2VybmFtZX0gb25DaGFuZ2U9e3NldFVzZXJUb0VkaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSBkZSBVc3XDoXJpb1wiIHJlcXVpcmVkPXshc2hvd01vZGFsRWRpdFVzZXJ9IGRpc2FibGVkPXtzaG93TW9kYWxFZGl0VXNlcn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPkUtbWFpbDo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBpZD1cImVtYWlsXCIgdmFsdWU9e3VzZXJUb0VkaXQuZW1haWx9IG9uQ2hhbmdlPXtzZXRVc2VyVG9FZGl0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkUtbWFpbFwiIHJlcXVpcmVkPXshc2hvd01vZGFsRWRpdFVzZXJ9IGRpc2FibGVkPXtzaG93TW9kYWxFZGl0VXNlcn0gLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtYi02Jz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21yLTInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPlNlbmhhOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbmhhXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtbC0yJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRyZXBlYXRcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5SZXBpdGEgYSBzZW5oYTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwicGFzc3dvcmRyZXBlYXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZXBpdGEgYSBlbmhhXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ludmFsaWRQYXNzd29yZCA/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXJlZC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCI+QXMgc2VuaGFzIGRpZ2l0YWRhcyBzw6NvIGRpZmVyZW50ZXM8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPSdoaWRkZW4nIHZhbHVlPXt1c2VyVG9FZGl0LmlkfS8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC1iXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRVc2VyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBteC0yIGZvbnQtYm9sZFwiPkZlY2hhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT0nc3VibWl0JyBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWx2YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTI1IGZpeGVkIGluc2V0LTAgei00MCBiZy1ibGFja1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgey8qIE1vZGFsIE5ld1Bob25lICovfVxyXG4gICAgICAgICAgICB7c2hvd01vZGFsTmV3UGhvbmUgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwianVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGZsZXggb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIGZpeGVkIGluc2V0LTAgei01MCBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1hdXRvIG15LTIgbXgtYXV0byBtYXgtdy0zeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCB3LWZ1bGwgYmctd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcC01IGJvcmRlci1iIGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb3ZvIFRlbGVmb25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiBmbGV4LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2FkZE5ld1Bob25lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmFtZVwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPk5vbWU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWVcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+VGVsZWZvbmU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmVJbnB1dCBpZD1cInBob25lXCIgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUZWxlZm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRyeT1cIkJSXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFBob25lfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10IGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsTmV3UGhvbmUoZmFsc2UpfSBjbGFzc05hbWU9XCJiZy1yZWQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgbXgtMiBmb250LWJvbGRcIj5GZWNoYXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPlNhbHZhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZm9ybT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm9wYWNpdHktMjUgZml4ZWQgaW5zZXQtMCB6LTQwIGJnLWJsYWNrXCI+PC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgICAgPC8+XHJcbiAgICApXHJcbn1cclxuXHJcblxyXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2VydmVyU2lkZVByb3BzKGN0eCwgcmVxKSB7XHJcbiAgICBpZiAoIWN0eC5yZXEuY29va2llcy51c2VyKVxyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHJlZGlyZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBwZXJtYW5lbnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb246IFwiL1wiLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm9wczoge30sXHJcbiAgICAgICAgfTtcclxuICAgIGNvbnN0IHRva2VuID0gSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcikudG9rZW5cclxuICAgIGNvbnN0IHVzZXJpZCA9IEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpLnVzZXJpZFxyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgaWYgKHJlcy5zdGF0dXMgIT0gMjAwKSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcmVkaXJlY3Q6IHtcclxuICAgICAgICAgICAgICAgIHBlcm1hbmVudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBkZXN0aW5hdGlvbjogXCIvbG9naW5cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcHJvcHM6IHt9LFxyXG4gICAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgcmVzVGVsID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGE/dXNlcnNfcGVybWlzc2lvbnNfdXNlci5pZD0nICsgdXNlcmlkLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGNvbnN0IHVzZXJzID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgY29uc3QgdGVscyA9IGF3YWl0IHJlc1RlbC5qc29uKClcclxuICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKVxyXG4gICAgY29uc29sZS5sb2coSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcikudG9rZW4pXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAgIHByb3BzOiB7XHJcbiAgICAgICAgICAgIHVzZXJzLFxyXG4gICAgICAgICAgICB1c2VyLFxyXG4gICAgICAgICAgICB0ZWxzLFxyXG4gICAgICAgICAgICB0b2tlblxyXG4gICAgICAgIH0sXHJcblxyXG4gICAgfVxyXG59Il0sIm5hbWVzIjpbIkhlYWQiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsInVzZUNvb2tpZXMiLCJQaG9uZUlucHV0IiwiRGF0YSIsInVzZXJzIiwidXNlciIsInRlbHMiLCJ0b2tlbiIsInJvdXRlciIsImNvb2tpZSIsInNldENvb2tpZSIsInJlbW92ZUNvb2tpZSIsInNob3dNb2RhbE5ld1VzZXIiLCJzZXRTaG93TW9kYWxOZXdVc2VyIiwic2hvd01vZGFsTmV3UGhvbmUiLCJzZXRTaG93TW9kYWxOZXdQaG9uZSIsImludmFsaWRQYXNzd29yZCIsInNldEludmFsaWRQYXNzd29yZCIsInNob3dNb2RhbEVkaXRVc2VyIiwic2V0U2hvd01vZGFsRWRpdFVzZXIiLCJsb2NhbFVzZXJzIiwic2V0TG9jYWxVc2VycyIsImxvY2FsVGVscyIsInNldExvY2FsVGVscyIsInBob25lIiwic2V0UGhvbmUiLCJ1c2VyVG9FZGl0Iiwic2V0VXNlclRvRWRpdCIsIm9uQ2xpY2tTYWlyIiwiZXZlbnQiLCJjb25zb2xlIiwibG9nIiwicHVzaCIsInJlbG9hZFRlbHMiLCJmZXRjaCIsInVzZXJpZCIsImhlYWRlcnMiLCJtZXRob2QiLCJyZXNUZWwiLCJqc29uIiwicmVsb2FkVXNlcnMiLCJyZXMiLCJzdGF0dXMiLCJhZGROZXdQaG9uZSIsInByZXZlbnREZWZhdWx0IiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJub21lIiwidGFyZ2V0IiwibmFtZSIsInZhbHVlIiwidGVsZWZvbmUiLCJ1c2Vyc19wZXJtaXNzaW9uc191c2VyIiwiaWQiLCJkZWxldGVQaG9uZSIsInBob25lSUQiLCJlZGl0VXNlciIsInVzZXJuYW1lIiwiZW1haWwiLCJwYXNzd29yZCIsImNvbmZpcm1lZCIsImJsb2NrZWQiLCJyb2xlIiwiYWRkTmV3VXNlciIsInBhc3N3b3JkcmVwZWF0IiwiZGVsZXRlVXNlciIsInVzZXJJRCIsIm1hcCIsInVzciIsImluZGV4IiwidGVsIl0sInNvdXJjZVJvb3QiOiIifQ==