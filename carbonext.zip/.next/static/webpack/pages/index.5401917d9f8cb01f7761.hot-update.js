"use strict";
self["webpackHotUpdate_N_E"]("pages/index",{

/***/ "./pages/index.js":
/*!************************!*\
  !*** ./pages/index.js ***!
  \************************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ Home; }
/* harmony export */ });
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-cookie */ "./node_modules/react-cookie/es6/index.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\index.js",
    _s = $RefreshSig$();








function Home() {
  _s();

  var router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      erroLogin = _useState[0],
      setErroLogin = _useState[1];

  var _useCookies = (0,react_cookie__WEBPACK_IMPORTED_MODULE_7__.useCookies)(["user"]),
      _useCookies2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__.default)(_useCookies, 2),
      cookie = _useCookies2[0],
      setCookie = _useCookies2[1];

  var loginUser = /*#__PURE__*/function () {
    var _ref = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(event) {
      var res, result;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              event.preventDefault(); // don't redirect the page
              // where we'll add our form logic

              _context.next = 3;
              return fetch('http://localhost:1337/auth/local', {
                body: JSON.stringify({
                  identifier: event.target.username.value,
                  password: event.target.password.value
                }),
                headers: {
                  'Content-Type': 'application/json'
                },
                method: 'POST'
              });

            case 3:
              res = _context.sent;

              if (!(res.status == 200)) {
                _context.next = 14;
                break;
              }

              _context.next = 7;
              return res.json();

            case 7:
              result = _context.sent;
              localStorage.setItem('jwt', result.jwt);
              setCookie("user", JSON.stringify({
                "username": result.user.username,
                "token": result.jwt,
                "userid": result.user.id
              }), {
                path: "/",
                maxAge: 3600,
                // Expires after 1hr
                sameSite: true
              });
              console.log('Logado');
              router.push('/data');
              _context.next = 16;
              break;

            case 14:
              console.log('Erro de login');
              setErroLogin(true);

            case 16:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function loginUser(_x) {
      return _ref.apply(this, arguments);
    };
  }();

  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        children: "Desafio - Login"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
      className: "flex flex-col p-4 bg-gray-50 min-h-screen",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "flex flex-col self-center p-8 w-96 bg-green-200 rounded-lg shadow mt-20",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "rounded-full bg-green-600 w-32 h-32 -mt-24 mb-5 self-center shadow-sm flex justify-center",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("svg", {
            xmlns: "http://www.w3.org/2000/svg",
            className: "h-20 w-20 self-center  bg-gray-50",
            fill: "none",
            viewBox: "0 0 24 24",
            stroke: "#ECFDF5",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("path", {
              strokeLinecap: "round",
              strokeLinejoin: "round",
              strokeWidth: "2",
              d: "M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 59,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("form", {
          onSubmit: loginUser,
          children: [erroLogin ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative space-x-1 mb-4 text-center",
            role: "alert",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("strong", {
              className: "font-bold",
              children: "Erro!"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 66,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
              className: "block sm:inline",
              children: "Usu\xE1rio ou senha inv\xE1lidos"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 67,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 65,
            columnNumber: 29
          }, this) : null, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "mb-6",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
              htmlFor: "username",
              className: "mb-3 block text-gray-700",
              children: "Nome de Usu\xE1rio:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 70,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
              type: "text",
              id: "username",
              className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
              placeholder: "Nome de Usu\xE1rio",
              required: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "mb-6",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
              htmlFor: "password",
              className: "mb-3 block text-gray-700",
              children: "Senha:"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 76,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
              type: "password",
              id: "password",
              className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
              placeholder: "Senha",
              required: true
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 77,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
            className: "mb-1 bg-green-500 text-white rounded-lg p-3 font-bold w-full",
            children: "Entrar"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 82,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, this)]
  }, void 0, true);
}

_s(Home, "Szi50q5Lvc3izoNjILW7IaAVPj8=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter, react_cookie__WEBPACK_IMPORTED_MODULE_7__.useCookies];
});

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguNTQwMTkxN2Q5ZjhjYjAxZjc3NjEuaG90LXVwZGF0ZS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7OztBQUVlLFNBQVNJLElBQVQsR0FBZ0I7QUFBQTs7QUFDM0IsTUFBTUMsTUFBTSxHQUFHSCxzREFBUyxFQUF4Qjs7QUFDQSxrQkFBZ0NELCtDQUFRLENBQUMsS0FBRCxDQUF4QztBQUFBLE1BQUtLLFNBQUw7QUFBQSxNQUFnQkMsWUFBaEI7O0FBQ0Esb0JBQTRCSix3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXRDO0FBQUE7QUFBQSxNQUFPSyxNQUFQO0FBQUEsTUFBZUMsU0FBZjs7QUFFQSxNQUFNQyxTQUFTO0FBQUEscVhBQUcsaUJBQU1DLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2RBLGNBQUFBLEtBQUssQ0FBQ0MsY0FBTixHQURjLENBQ1M7QUFDdkI7O0FBRmM7QUFBQSxxQkFJSUMsS0FBSyxDQUNuQixrQ0FEbUIsRUFFbkI7QUFDSUMsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJDLGtCQUFBQSxVQUFVLEVBQUVOLEtBQUssQ0FBQ08sTUFBTixDQUFhQyxRQUFiLENBQXNCQyxLQURqQjtBQUVqQkMsa0JBQUFBLFFBQVEsRUFBRVYsS0FBSyxDQUFDTyxNQUFOLENBQWFHLFFBQWIsQ0FBc0JEO0FBRmYsaUJBQWYsQ0FEVjtBQUtJRSxnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCO0FBRFgsaUJBTGI7QUFRSUMsZ0JBQUFBLE1BQU0sRUFBRTtBQVJaLGVBRm1CLENBSlQ7O0FBQUE7QUFJUkMsY0FBQUEsR0FKUTs7QUFBQSxvQkFpQlZBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBakJKO0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUEscUJBa0JXRCxHQUFHLENBQUNFLElBQUosRUFsQlg7O0FBQUE7QUFrQkpDLGNBQUFBLE1BbEJJO0FBbUJWQyxjQUFBQSxZQUFZLENBQUNDLE9BQWIsQ0FBcUIsS0FBckIsRUFBNEJGLE1BQU0sQ0FBQ0csR0FBbkM7QUFFQXJCLGNBQUFBLFNBQVMsQ0FBQyxNQUFELEVBQVNNLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQUMsNEJBQVlXLE1BQU0sQ0FBQ0ksSUFBUCxDQUFZWixRQUF6QjtBQUFtQyx5QkFBU1EsTUFBTSxDQUFDRyxHQUFuRDtBQUF3RCwwQkFBVUgsTUFBTSxDQUFDSSxJQUFQLENBQVlDO0FBQTlFLGVBQWYsQ0FBVCxFQUE0RztBQUNqSEMsZ0JBQUFBLElBQUksRUFBRSxHQUQyRztBQUVqSEMsZ0JBQUFBLE1BQU0sRUFBRSxJQUZ5RztBQUVuRztBQUNkQyxnQkFBQUEsUUFBUSxFQUFFO0FBSHVHLGVBQTVHLENBQVQ7QUFPQUMsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjtBQUNBaEMsY0FBQUEsTUFBTSxDQUFDaUMsSUFBUCxDQUFZLE9BQVo7QUE3QlU7QUFBQTs7QUFBQTtBQWdDVkYsY0FBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksZUFBWjtBQUNBOUIsY0FBQUEsWUFBWSxDQUFDLElBQUQsQ0FBWjs7QUFqQ1U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBVEcsU0FBUztBQUFBO0FBQUE7QUFBQSxLQUFmOztBQXFDQSxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGtEQUFEO0FBQUEsNkJBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFLSTtBQUFLLGVBQVMsRUFBQywyQ0FBZjtBQUFBLDZCQUNJO0FBQUssaUJBQVMsRUFBQyx5RUFBZjtBQUFBLGdDQUNJO0FBQUssbUJBQVMsRUFBQywyRkFBZjtBQUFBLGlDQUNJO0FBQUssaUJBQUssRUFBQyw0QkFBWDtBQUF3QyxxQkFBUyxFQUFDLG1DQUFsRDtBQUFzRixnQkFBSSxFQUFDLE1BQTNGO0FBQWtHLG1CQUFPLEVBQUMsV0FBMUc7QUFDSSxrQkFBTSxFQUFDLFNBRFg7QUFBQSxtQ0FFSTtBQUFPLDJCQUFhLEVBQUMsT0FBckI7QUFBNkIsNEJBQWMsRUFBQyxPQUE1QztBQUFvRCx5QkFBVyxFQUFDLEdBQWhFO0FBQ0ksZUFBQyxFQUFDO0FBRE47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBUUk7QUFBTSxrQkFBUSxFQUFFQSxTQUFoQjtBQUFBLHFCQUNLSixTQUFTLGdCQUNOO0FBQUsscUJBQVMsRUFBQyxxR0FBZjtBQUFxSCxnQkFBSSxFQUFDLE9BQTFIO0FBQUEsb0NBQ0k7QUFBUSx1QkFBUyxFQUFDLFdBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBRUk7QUFBTSx1QkFBUyxFQUFDLGlCQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRE0sR0FJRyxJQUxqQixlQU1JO0FBQUsscUJBQVMsRUFBQyxNQUFmO0FBQUEsb0NBQ0k7QUFBTyxxQkFBTyxFQUFDLFVBQWY7QUFBMEIsdUJBQVMsRUFBQywwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFFSTtBQUFPLGtCQUFJLEVBQUMsTUFBWjtBQUFtQixnQkFBRSxFQUFDLFVBQXRCO0FBQ0ksdUJBQVMsRUFBQywwRUFEZDtBQUVJLHlCQUFXLEVBQUMsb0JBRmhCO0FBRWtDLHNCQUFRO0FBRjFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQU5KLGVBWUk7QUFBSyxxQkFBUyxFQUFDLE1BQWY7QUFBQSxvQ0FDSTtBQUFPLHFCQUFPLEVBQUMsVUFBZjtBQUEwQix1QkFBUyxFQUFDLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQUVJO0FBQU8sa0JBQUksRUFBQyxVQUFaO0FBQXVCLGdCQUFFLEVBQUMsVUFBMUI7QUFDSSx1QkFBUyxFQUFDLDBFQURkO0FBRUkseUJBQVcsRUFBQyxPQUZoQjtBQUV3QixzQkFBUTtBQUZoQztBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFaSixlQW1CSTtBQUFRLHFCQUFTLEVBQUMsOERBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQW5CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUxKO0FBQUEsa0JBREo7QUEwQ0g7O0dBcEZ1QkY7VUFDTEYsb0RBRWFDOzs7S0FIUkMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXguanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xuaW1wb3J0IHsgdXNlQ29va2llcyB9IGZyb20gXCJyZWFjdC1jb29raWVcIlxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBIb21lKCkge1xuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG4gICAgdmFyIFtlcnJvTG9naW4sIHNldEVycm9Mb2dpbl0gPSB1c2VTdGF0ZShmYWxzZSk7XG4gICAgY29uc3QgW2Nvb2tpZSwgc2V0Q29va2llXSA9IHVzZUNvb2tpZXMoW1widXNlclwiXSlcblxuICAgIGNvbnN0IGxvZ2luVXNlciA9IGFzeW5jIGV2ZW50ID0+IHtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKSAvLyBkb24ndCByZWRpcmVjdCB0aGUgcGFnZVxuICAgICAgICAvLyB3aGVyZSB3ZSdsbCBhZGQgb3VyIGZvcm0gbG9naWNcblxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvYXV0aC9sb2NhbCcsXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICBpZGVudGlmaWVyOiBldmVudC50YXJnZXQudXNlcm5hbWUudmFsdWUsXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWVcbiAgICAgICAgICAgICAgICB9KSxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbidcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnXG4gICAgICAgICAgICB9XG4gICAgICAgIClcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZXMuanNvbigpXG4gICAgICAgICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnand0JywgcmVzdWx0Lmp3dClcblxuICAgICAgICAgICAgc2V0Q29va2llKFwidXNlclwiLCBKU09OLnN0cmluZ2lmeSh7XCJ1c2VybmFtZVwiOiByZXN1bHQudXNlci51c2VybmFtZSwgXCJ0b2tlblwiOiByZXN1bHQuand0LCBcInVzZXJpZFwiOiByZXN1bHQudXNlci5pZH0pLCB7XG4gICAgICAgICAgICAgICAgcGF0aDogXCIvXCIsXG4gICAgICAgICAgICAgICAgbWF4QWdlOiAzNjAwLCAvLyBFeHBpcmVzIGFmdGVyIDFoclxuICAgICAgICAgICAgICAgIHNhbWVTaXRlOiB0cnVlLFxuICAgICAgICAgICAgICB9KVxuXG5cbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdMb2dhZG8nKVxuICAgICAgICAgICAgcm91dGVyLnB1c2goJy9kYXRhJylcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdFcnJvIGRlIGxvZ2luJylcbiAgICAgICAgICAgIHNldEVycm9Mb2dpbih0cnVlKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICAgIDxIZWFkPlxuICAgICAgICAgICAgICAgIDx0aXRsZT5EZXNhZmlvIC0gTG9naW48L3RpdGxlPlxuICAgICAgICAgICAgPC9IZWFkPlxuICAgICAgICAgICAgXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1jb2wgcC00IGJnLWdyYXktNTAgbWluLWgtc2NyZWVuXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtY29sIHNlbGYtY2VudGVyIHAtOCB3LTk2IGJnLWdyZWVuLTIwMCByb3VuZGVkLWxnIHNoYWRvdyBtdC0yMFwiPlxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvdW5kZWQtZnVsbCBiZy1ncmVlbi02MDAgdy0zMiBoLTMyIC1tdC0yNCBtYi01IHNlbGYtY2VudGVyIHNoYWRvdy1zbSBmbGV4IGp1c3RpZnktY2VudGVyXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBjbGFzc05hbWU9XCJoLTIwIHctMjAgc2VsZi1jZW50ZXIgIGJnLWdyYXktNTBcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZT1cIiNFQ0ZERjVcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCAgc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGQ9XCJNMTEgMTZsLTQtNG0wIDBsNC00bS00IDRoMTRtLTUgNHYxYTMgMyAwIDAxLTMgM0g2YTMgMyAwIDAxLTMtM1Y3YTMgMyAwIDAxMy0zaDdhMyAzIDAgMDEzIDN2MVwiIC8+XG4gICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtsb2dpblVzZXJ9PlxuICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9Mb2dpbiA/XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1yZWQtMTAwIGJvcmRlciBib3JkZXItcmVkLTQwMCB0ZXh0LXJlZC03MDAgcHgtNCBweS0zIHJvdW5kZWQgcmVsYXRpdmUgc3BhY2UteC0xIG1iLTQgdGV4dC1jZW50ZXJcIiByb2xlPVwiYWxlcnRcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN0cm9uZyBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5FcnJvITwvc3Ryb25nPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJibG9jayBzbTppbmxpbmVcIj5Vc3XDoXJpbyBvdSBzZW5oYSBpbnbDoWxpZG9zPC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiA6IG51bGx9XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXJuYW1lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+Tm9tZSBkZSBVc3XDoXJpbzo8L2xhYmVsPlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwidXNlcm5hbWVcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZGUgVXN1w6FyaW9cIiByZXF1aXJlZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+U2VuaGE6PC9sYWJlbD5cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJwYXNzd29yZFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VuaGFcIiByZXF1aXJlZCAvPlxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwibWItMSBiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHAtMyBmb250LWJvbGQgdy1mdWxsXCI+XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgRW50cmFyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvPlxuICAgIClcbn1cbiJdLCJuYW1lcyI6WyJIZWFkIiwidXNlU3RhdGUiLCJ1c2VSb3V0ZXIiLCJ1c2VDb29raWVzIiwiSG9tZSIsInJvdXRlciIsImVycm9Mb2dpbiIsInNldEVycm9Mb2dpbiIsImNvb2tpZSIsInNldENvb2tpZSIsImxvZ2luVXNlciIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJmZXRjaCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwiaWRlbnRpZmllciIsInRhcmdldCIsInVzZXJuYW1lIiwidmFsdWUiLCJwYXNzd29yZCIsImhlYWRlcnMiLCJtZXRob2QiLCJyZXMiLCJzdGF0dXMiLCJqc29uIiwicmVzdWx0IiwibG9jYWxTdG9yYWdlIiwic2V0SXRlbSIsImp3dCIsInVzZXIiLCJpZCIsInBhdGgiLCJtYXhBZ2UiLCJzYW1lU2l0ZSIsImNvbnNvbGUiLCJsb2ciLCJwdXNoIl0sInNvdXJjZVJvb3QiOiIifQ==