"use strict";
self["webpackHotUpdate_N_E"]("pages/data",{

/***/ "./pages/data.js":
/*!***********************!*\
  !*** ./pages/data.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Data; }
/* harmony export */ });
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-cookie */ "./node_modules/react-cookie/es6/index.js");
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-phone-number-input/input */ "./node_modules/react-phone-number-input/input/index.js");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-phone-number-input/style.css */ "./node_modules/react-phone-number-input/style.css");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\data.js",
    _s = $RefreshSig$();










var __N_SSP = true;
function Data(_ref) {
  _s();

  var _this = this;

  var users = _ref.users,
      user = _ref.user,
      tels = _ref.tels,
      token = _ref.token;
  var router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();

  var _useCookies = (0,react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies)(["user"]),
      _useCookies2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__.default)(_useCookies, 3),
      cookie = _useCookies2[0],
      setCookie = _useCookies2[1],
      removeCookie = _useCookies2[2];

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewUser = _useState[0],
      setShowModalNewUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewPhone = _useState2[0],
      setShowModalNewPhone = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      invalidPassword = _useState3[0],
      setInvalidPassword = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(users),
      localUsers = _useState4[0],
      setLocalUsers = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(tels),
      localTels = _useState5[0],
      setLocalTels = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phone = _useState6[0],
      setPhone = _useState6[1];

  var onClickSair = /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(event) {
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              console.log("Sair");
              removeCookie("user");
              router.push('/');

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onClickSair(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  function reloadUsers() {
    return _reloadUsers.apply(this, arguments);
  }

  function _reloadUsers() {
    _reloadUsers = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4() {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              _context4.next = 2;
              return fetch('http://localhost:1337/users', {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              res = _context4.sent;

              if (!(res.status == 200)) {
                _context4.next = 9;
                break;
              }

              _context4.t0 = setLocalUsers;
              _context4.next = 7;
              return res.json();

            case 7:
              _context4.t1 = _context4.sent;
              (0, _context4.t0)(_context4.t1);

            case 9:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));
    return _reloadUsers.apply(this, arguments);
  }

  var addNewPhone = /*#__PURE__*/function () {
    var _ref3 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2(event) {
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function addNewPhone(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var addNewUser = /*#__PURE__*/function () {
    var _ref4 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              event.preventDefault();

              if (!(event.target.password.value !== event.target.passwordrepeat.value)) {
                _context3.next = 4;
                break;
              }

              setInvalidPassword(true);
              return _context3.abrupt("return");

            case 4:
              _context3.next = 6;
              return fetch('http://localhost:1337/users', {
                body: JSON.stringify({
                  username: event.target.username.value,
                  email: event.target.email.value,
                  password: event.target.password.value,
                  confirmed: true,
                  blocked: false,
                  role: {
                    id: 1
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 6:
              res = _context3.sent;

              if (res.status == 201) {
                reloadUsers();
                setShowModalNewUser(false);
              }

            case 8:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function addNewUser(_x3) {
      return _ref4.apply(this, arguments);
    };
  }();

  function deleteUser(_x4) {
    return _deleteUser.apply(this, arguments);
  }

  function _deleteUser() {
    _deleteUser = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5(userID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              _context5.next = 2;
              return fetch('http://localhost:1337/users/' + userID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context5.sent;

              if (res.status == 200) {
                reloadUsers();
              }

            case 4:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5);
    }));
    return _deleteUser.apply(this, arguments);
  }

  console.log(users);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        children: "Desafio - Area Restrita"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 93,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 92,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex bg-gray-50",
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-between w-full flex justfy-between p-3",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
          children: ["Bem vindo, ", user.username, "!!!"]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
          onClick: onClickSair,
          className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
          children: "Sair"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "flex flex-row",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              return setShowModalNewUser(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Usu\xE1rio"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 105,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 104,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome de Usu\xE1rio"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 111,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "E-mail"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 117,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 120,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 110,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 109,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localUsers.map(function (usr, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                        className: "flex items-center",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "flex-shrink-0 h-10 w-10",
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "currentColor",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: "2",
                              d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 135,
                              columnNumber: 65
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 134,
                            columnNumber: 61
                          }, _this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 133,
                          columnNumber: 57
                        }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "ml-3",
                          children: usr.username
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 138,
                          columnNumber: 57
                        }, _this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 132,
                        columnNumber: 53
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 131,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.email
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 141,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: "Editar"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 142,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.username == user.username ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            return deleteUser(usr.id);
                          },
                          children: "Excluir"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 143,
                          columnNumber: 148
                        }, _this)
                      }, void 0, false)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 143,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 108,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 107,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex-grow",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: function onClick() {
              return setShowModalNewPhone(true);
            },
            className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
            children: "Novo Telefone"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 158,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 157,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "m-5 border border-b border-gray-200 flex-grow",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
            className: "min-w-full divide-y divide-gray-200",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
              className: "bg-gray-50",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Nome"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 164,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                  children: "Telefone"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 167,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 170,
                  columnNumber: 37
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                  scope: "col",
                  className: "relative px-6 py-3"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 173,
                  columnNumber: 37
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 163,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 162,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
              className: "bg-white divide-y divide-gray-200",
              children: localTels.map(function (tel, index) {
                return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: tel.nome
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 184,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: tel.telefone
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 185,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: "Editar"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 186,
                      columnNumber: 49
                    }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: "Excluir"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 187,
                      columnNumber: 49
                    }, _this)]
                  }, "{ index }", true, {
                    fileName: _jsxFileName,
                    lineNumber: 183,
                    columnNumber: 45
                  }, _this)
                }, void 0, false);
              })
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 178,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 161,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 160,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 156,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 102,
      columnNumber: 13
    }, this), showModalNewUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: "Novo Usu\xE1rio"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 206,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 205,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: addNewUser,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "username",
                    className: "mb-3 block text-gray-700",
                    children: "Nome de Usu\xE1rio:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 213,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "username",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome de Usu\xE1rio",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 214,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 212,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "email",
                    className: "mb-3 block text-gray-700",
                    children: "E-mail:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 219,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "email",
                    id: "email",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "E-mail",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 220,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 218,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "flex flex-row",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "mr-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "password",
                        className: "mb-3 block text-gray-700",
                        children: "Senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 228,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "password",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Senha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 229,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 227,
                      columnNumber: 49
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "ml-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "passwordrepeat",
                        className: "mb-3 block text-gray-700",
                        children: "Repita a senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 234,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "passwordrepeat",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Repita a enha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 235,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 233,
                      columnNumber: 49
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 226,
                    columnNumber: 45
                  }, this), invalidPassword ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "mt-1 text-red-400",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                      href: "#",
                      children: "As senhas digitadas s\xE3o diferentes"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 242,
                      columnNumber: 53
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 241,
                    columnNumber: 49
                  }, this) : null]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 225,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      return setShowModalNewUser(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 246,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 247,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 245,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 211,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 210,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 204,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 203,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 202,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 254,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null, showModalNewPhone ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: "Novo Telefone"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 265,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 264,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: addNewPhone,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "name",
                    className: "mb-3 block text-gray-700",
                    children: "Nome:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 272,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "name",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 273,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 271,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "phone",
                    className: "mb-3 block text-gray-700",
                    children: "Telefone:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 278,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__.default, {
                    placeholder: "Enter phone number",
                    value: phone,
                    onChange: setPhone
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 279,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 277,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      return setShowModalNewPhone(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 287,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 288,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 286,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 270,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 269,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 263,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 262,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 261,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 295,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null]
  }, void 0, true);
}

_s(Data, "xLq1/1Y12OJXkl9ugwS+2b9hhnI=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter, react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies];
});

_c = Data;

var _c;

$RefreshReg$(_c, "Data");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ }),

/***/ "./node_modules/react-phone-number-input/input/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/react-phone-number-input/input/index.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "parsePhoneNumber": function() { return /* binding */ parsePhoneNumber; },
/* harmony export */   "formatPhoneNumber": function() { return /* binding */ formatPhoneNumber; },
/* harmony export */   "formatPhoneNumberIntl": function() { return /* binding */ formatPhoneNumberIntl; },
/* harmony export */   "isValidPhoneNumber": function() { return /* binding */ isValidPhoneNumber; },
/* harmony export */   "isPossiblePhoneNumber": function() { return /* binding */ isPossiblePhoneNumber; },
/* harmony export */   "getCountries": function() { return /* binding */ getCountries; },
/* harmony export */   "getCountryCallingCode": function() { return /* binding */ getCountryCallingCode; },
/* harmony export */   "isSupportedCountry": function() { return /* binding */ isSupportedCountry; }
/* harmony export */ });
/* harmony import */ var libphonenumber_js_metadata_min_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! libphonenumber-js/metadata.min.json */ "./node_modules/libphonenumber-js/metadata.min.json");
/* harmony import */ var _core_index__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../core/index */ "./node_modules/react-phone-number-input/core/index.js");
/* harmony import */ var _modules_PhoneInputBrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../modules/PhoneInputBrowser */ "./node_modules/react-phone-number-input/modules/PhoneInputBrowser.js");






function call(func, _arguments) {
	var args = Array.prototype.slice.call(_arguments)
	args.push(libphonenumber_js_metadata_min_json__WEBPACK_IMPORTED_MODULE_0__)
	return func.apply(this, args)
}

/* harmony default export */ __webpack_exports__["default"] = ((0,_modules_PhoneInputBrowser__WEBPACK_IMPORTED_MODULE_1__.createInput)(libphonenumber_js_metadata_min_json__WEBPACK_IMPORTED_MODULE_0__));

function parsePhoneNumber() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.parsePhoneNumber, arguments)
}

function formatPhoneNumber() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.formatPhoneNumber, arguments)
}

function formatPhoneNumberIntl() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.formatPhoneNumberIntl, arguments)
}

function isValidPhoneNumber() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.isValidPhoneNumber, arguments)
}

function isPossiblePhoneNumber() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.isPossiblePhoneNumber, arguments)
}

function getCountries() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.getCountries, arguments)
}

function getCountryCallingCode() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.getCountryCallingCode, arguments)
}

function isSupportedCountry() {
	return call(_core_index__WEBPACK_IMPORTED_MODULE_2__.isSupportedCountry, arguments)
}

/***/ }),

/***/ "./node_modules/react-phone-number-input/modules/PhoneInput.js":
/*!*********************************************************************!*\
  !*** ./node_modules/react-phone-number-input/modules/PhoneInput.js ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _usePhoneDigits__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./usePhoneDigits */ "./node_modules/react-phone-number-input/modules/usePhoneDigits.js");
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





function PhoneInput(_ref, ref) {
  var Component = _ref.Component,
      country = _ref.country,
      defaultCountry = _ref.defaultCountry,
      useNationalFormatForDefaultCountryValue = _ref.useNationalFormatForDefaultCountryValue,
      value = _ref.value,
      onChange = _ref.onChange,
      metadata = _ref.metadata,
      international = _ref.international,
      withCountryCallingCode = _ref.withCountryCallingCode,
      rest = _objectWithoutProperties(_ref, ["Component", "country", "defaultCountry", "useNationalFormatForDefaultCountryValue", "value", "onChange", "metadata", "international", "withCountryCallingCode"]);

  // "Phone digits" includes not only "digits" but also a `+` sign.
  var _usePhoneDigits = (0,_usePhoneDigits__WEBPACK_IMPORTED_MODULE_2__.default)({
    value: value,
    onChange: onChange,
    country: country,
    defaultCountry: defaultCountry,
    international: international,
    withCountryCallingCode: withCountryCallingCode,
    useNationalFormatForDefaultCountryValue: useNationalFormatForDefaultCountryValue,
    metadata: metadata
  }),
      _usePhoneDigits2 = _slicedToArray(_usePhoneDigits, 2),
      phoneDigits = _usePhoneDigits2[0],
      setPhoneDigits = _usePhoneDigits2[1];

  return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(Component, _extends({}, rest, {
    ref: ref,
    metadata: metadata,
    international: international,
    withCountryCallingCode: withCountryCallingCode,
    country: country || defaultCountry,
    value: phoneDigits,
    onChange: setPhoneDigits
  }));
}

PhoneInput = react__WEBPACK_IMPORTED_MODULE_0___default().forwardRef(PhoneInput);
PhoneInput.propTypes = {
  /**
   * The phone number (in E.164 format).
   * Examples: `undefined`, `"+12"`, `"+12133734253"`.
   */
  value: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),

  /**
   * A function of `value: string?`.
   * Updates the `value` property.
   */
  onChange: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().func.isRequired),

  /**
   * A two-letter country code for formatting `value`
   * as a national phone number (example: `(213) 373-4253`),
   * or as an international phone number without "country calling code"
   * if `international` property is passed (example: `213 373 4253`).
   * Example: "US".
   * If no `country` is passed then `value`
   * is formatted as an international phone number.
   * (example: `+1 213 373 4253`)
   */
  country: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),

  /**
   * A two-letter country code for formatting `value`
   * when a user inputs a national phone number (example: `(213) 373-4253`).
   * The user can still input a phone number in international format.
   * Example: "US".
   * `country` and `defaultCountry` properties are mutually exclusive.
   */
  defaultCountry: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),

  /**
   * If `country` property is passed along with `international={true}` property
   * then the phone number will be input in "international" format for that `country`
   * (without "country calling code").
   * For example, if `country="US"` property is passed to "without country select" input
   * then the phone number will be input in the "national" format for `US` (`(213) 373-4253`).
   * But if both `country="US"` and `international={true}` properties are passed then
   * the phone number will be input in the "international" format for `US` (`213 373 4253`)
   * (without "country calling code" `+1`).
   */
  international: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool),

  /**
   * If `country` and `international` properties are set,
   * then by default it won't include "country calling code" in the input field.
   * To change that, pass `withCountryCallingCode` property,
   * and it will include "country calling code" in the input field.
   */
  withCountryCallingCode: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool),

  /**
   * A component that renders the `<input/>` itself and also
   * parses and formats its `value` as the user inputs it.
   */
  Component: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().elementType.isRequired),

  /**
   * When `defaultCountry` is defined and the initial `value` corresponds to `defaultCountry`,
   * then the `value` will be formatted as a national phone number by default.
   * To format the initial `value` of `defaultCountry` as an international number instead
   * set `useNationalFormatForDefaultCountryValue` property to `true`.
   */
  useNationalFormatForDefaultCountryValue: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool.isRequired),

  /**
   * `libphonenumber-js` metadata.
   */
  metadata: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().object.isRequired)
};
PhoneInput.defaultProps = {
  /**
   * Set to `true` to force international phone number format
   * (without "country calling code") when `country` is specified.
   */
  // international: false,

  /**
   * Prefer national format when formatting E.164 phone number `value`
   * corresponding to `defaultCountry`.
   */
  useNationalFormatForDefaultCountryValue: true
};
/* harmony default export */ __webpack_exports__["default"] = (PhoneInput);
//# sourceMappingURL=PhoneInput.js.map

/***/ }),

/***/ "./node_modules/react-phone-number-input/modules/PhoneInputBrowser.js":
/*!****************************************************************************!*\
  !*** ./node_modules/react-phone-number-input/modules/PhoneInputBrowser.js ***!
  \****************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "createInput": function() { return /* binding */ createInput; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prop-types */ "./node_modules/prop-types/index.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _PhoneInput__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./PhoneInput */ "./node_modules/react-phone-number-input/modules/PhoneInput.js");
/* harmony import */ var _InputSmart__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./InputSmart */ "./node_modules/react-phone-number-input/modules/InputSmart.js");
/* harmony import */ var _InputBasic__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./InputBasic */ "./node_modules/react-phone-number-input/modules/InputBasic.js");
function _extends() { _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






function createInput(defaultMetadata) {
  function PhoneInput(_ref, ref) {
    var smartCaret = _ref.smartCaret,
        rest = _objectWithoutProperties(_ref, ["smartCaret"]);

    return react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_PhoneInput__WEBPACK_IMPORTED_MODULE_2__.default, _extends({}, rest, {
      ref: ref,
      Component: smartCaret ? _InputSmart__WEBPACK_IMPORTED_MODULE_3__.default : _InputBasic__WEBPACK_IMPORTED_MODULE_4__.default
    }));
  }

  PhoneInput = react__WEBPACK_IMPORTED_MODULE_0___default().forwardRef(PhoneInput);
  PhoneInput.propTypes = {
    /**
     * HTML `<input/>` `type` attribute.
     */
    type: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),

    /**
     * HTML `<input/>` `autocomplete` attribute.
     */
    autoComplete: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string),

    /**
     * By default, the caret position is being "intelligently" managed
     * while a user inputs a phone number.
     * This "smart" caret behavior can be turned off
     * by passing `smartCaret={false}` property.
     * This is just an "escape hatch" for any possible caret position issues.
     */
    // Is `true` by default.
    smartCaret: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().bool.isRequired),

    /**
     * `libphonenumber-js` metadata.
     */
    metadata: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().object.isRequired)
  };
  PhoneInput.defaultProps = {
    /**
     * HTML `<input/>` `type="tel"`.
     */
    type: 'tel',

    /**
     * Remember (and autofill) the value as a phone number.
     */
    autoComplete: 'tel',

    /**
     * Set to `false` to use "basic" caret instead of the "smart" one.
     */
    smartCaret: true,

    /**
     * `libphonenumber-js` metadata.
     */
    metadata: defaultMetadata
  };
  return PhoneInput;
}
/* harmony default export */ __webpack_exports__["default"] = (createInput());
//# sourceMappingURL=PhoneInputBrowser.js.map

/***/ }),

/***/ "./node_modules/react-phone-number-input/modules/usePhoneDigits.js":
/*!*************************************************************************!*\
  !*** ./node_modules/react-phone-number-input/modules/usePhoneDigits.js ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ usePhoneDigits; }
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! libphonenumber-js/core */ "./node_modules/libphonenumber-js/core/index.js");
/* harmony import */ var _helpers_getInternationalPhoneNumberPrefix__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./helpers/getInternationalPhoneNumberPrefix */ "./node_modules/react-phone-number-input/modules/helpers/getInternationalPhoneNumberPrefix.js");
function _slicedToArray(arr, i) { return _arrayWithHoles(arr) || _iterableToArrayLimit(arr, i) || _nonIterableRest(); }

function _nonIterableRest() { throw new TypeError("Invalid attempt to destructure non-iterable instance"); }

function _iterableToArrayLimit(arr, i) { if (!(Symbol.iterator in Object(arr) || Object.prototype.toString.call(arr) === "[object Arguments]")) { return; } var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"] != null) _i["return"](); } finally { if (_d) throw _e; } } return _arr; }

function _arrayWithHoles(arr) { if (Array.isArray(arr)) return arr; }




/**
 * Returns `[phoneDigits, setPhoneDigits]`.
 * "Phone digits" includes not only "digits" but also a `+` sign.
 */

function usePhoneDigits(_ref) {
  var _this = this;

  var value = _ref.value,
      onChange = _ref.onChange,
      country = _ref.country,
      defaultCountry = _ref.defaultCountry,
      international = _ref.international,
      withCountryCallingCode = _ref.withCountryCallingCode,
      useNationalFormatForDefaultCountryValue = _ref.useNationalFormatForDefaultCountryValue,
      metadata = _ref.metadata;
  var countryMismatchDetected = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)();

  var onCountryMismatch = function onCountryMismatch(value, country, actualCountry) {
    console.error("[react-phone-number-input] Expected phone number ".concat(value, " to correspond to country ").concat(country, " but ").concat(actualCountry ? 'in reality it corresponds to country ' + actualCountry : 'it doesn\'t', "."));
    countryMismatchDetected.current = true;
  };

  var getInitialPhoneDigits = function getInitialPhoneDigits(options) {
    return getPhoneDigitsForValue(value, country, international, withCountryCallingCode, defaultCountry, useNationalFormatForDefaultCountryValue, metadata, function () {
      if (options && options.onCountryMismatch) {
        options.onCountryMismatch();
      }

      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      onCountryMismatch.apply(_this, args);
    });
  }; // This is only used to detect `country` property change.


  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(country),
      _useState2 = _slicedToArray(_useState, 2),
      prevCountry = _useState2[0],
      setPrevCountry = _useState2[1]; // This is only used to detect `defaultCountry` property change.


  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(defaultCountry),
      _useState4 = _slicedToArray(_useState3, 2),
      prevDefaultCountry = _useState4[0],
      setPrevDefaultCountry = _useState4[1]; // `phoneDigits` is the `value` passed to the `<input/>`.


  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(getInitialPhoneDigits()),
      _useState6 = _slicedToArray(_useState5, 2),
      phoneDigits = _useState6[0],
      setPhoneDigits = _useState6[1]; // This is only used to detect `value` property changes.


  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(value),
      _useState8 = _slicedToArray(_useState7, 2),
      valueForPhoneDigits = _useState8[0],
      setValueForPhoneDigits = _useState8[1]; // Rerender hack.


  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(),
      _useState10 = _slicedToArray(_useState9, 2),
      rerenderTrigger = _useState10[0],
      setRerenderTrigger = _useState10[1];

  var rerender = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function () {
    return setRerenderTrigger({});
  }, [setRerenderTrigger]);

  function getValueForPhoneDigits(phoneDigits) {
    var asYouType = new libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.AsYouType(country || defaultCountry, metadata);
    asYouType.input(country && international && !withCountryCallingCode ? "+".concat((0,libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.getCountryCallingCode)(country, metadata)).concat(phoneDigits) : phoneDigits);
    var phoneNumber = asYouType.getNumber(); // If it's a "possible" incomplete phone number.

    if (phoneNumber) {
      return phoneNumber.number;
    }
  } // If `value` property has been changed externally
  // then re-initialize the component.


  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (value !== valueForPhoneDigits) {
      setValueForPhoneDigits(value);
      setPhoneDigits(getInitialPhoneDigits());
    }
  }, [value]); // If the `country` has been changed then re-initialize the component.

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (country !== prevCountry) {
      setPrevCountry(country);

      var _countryMismatchDetected;

      var _phoneDigits = getInitialPhoneDigits({
        onCountryMismatch: function onCountryMismatch() {
          _countryMismatchDetected = true;
        }
      });

      setPhoneDigits(_phoneDigits);

      if (_countryMismatchDetected) {
        setValueForPhoneDigits(getValueForPhoneDigits(_phoneDigits));
      }
    }
  }, [country]); // If the `defaultCountry` has been changed then re-initialize the component.

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (defaultCountry !== prevDefaultCountry) {
      setPrevDefaultCountry(defaultCountry);
      setPhoneDigits(getInitialPhoneDigits());
    }
  }, [defaultCountry]); // Update the `value` after `valueForPhoneDigits` has been updated.

  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(function () {
    if (valueForPhoneDigits !== value) {
      onChange(valueForPhoneDigits);
    }
  }, [valueForPhoneDigits]);
  var onSetPhoneDigits = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(function (phoneDigits) {
    var value;

    if (country) {
      if (international && withCountryCallingCode) {
        // The `<input/>` value must start with the country calling code.
        var prefix = (0,_helpers_getInternationalPhoneNumberPrefix__WEBPACK_IMPORTED_MODULE_2__.default)(country, metadata);

        if (phoneDigits.indexOf(prefix) !== 0) {
          // If a user tabs into a phone number input field
          // that is `international` and `withCountryCallingCode`,
          // and then starts inputting local phone number digits,
          // the first digit would get "swallowed" if the fix below wasn't implemented.
          // https://gitlab.com/catamphetamine/react-phone-number-input/-/issues/43
          if (phoneDigits && phoneDigits[0] !== '+') {
            phoneDigits = prefix + phoneDigits;
          } else {
            // // Reset phone digits if they don't start with the correct prefix.
            // // Undo the `<input/>` value change if it doesn't.
            if (countryMismatchDetected.current) {// In case of a `country`/`value` mismatch,
              // if it performed an "undo" here, then
              // it wouldn't let a user edit their phone number at all,
              // so this special case at least allows phone number editing
              // when `value` already doesn't match the `country`.
            } else {
              // If it simply did `phoneDigits = prefix` here,
              // then it could have no effect when erasing phone number
              // via Backspace, because `phoneDigits` in `state` wouldn't change
              // as a result, because it was `prefix` and it became `prefix`,
              // so the component wouldn't rerender, and the user would be able
              // to erase the country calling code part, and that part is
              // assumed to be non-eraseable. That's why the component is
              // forcefully rerendered here.
              setPhoneDigits(prefix);
              setValueForPhoneDigits(undefined); // Force a re-render of the `<input/>` with previous `phoneDigits` value.

              return rerender();
            }
          }
        }
      } else {
        // Entering phone number either in "national" format
        // when `country` has been specified, or in "international" format
        // when `country` has been specified but `withCountryCallingCode` hasn't.
        // Therefore, `+` is not allowed.
        if (phoneDigits && phoneDigits[0] === '+') {
          // Remove the `+`.
          phoneDigits = phoneDigits.slice(1);
        }
      }
    } else if (!defaultCountry) {
      // Force a `+` in the beginning of a `value`
      // when no `country` and `defaultCountry` have been specified.
      if (phoneDigits && phoneDigits[0] !== '+') {
        // Prepend a `+`.
        phoneDigits = '+' + phoneDigits;
      }
    } // Convert `phoneDigits` to `value`.


    if (phoneDigits) {
      value = getValueForPhoneDigits(phoneDigits);
    }

    setPhoneDigits(phoneDigits);
    setValueForPhoneDigits(value);
  }, [country, international, withCountryCallingCode, defaultCountry, metadata, setPhoneDigits, setValueForPhoneDigits, rerender, countryMismatchDetected]);
  return [phoneDigits, onSetPhoneDigits];
}
/**
 * Returns phone number input field value for a E.164 phone number `value`.
 * @param  {string} [value]
 * @param  {string} [country]
 * @param  {boolean} [international]
 * @param  {boolean} [withCountryCallingCode]
 * @param  {string} [defaultCountry]
 * @param  {boolean} [useNationalFormatForDefaultCountryValue]
 * @param  {object} metadata
 * @return {string}
 */

function getPhoneDigitsForValue(value, country, international, withCountryCallingCode, defaultCountry, useNationalFormatForDefaultCountryValue, metadata, onCountryMismatch) {
  if (country && international && withCountryCallingCode) {
    var prefix = (0,_helpers_getInternationalPhoneNumberPrefix__WEBPACK_IMPORTED_MODULE_2__.default)(country, metadata);

    if (value) {
      if (value.indexOf(prefix) !== 0) {
        onCountryMismatch(value, country);
      }

      return value;
    }

    return prefix;
  }

  if (!value) {
    return '';
  }

  if (!country && !defaultCountry) {
    return value;
  }

  var asYouType = new libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.AsYouType(undefined, metadata);
  asYouType.input(value);
  var phoneNumber = asYouType.getNumber();

  if (phoneNumber) {
    if (country) {
      if (phoneNumber.country && phoneNumber.country !== country) {
        onCountryMismatch(value, country, phoneNumber.country);
      } else if (phoneNumber.countryCallingCode !== (0,libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.getCountryCallingCode)(country, metadata)) {
        onCountryMismatch(value, country);
      }

      if (international) {
        return phoneNumber.nationalNumber;
      }

      return (0,libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.parseDigits)(phoneNumber.formatNational());
    } else {
      // `phoneNumber.countryCallingCode` is compared here  instead of
      // `phoneNumber.country`, because, for example, a person could have
      // previously input a phone number (in "national" format) that isn't
      // 100% valid for the `defaultCountry`, and if `phoneNumber.country`
      // was compared, then it wouldn't match, and such phone number
      // wouldn't be formatted as a "national" one, and instead would be
      // formatted as an "international" one, confusing the user.
      // Comparing `phoneNumber.countryCallingCode` works around such issues.
      //
      // Example: `defaultCountry="US"` and the `<input/>` is empty.
      // The user inputs: "222 333 4444", which gets formatted to "(222) 333-4444".
      // The user then clicks "Save", the page is refreshed, and the user sees
      // that the `<input/>` value is now "+1 222 333 4444" which confuses the user:
      // the user expected the `<input/>` value to be "(222) 333-4444", same as it
      // was when they've just typed it in. The cause of the issue is that "222 333 4444"
      // is not a valid national number for US, and `phoneNumber.country` is compared
      // instead of `phoneNumber.countryCallingCode`. After the `phoneNumber.country`
      // comparison is replaced with `phoneNumber.countryCallingCode` one, the issue
      // is no longer the case.
      //
      if (phoneNumber.countryCallingCode && phoneNumber.countryCallingCode === (0,libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.getCountryCallingCode)(defaultCountry, metadata) && useNationalFormatForDefaultCountryValue) {
        return (0,libphonenumber_js_core__WEBPACK_IMPORTED_MODULE_1__.parseDigits)(phoneNumber.formatNational());
      }

      return value;
    }
  } else {
    return '';
  }
}
//# sourceMappingURL=usePhoneDigits.js.map

/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZGF0YS5iNDUyMzQ4YjYxMWQ4ZjE0ZGUyZi5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBRWUsU0FBU0ssSUFBVCxPQUE0QztBQUFBOztBQUFBOztBQUFBLE1BQTVCQyxLQUE0QixRQUE1QkEsS0FBNEI7QUFBQSxNQUFyQkMsSUFBcUIsUUFBckJBLElBQXFCO0FBQUEsTUFBZkMsSUFBZSxRQUFmQSxJQUFlO0FBQUEsTUFBVEMsS0FBUyxRQUFUQSxLQUFTO0FBQ3ZELE1BQU1DLE1BQU0sR0FBR1Isc0RBQVMsRUFBeEI7O0FBQ0Esb0JBQTBDQyx3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXBEO0FBQUE7QUFBQSxNQUFPUSxNQUFQO0FBQUEsTUFBZUMsU0FBZjtBQUFBLE1BQTBCQyxZQUExQjs7QUFDQSxrQkFBZ0RaLCtDQUFRLENBQUMsS0FBRCxDQUF4RDtBQUFBLE1BQU9hLGdCQUFQO0FBQUEsTUFBeUJDLG1CQUF6Qjs7QUFDQSxtQkFBa0RkLCtDQUFRLENBQUMsS0FBRCxDQUExRDtBQUFBLE1BQU9lLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBOENoQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEQ7QUFBQSxNQUFPaUIsZUFBUDtBQUFBLE1BQXdCQyxrQkFBeEI7O0FBQ0EsbUJBQW9DbEIsK0NBQVEsQ0FBQ0ssS0FBRCxDQUE1QztBQUFBLE1BQU9jLFVBQVA7QUFBQSxNQUFtQkMsYUFBbkI7O0FBQ0EsbUJBQWtDcEIsK0NBQVEsQ0FBQ08sSUFBRCxDQUExQztBQUFBLE1BQU9jLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQTBCdEIsK0NBQVEsRUFBbEM7QUFBQSxNQUFPdUIsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsTUFBTUMsV0FBVztBQUFBLHNYQUFHLGlCQUFNQyxLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEJDLGNBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFDQWhCLGNBQUFBLFlBQVksQ0FBQyxNQUFELENBQVo7QUFDQUgsY0FBQUEsTUFBTSxDQUFDb0IsSUFBUCxDQUFZLEdBQVo7O0FBSGdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVhKLFdBQVc7QUFBQTtBQUFBO0FBQUEsS0FBakI7O0FBVHVELFdBZXhDSyxXQWZ3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx5WEFldkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JDLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0lDLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWXhCO0FBRHhCLGlCQURiO0FBSUl5QixnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUMsY0FBQUEsR0FEVjs7QUFBQSxvQkFVUUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FWdEI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsNkJBV1FmLGFBWFI7QUFBQTtBQUFBLHFCQVc0QmMsR0FBRyxDQUFDRSxJQUFKLEVBWDVCOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQWZ1RDtBQUFBO0FBQUE7O0FBOEJ2RCxNQUFNQyxXQUFXO0FBQUEsc1hBQUcsa0JBQU1YLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYVyxXQUFXO0FBQUE7QUFBQTtBQUFBLEtBQWpCOztBQUVBLE1BQU1DLFVBQVU7QUFBQSxzWEFBRyxrQkFBTVosS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDZkEsY0FBQUEsS0FBSyxDQUFDYSxjQUFOOztBQURlLG9CQUVYYixLQUFLLENBQUNjLE1BQU4sQ0FBYUMsUUFBYixDQUFzQkMsS0FBdEIsS0FBZ0NoQixLQUFLLENBQUNjLE1BQU4sQ0FBYUcsY0FBYixDQUE0QkQsS0FGakQ7QUFBQTtBQUFBO0FBQUE7O0FBR1h4QixjQUFBQSxrQkFBa0IsQ0FBQyxJQUFELENBQWxCO0FBSFc7O0FBQUE7QUFBQTtBQUFBLHFCQU1HYSxLQUFLLENBQ25CLDZCQURtQixFQUVuQjtBQUNJYSxnQkFBQUEsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNqQkMsa0JBQUFBLFFBQVEsRUFBRXJCLEtBQUssQ0FBQ2MsTUFBTixDQUFhTyxRQUFiLENBQXNCTCxLQURmO0FBRWpCTSxrQkFBQUEsS0FBSyxFQUFFdEIsS0FBSyxDQUFDYyxNQUFOLENBQWFRLEtBQWIsQ0FBbUJOLEtBRlQ7QUFHakJELGtCQUFBQSxRQUFRLEVBQUVmLEtBQUssQ0FBQ2MsTUFBTixDQUFhQyxRQUFiLENBQXNCQyxLQUhmO0FBSWpCTyxrQkFBQUEsU0FBUyxFQUFFLElBSk07QUFLakJDLGtCQUFBQSxPQUFPLEVBQUUsS0FMUTtBQU1qQkMsa0JBQUFBLElBQUksRUFBRTtBQUFFQyxvQkFBQUEsRUFBRSxFQUFFO0FBQU47QUFOVyxpQkFBZixDQURWO0FBU0lwQixnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVl4QjtBQUZ4QixpQkFUYjtBQWNJeUIsZ0JBQUFBLE1BQU0sRUFBRTtBQWRaLGVBRm1CLENBTlI7O0FBQUE7QUFNVEMsY0FBQUEsR0FOUzs7QUEwQmYsa0JBQUlBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CTCxnQkFBQUEsV0FBVztBQUNYaEIsZ0JBQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDSDs7QUE3QmM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBVndCLFVBQVU7QUFBQTtBQUFBO0FBQUEsS0FBaEI7O0FBaEN1RCxXQWdFeENlLFVBaEV3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx3WEFnRXZELGtCQUEwQkMsTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0J2QixLQUFLLENBQ25CLGlDQUFpQ3VCLE1BRGQsRUFFbkI7QUFDSXRCLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWXhCO0FBRHhCLGlCQURiO0FBS0l5QixnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUMsY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJMLGdCQUFBQSxXQUFXO0FBQ2Q7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FoRXVEO0FBQUE7QUFBQTs7QUFpRnZESCxFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWXZCLEtBQVo7QUFDQSxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGtEQUFEO0FBQUEsNkJBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFJSTtBQUFLLGVBQVMsRUFBQyxpQkFBZjtBQUFBLDZCQUNJO0FBQUssaUJBQVMsRUFBQyxnREFBZjtBQUFBLGdDQUNJO0FBQUEsb0NBQWtCQyxJQUFJLENBQUN5QyxRQUF2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFFSTtBQUFRLGlCQUFPLEVBQUV0QixXQUFqQjtBQUE4QixtQkFBUyxFQUFDLHdEQUF4QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkosZUFXSTtBQUFLLGVBQVMsRUFBQyxlQUFmO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsS0FBZjtBQUFBLGlDQUNJO0FBQVEsbUJBQU8sRUFBRTtBQUFBLHFCQUFNWCxtQkFBbUIsQ0FBQyxJQUFELENBQXpCO0FBQUEsYUFBakI7QUFBa0QscUJBQVMsRUFBQyx3REFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQURKLGVBSUk7QUFBSyxtQkFBUyxFQUFDLCtDQUFmO0FBQUEsaUNBQ0k7QUFBTyxxQkFBUyxFQUFDLHFDQUFqQjtBQUFBLG9DQUNJO0FBQU8sdUJBQVMsRUFBQyxZQUFqQjtBQUFBLHFDQUNJO0FBQUEsd0NBQ0k7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREosZUFJSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFKSixlQU9JO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQSixlQVVJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBaUJJO0FBQU8sdUJBQVMsRUFBQyxtQ0FBakI7QUFBQSx3QkFHUUssVUFBVSxDQUFDb0MsR0FBWCxDQUFlLFVBQUNDLEdBQUQsRUFBTUMsS0FBTjtBQUFBLG9DQUNYO0FBQUEseUNBQ0k7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNkJBQWQ7QUFBQSw2Q0FDSTtBQUFLLGlDQUFTLEVBQUMsbUJBQWY7QUFBQSxnREFDSTtBQUFLLG1DQUFTLEVBQUMseUJBQWY7QUFBQSxpREFDSTtBQUFLLGlDQUFLLEVBQUMsNEJBQVg7QUFBd0MsZ0NBQUksRUFBQyxNQUE3QztBQUFvRCxtQ0FBTyxFQUFDLFdBQTVEO0FBQXdFLGtDQUFNLEVBQUMsY0FBL0U7QUFBQSxtREFDSTtBQUFNLDJDQUFhLEVBQUMsT0FBcEI7QUFBNEIsNENBQWMsRUFBQyxPQUEzQztBQUFtRCx5Q0FBVyxFQUFDLEdBQS9EO0FBQW1FLCtCQUFDLEVBQUM7QUFBckU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURKLGVBTUk7QUFBSyxtQ0FBUyxFQUFDLE1BQWY7QUFBQSxvQ0FBdUJELEdBQUcsQ0FBQ1Q7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBV0k7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsZ0NBQTBEUyxHQUFHLENBQUNSO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBWEosZUFZSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBWkosZUFhSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSxnQ0FBMERRLEdBQUcsQ0FBQ1QsUUFBSixJQUFnQnpDLElBQUksQ0FBQ3lDLFFBQXJCLEdBQWdDLElBQWhDLGdCQUF1QztBQUFBLCtDQUFFO0FBQUcsOEJBQUksRUFBQyxvQkFBUjtBQUE2QixpQ0FBTyxFQUFFO0FBQUEsbUNBQU1NLFVBQVUsQ0FBQ0csR0FBRyxDQUFDSixFQUFMLENBQWhCO0FBQUEsMkJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUY7QUFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFiSjtBQUFBLHFCQUFRLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlDQURXO0FBQUEsZUFBZjtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUFzREk7QUFBSyxpQkFBUyxFQUFDLFdBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsS0FBZjtBQUFBLGlDQUNJO0FBQVEsbUJBQU8sRUFBRTtBQUFBLHFCQUFNcEMsb0JBQW9CLENBQUMsSUFBRCxDQUExQjtBQUFBLGFBQWpCO0FBQW1ELHFCQUFTLEVBQUMsd0RBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQUlJO0FBQUssbUJBQVMsRUFBQywrQ0FBZjtBQUFBLGlDQUNJO0FBQU8scUJBQVMsRUFBQyxxQ0FBakI7QUFBQSxvQ0FDSTtBQUFPLHVCQUFTLEVBQUMsWUFBakI7QUFBQSxxQ0FDSTtBQUFBLHdDQUNJO0FBQUksdUJBQUssRUFBQyxLQUFWO0FBQWdCLDJCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQURKLGVBSUk7QUFBSSx1QkFBSyxFQUFDLEtBQVY7QUFBZ0IsMkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBSkosZUFPSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFVSTtBQUFJLHVCQUFLLEVBQUMsS0FBVjtBQUFnQiwyQkFBUyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQWlCSTtBQUFPLHVCQUFTLEVBQUMsbUNBQWpCO0FBQUEsd0JBR1FLLFNBQVMsQ0FBQ2tDLEdBQVYsQ0FBYyxVQUFDRyxHQUFELEVBQU1ELEtBQU47QUFBQSxvQ0FDVjtBQUFBLHlDQUNJO0FBQUEsNENBQ0k7QUFBSSwrQkFBUyxFQUFDLDZCQUFkO0FBQUEsZ0NBQTZDQyxHQUFHLENBQUNDO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFFSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSxnQ0FBMERELEdBQUcsQ0FBQ0U7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFGSixlQUdJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFISixlQUlJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFKSjtBQUFBLHFCQUFRLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlDQURVO0FBQUEsZUFBZDtBQUhSO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQVhKLEVBNkdLL0MsZ0JBQWdCLGdCQUNiO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLHVIQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHNHQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBGQUFmO0FBQUEscUNBQ0k7QUFBTSx5QkFBUyxFQUFDLGVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQU1JO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLHFDQUNJO0FBQU0sd0JBQVEsRUFBRXlCLFVBQWhCO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsVUFBZjtBQUEwQiw2QkFBUyxFQUFDLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsVUFBdEI7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxvQkFGaEI7QUFFa0MsNEJBQVE7QUFGMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREosZUFPSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQU8sMkJBQU8sRUFBQyxPQUFmO0FBQXVCLDZCQUFTLEVBQUMsMEJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBRUk7QUFBTyx3QkFBSSxFQUFDLE9BQVo7QUFBb0Isc0JBQUUsRUFBQyxPQUF2QjtBQUNJLDZCQUFTLEVBQUMsMEVBRGQ7QUFFSSwrQkFBVyxFQUFDLFFBRmhCO0FBRXlCLDRCQUFRO0FBRmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQVBKLGVBY0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFLLDZCQUFTLEVBQUMsZUFBZjtBQUFBLDRDQUNJO0FBQUssK0JBQVMsRUFBQyxNQUFmO0FBQUEsOENBQ0k7QUFBTywrQkFBTyxFQUFDLFVBQWY7QUFBMEIsaUNBQVMsRUFBQywwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREosZUFFSTtBQUFPLDRCQUFJLEVBQUMsVUFBWjtBQUF1QiwwQkFBRSxFQUFDLFVBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsT0FGaEI7QUFFd0IsZ0NBQVE7QUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREosZUFPSTtBQUFLLCtCQUFTLEVBQUMsTUFBZjtBQUFBLDhDQUNJO0FBQU8sK0JBQU8sRUFBQyxnQkFBZjtBQUFnQyxpQ0FBUyxFQUFDLDBCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFESixlQUVJO0FBQU8sNEJBQUksRUFBQyxVQUFaO0FBQXVCLDBCQUFFLEVBQUMsZ0JBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsZUFGaEI7QUFFZ0MsZ0NBQVE7QUFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLEVBZUtyQixlQUFlLGdCQUNaO0FBQUssNkJBQVMsRUFBQyxtQkFBZjtBQUFBLDJDQUNJO0FBQUcsMEJBQUksRUFBQyxHQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFEWSxHQUdILElBbEJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZEosZUFrQ0k7QUFBSywyQkFBUyxFQUFDLHdGQUFmO0FBQUEsMENBQ0k7QUFBUSwyQkFBTyxFQUFFO0FBQUEsNkJBQU1ILG1CQUFtQixDQUFDLEtBQUQsQ0FBekI7QUFBQSxxQkFBakI7QUFBbUQsNkJBQVMsRUFBQywyREFBN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFRLDZCQUFTLEVBQUMsd0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFsQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBcURJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FyREo7QUFBQSxvQkFEYSxHQXdEYixJQXJLUixFQXdLS0MsaUJBQWlCLGdCQUNkO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLHVIQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHNHQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBGQUFmO0FBQUEscUNBQ0k7QUFBTSx5QkFBUyxFQUFDLGVBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQU1JO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLHFDQUNJO0FBQU0sd0JBQVEsRUFBRXNCLFdBQWhCO0FBQUEsd0NBQ0k7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsTUFBZjtBQUFzQiw2QkFBUyxFQUFDLDBCQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsTUFBdEI7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxNQUZoQjtBQUV1Qiw0QkFBUTtBQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESixlQU9JO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBdUIsNkJBQVMsRUFBQywwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSSw4REFBQyxtRUFBRDtBQUNJLCtCQUFXLEVBQUMsb0JBRGhCO0FBRUkseUJBQUssRUFBRWQsS0FGWDtBQUdJLDRCQUFRLEVBQUVDO0FBSGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFnQkk7QUFBSywyQkFBUyxFQUFDLHdGQUFmO0FBQUEsMENBQ0k7QUFBUSwyQkFBTyxFQUFFO0FBQUEsNkJBQU1SLG9CQUFvQixDQUFDLEtBQUQsQ0FBMUI7QUFBQSxxQkFBakI7QUFBb0QsNkJBQVMsRUFBQywyREFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFRLDZCQUFTLEVBQUMsd0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBbUNJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FuQ0o7QUFBQSxvQkFEYyxHQXNDZCxJQTlNUjtBQUFBLGtCQURKO0FBa05IOztHQXBTdUJaO1VBQ0xILG9EQUMyQkM7OztLQUZ0QkU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BrQztBQUMxRDtBQVVzQjtBQUN0QjtBQUMwRDtBQUMxRDtBQUNBO0FBQ0E7QUFDQSxXQUFXLGdFQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBLCtEQUFlLHVFQUFXLENBQUMsZ0VBQVEsQ0FBQztBQUNwQztBQUNPO0FBQ1AsYUFBYSx5REFBaUI7QUFDOUI7QUFDQTtBQUNPO0FBQ1AsYUFBYSwwREFBa0I7QUFDL0I7QUFDQTtBQUNPO0FBQ1AsYUFBYSw4REFBc0I7QUFDbkM7QUFDQTtBQUNPO0FBQ1AsYUFBYSwyREFBbUI7QUFDaEM7QUFDQTtBQUNPO0FBQ1AsYUFBYSw4REFBc0I7QUFDbkM7QUFDQTtBQUNPO0FBQ1AsYUFBYSxxREFBYTtBQUMxQjtBQUNBO0FBQ087QUFDUCxhQUFhLDhEQUFzQjtBQUNuQztBQUNBO0FBQ087QUFDUCxhQUFhLDJEQUFtQjtBQUNoQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3JEQSxzQkFBc0IsZ0RBQWdELGdCQUFnQixzQkFBc0IsT0FBTywyQkFBMkIsMEJBQTBCLHlEQUF5RCxpQ0FBaUMsa0JBQWtCOztBQUVwUixrQ0FBa0M7O0FBRWxDLDhCQUE4Qjs7QUFFOUIseUNBQXlDLHlHQUF5RyxVQUFVLGVBQWUsZUFBZSxnQkFBZ0Isb0JBQW9CLE1BQU0sMENBQTBDLCtCQUErQixhQUFhLHFCQUFxQix1Q0FBdUMsY0FBYyxXQUFXLFlBQVksVUFBVSxNQUFNLG1EQUFtRCxVQUFVLHNCQUFzQjs7QUFFOWYsZ0NBQWdDOztBQUVoQyxzREFBc0QsK0JBQStCLDhEQUE4RCxZQUFZLG9DQUFvQyw2REFBNkQsWUFBWSw2QkFBNkIsT0FBTywyQkFBMkIsMENBQTBDLHdFQUF3RSwrQkFBK0I7O0FBRTVkLDJEQUEyRCwrQkFBK0IsaUJBQWlCLHNDQUFzQyxZQUFZLFlBQVksdUJBQXVCLE9BQU8scUJBQXFCLDBDQUEwQyw2QkFBNkI7O0FBRXpRO0FBQ1M7QUFDVzs7QUFFOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLHdCQUF3Qix3REFBYztBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTs7QUFFQSxTQUFTLDBEQUFtQix1QkFBdUI7QUFDbkQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHO0FBQ0g7O0FBRUEsYUFBYSx1REFBZ0I7QUFDN0I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVMsMERBQWdCOztBQUV6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVksbUVBQXlCOztBQUVyQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVcsMERBQWdCOztBQUUzQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGtCQUFrQiwwREFBZ0I7O0FBRWxDO0FBQ0EsZ0VBQWdFLEtBQUs7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxvREFBb0QsS0FBSztBQUN6RDtBQUNBO0FBQ0E7QUFDQSxpQkFBaUIsd0RBQWM7O0FBRS9CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLDBCQUEwQix3REFBYzs7QUFFeEM7QUFDQTtBQUNBO0FBQ0E7QUFDQSxhQUFhLDBFQUFnQzs7QUFFN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsMkNBQTJDLG1FQUF5Qjs7QUFFcEU7QUFDQTtBQUNBO0FBQ0EsWUFBWSxxRUFBMkI7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0RBQWUsVUFBVSxFQUFDO0FBQzFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoSkEsc0JBQXNCLGdEQUFnRCxnQkFBZ0Isc0JBQXNCLE9BQU8sMkJBQTJCLDBCQUEwQix5REFBeUQsaUNBQWlDLGtCQUFrQjs7QUFFcFIsc0RBQXNELCtCQUErQiw4REFBOEQsWUFBWSxvQ0FBb0MsNkRBQTZELFlBQVksNkJBQTZCLE9BQU8sMkJBQTJCLDBDQUEwQyx3RUFBd0UsK0JBQStCOztBQUU1ZCwyREFBMkQsK0JBQStCLGlCQUFpQixzQ0FBc0MsWUFBWSxZQUFZLHVCQUF1QixPQUFPLHFCQUFxQiwwQ0FBMEMsNkJBQTZCOztBQUV6UTtBQUNTO0FBQ0k7QUFDRDtBQUNBO0FBQy9CO0FBQ1A7QUFDQTtBQUNBOztBQUVBLFdBQVcsMERBQW1CLENBQUMsZ0RBQVcsYUFBYTtBQUN2RDtBQUNBLDhCQUE4QixnREFBVSxHQUFHLGdEQUFVO0FBQ3JELEtBQUs7QUFDTDs7QUFFQSxlQUFlLHVEQUFnQjtBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVUsMERBQWdCOztBQUUxQjtBQUNBO0FBQ0E7QUFDQSxrQkFBa0IsMERBQWdCOztBQUVsQztBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUErQixNQUFNO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBLGdCQUFnQixtRUFBeUI7O0FBRXpDO0FBQ0E7QUFDQTtBQUNBLGNBQWMscUVBQTJCO0FBQ3pDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtEQUFlLGFBQWEsRUFBQztBQUM3Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekVBLGtDQUFrQzs7QUFFbEMsOEJBQThCOztBQUU5Qix5Q0FBeUMseUdBQXlHLFVBQVUsZUFBZSxlQUFlLGdCQUFnQixvQkFBb0IsTUFBTSwwQ0FBMEMsK0JBQStCLGFBQWEscUJBQXFCLHVDQUF1QyxjQUFjLFdBQVcsWUFBWSxVQUFVLE1BQU0sbURBQW1ELFVBQVUsc0JBQXNCOztBQUU5ZixnQ0FBZ0M7O0FBRWlDO0FBQ3NCO0FBQ0s7QUFDNUY7QUFDQTtBQUNBO0FBQ0E7O0FBRWU7QUFDZjs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsZ0NBQWdDLDZDQUFNOztBQUV0QztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLDBFQUEwRSxhQUFhO0FBQ3ZGO0FBQ0E7O0FBRUE7QUFDQSxLQUFLO0FBQ0wsS0FBSzs7O0FBR0wsa0JBQWtCLCtDQUFRO0FBQzFCO0FBQ0E7QUFDQSxzQ0FBc0M7OztBQUd0QyxtQkFBbUIsK0NBQVE7QUFDM0I7QUFDQTtBQUNBLDZDQUE2Qzs7O0FBRzdDLG1CQUFtQiwrQ0FBUTtBQUMzQjtBQUNBO0FBQ0Esc0NBQXNDOzs7QUFHdEMsbUJBQW1CLCtDQUFRO0FBQzNCO0FBQ0E7QUFDQSw4Q0FBOEM7OztBQUc5QyxtQkFBbUIsK0NBQVE7QUFDM0I7QUFDQTtBQUNBOztBQUVBLGlCQUFpQixrREFBVztBQUM1QixnQ0FBZ0M7QUFDaEMsR0FBRzs7QUFFSDtBQUNBLHdCQUF3Qiw2REFBUztBQUNqQyxxRkFBcUYsNkVBQXFCO0FBQzFHLDZDQUE2Qzs7QUFFN0M7QUFDQTtBQUNBO0FBQ0EsSUFBSTtBQUNKOzs7QUFHQSxFQUFFLGdEQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLFlBQVk7O0FBRWYsRUFBRSxnREFBUztBQUNYO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxPQUFPOztBQUVQOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsR0FBRyxjQUFjOztBQUVqQixFQUFFLGdEQUFTO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQSxHQUFHLHFCQUFxQjs7QUFFeEIsRUFBRSxnREFBUztBQUNYO0FBQ0E7QUFDQTtBQUNBLEdBQUc7QUFDSCx5QkFBeUIsa0RBQVc7QUFDcEM7O0FBRUE7QUFDQTtBQUNBO0FBQ0EscUJBQXFCLG1GQUFpQzs7QUFFdEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFlBQVk7QUFDWjtBQUNBO0FBQ0Esa0RBQWtEO0FBQ2xEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsY0FBYztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLGlEQUFpRDs7QUFFakQ7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTTtBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLE1BQU07OztBQUdOO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0EsR0FBRztBQUNIO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsWUFBWSxRQUFRO0FBQ3BCLFlBQVksUUFBUTtBQUNwQixZQUFZLFNBQVM7QUFDckIsWUFBWSxTQUFTO0FBQ3JCLFlBQVksUUFBUTtBQUNwQixZQUFZLFNBQVM7QUFDckIsWUFBWSxRQUFRO0FBQ3BCLFlBQVk7QUFDWjs7QUFFQTtBQUNBO0FBQ0EsaUJBQWlCLG1GQUFpQzs7QUFFbEQ7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsc0JBQXNCLDZEQUFTO0FBQy9CO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQSxRQUFRLDRDQUE0Qyw2RUFBcUI7QUFDekU7QUFDQTs7QUFFQTtBQUNBO0FBQ0E7O0FBRUEsYUFBYSxtRUFBVztBQUN4QixNQUFNO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtFQUErRSw2RUFBcUI7QUFDcEcsZUFBZSxtRUFBVztBQUMxQjs7QUFFQTtBQUNBO0FBQ0EsSUFBSTtBQUNKO0FBQ0E7QUFDQTtBQUNBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2RhdGEuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1waG9uZS1udW1iZXItaW5wdXQvaW5wdXQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1waG9uZS1udW1iZXItaW5wdXQvbW9kdWxlcy9QaG9uZUlucHV0LmpzIiwid2VicGFjazovL19OX0UvLi9ub2RlX21vZHVsZXMvcmVhY3QtcGhvbmUtbnVtYmVyLWlucHV0L21vZHVsZXMvUGhvbmVJbnB1dEJyb3dzZXIuanMiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9yZWFjdC1waG9uZS1udW1iZXItaW5wdXQvbW9kdWxlcy91c2VQaG9uZURpZ2l0cy5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZCBmcm9tICduZXh0L2hlYWQnXHJcbmltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ25leHQvcm91dGVyJ1xyXG5pbXBvcnQgeyB1c2VDb29raWVzIH0gZnJvbSBcInJlYWN0LWNvb2tpZVwiXHJcbmltcG9ydCBQaG9uZUlucHV0IGZyb20gJ3JlYWN0LXBob25lLW51bWJlci1pbnB1dC9pbnB1dCdcclxuaW1wb3J0ICdyZWFjdC1waG9uZS1udW1iZXItaW5wdXQvc3R5bGUuY3NzJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gRGF0YSh7IHVzZXJzLCB1c2VyLCB0ZWxzLCB0b2tlbiB9KSB7XHJcbiAgICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxyXG4gICAgY29uc3QgW2Nvb2tpZSwgc2V0Q29va2llLCByZW1vdmVDb29raWVdID0gdXNlQ29va2llcyhbXCJ1c2VyXCJdKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbE5ld1VzZXIsIHNldFNob3dNb2RhbE5ld1VzZXJdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW3Nob3dNb2RhbE5ld1Bob25lLCBzZXRTaG93TW9kYWxOZXdQaG9uZV0gPSB1c2VTdGF0ZShmYWxzZSk7XHJcbiAgICBjb25zdCBbaW52YWxpZFBhc3N3b3JkLCBzZXRJbnZhbGlkUGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgW2xvY2FsVXNlcnMsIHNldExvY2FsVXNlcnNdID0gdXNlU3RhdGUodXNlcnMpXHJcbiAgICBjb25zdCBbbG9jYWxUZWxzLCBzZXRMb2NhbFRlbHNdID0gdXNlU3RhdGUodGVscylcclxuICAgIGNvbnN0IFtwaG9uZSwgc2V0UGhvbmVdID0gdXNlU3RhdGUoKVxyXG4gICAgY29uc3Qgb25DbGlja1NhaXIgPSBhc3luYyBldmVudCA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJTYWlyXCIpXHJcbiAgICAgICAgcmVtb3ZlQ29va2llKFwidXNlclwiKVxyXG4gICAgICAgIHJvdXRlci5wdXNoKCcvJylcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZWxvYWRVc2VycygpIHtcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICBzZXRMb2NhbFVzZXJzKGF3YWl0IHJlcy5qc29uKCkpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuICAgIGNvbnN0IGFkZE5ld1Bob25lID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgfVxyXG4gICAgY29uc3QgYWRkTmV3VXNlciA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgaWYgKGV2ZW50LnRhcmdldC5wYXNzd29yZC52YWx1ZSAhPT0gZXZlbnQudGFyZ2V0LnBhc3N3b3JkcmVwZWF0LnZhbHVlKSB7XHJcbiAgICAgICAgICAgIHNldEludmFsaWRQYXNzd29yZCh0cnVlKVxyXG4gICAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMnLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcm5hbWU6IGV2ZW50LnRhcmdldC51c2VybmFtZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBlbWFpbDogZXZlbnQudGFyZ2V0LmVtYWlsLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgY29uZmlybWVkOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrZWQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgICAgIHJvbGU6IHsgaWQ6IDEgfVxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMSkge1xyXG4gICAgICAgICAgICByZWxvYWRVc2VycygpXHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVVzZXIodXNlcklEKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMvJyArIHVzZXJJRCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJ1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZyh1c2VycylcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8dGl0bGU+RGVzYWZpbyAtIEFyZWEgUmVzdHJpdGE8L3RpdGxlPlxyXG4gICAgICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImp1c3RpZnktYmV0d2VlbiB3LWZ1bGwgZmxleCBqdXN0ZnktYmV0d2VlbiBwLTNcIj5cclxuICAgICAgICAgICAgICAgICAgICA8c3Bhbj5CZW0gdmluZG8sIHt1c2VyLnVzZXJuYW1lfSEhITwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9e29uQ2xpY2tTYWlyfSBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWlyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWxOZXdVc2VyKHRydWUpfSBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5Ob3ZvIFVzdcOhcmlvPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTUgYm9yZGVyIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb21lIGRlIFVzdcOhcmlvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRS1tYWlsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsVXNlcnMubWFwKCh1c3IsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9XCJ7IGluZGV4IH1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBoLTEwIHctMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHN2ZyB4bWxucz1cImh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnXCIgZmlsbD1cIm5vbmVcIiB2aWV3Qm94PVwiMCAwIDI0IDI0XCIgc3Ryb2tlPVwiY3VycmVudENvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xNiA3YTQgNCAwIDExLTggMCA0IDQgMCAwMTggMHpNMTIgMTRhNyA3IDAgMDAtNyA3aDE0YTcgNyAwIDAwLTctN3pcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTNcIj57dXNyLnVzZXJuYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3Vzci5lbWFpbH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPkVkaXRhcjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3Vzci51c2VybmFtZSA9PSB1c2VyLnVzZXJuYW1lID8gbnVsbCA6IDw+PGEgaHJlZj0namF2YXNjcmlwdDp2b2lkKDApJyBvbkNsaWNrPXsoKSA9PiBkZWxldGVVc2VyKHVzci5pZCl9PkV4Y2x1aXI8L2E+PC8+fTwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3RhYmxlPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd01vZGFsTmV3UGhvbmUodHJ1ZSl9IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPk5vdm8gVGVsZWZvbmU8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNSBib3JkZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUZWxlZm9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aGVhZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2NhbFRlbHMubWFwKCh0ZWwsIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9XCJ7IGluZGV4IH1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcFwiPnt0ZWwubm9tZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt0ZWwudGVsZWZvbmV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj5FZGl0YXI8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPkV4Y2x1aXI8L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBOZXdVc2VyICovfVxyXG4gICAgICAgICAgICB7c2hvd01vZGFsTmV3VXNlciA/IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZmxleCBvdmVyZmxvdy14LWhpZGRlbiBvdmVyZmxvdy15LWF1dG8gZml4ZWQgaW5zZXQtMCB6LTUwIG91dGxpbmUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWF1dG8gbXktMiBteC1hdXRvIG1heC13LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMCByb3VuZGVkLWxnIHNoYWRvdy1sZyByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIHctZnVsbCBiZy13aGl0ZSBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBwLTUgYm9yZGVyLWIgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC10XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vdm8gVXN1w6FyaW9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgcC02IGZsZXgtYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Zm9ybSBvblN1Ym1pdD17YWRkTmV3VXNlcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXJuYW1lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+Tm9tZSBkZSBVc3XDoXJpbzo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwidXNlcm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWUgZGUgVXN1w6FyaW9cIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+RS1tYWlsOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJlbWFpbFwiIGlkPVwiZW1haWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkUtbWFpbFwiIHJlcXVpcmVkIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbWItNic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtci0yJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5TZW5oYTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJTZW5oYVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbWwtMic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkcmVwZWF0XCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+UmVwaXRhIGEgc2VuaGE6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBpZD1cInBhc3N3b3JkcmVwZWF0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiUmVwaXRhIGEgZW5oYVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpbnZhbGlkUGFzc3dvcmQgP1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTEgdGV4dC1yZWQtNDAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiPkFzIHNlbmhhcyBkaWdpdGFkYXMgc8OjbyBkaWZlcmVudGVzPC9hPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj4gOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC1iXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBzZXRTaG93TW9kYWxOZXdVc2VyKGZhbHNlKX0gY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIG14LTIgZm9udC1ib2xkXCI+RmVjaGFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWx2YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTI1IGZpeGVkIGluc2V0LTAgei00MCBiZy1ibGFja1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgey8qIE1vZGFsIE5ld1Bob25lICovfVxyXG4gICAgICAgICAgICB7c2hvd01vZGFsTmV3UGhvbmUgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwianVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGZsZXggb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIGZpeGVkIGluc2V0LTAgei01MCBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1hdXRvIG15LTIgbXgtYXV0byBtYXgtdy0zeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCB3LWZ1bGwgYmctd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcC01IGJvcmRlci1iIGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb3ZvIFRlbGVmb25lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiBmbGV4LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e2FkZE5ld1Bob25lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmFtZVwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPk5vbWU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWVcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+VGVsZWZvbmU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmVJbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkVudGVyIHBob25lIG51bWJlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFBob25lfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1lbmQgcHQtNiBib3JkZXItdCBib3JkZXItc29saWQgYm9yZGVyLWJsdWVHcmF5LTIwMCByb3VuZGVkLWJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dNb2RhbE5ld1Bob25lKGZhbHNlKX0gY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIG14LTIgZm9udC1ib2xkXCI+RmVjaGFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWx2YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTI1IGZpeGVkIGluc2V0LTAgei00MCBiZy1ibGFja1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyhjdHgsIHJlcSkge1xyXG4gICAgaWYgKCFjdHgucmVxLmNvb2tpZXMudXNlcilcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICByZWRpcmVjdDoge1xyXG4gICAgICAgICAgICAgICAgcGVybWFuZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uOiBcIi9cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcHJvcHM6IHt9LFxyXG4gICAgICAgIH07XHJcbiAgICBjb25zdCB0b2tlbiA9IEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpLnRva2VuXHJcbiAgICBjb25zdCB1c2VyaWQgPSBKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS51c2VyaWRcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMnLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGlmIChyZXMuc3RhdHVzICE9IDIwMCkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHJlZGlyZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBwZXJtYW5lbnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb246IFwiL2xvZ2luXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHByb3BzOiB7fSxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlc1RlbCA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhP3VzZXJzX3Blcm1pc3Npb25zX3VzZXIuaWQ9JyArIHVzZXJpZCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBjb25zdCB1c2VycyA9IGF3YWl0IHJlcy5qc29uKClcclxuICAgIGNvbnN0IHRlbHMgPSBhd2FpdCByZXNUZWwuanNvbigpXHJcbiAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcilcclxuICAgIGNvbnNvbGUubG9nKEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpLnRva2VuKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBwcm9wczoge1xyXG4gICAgICAgICAgICB1c2VycyxcclxuICAgICAgICAgICAgdXNlcixcclxuICAgICAgICAgICAgdGVscyxcclxuICAgICAgICAgICAgdG9rZW5cclxuICAgICAgICB9LFxyXG5cclxuICAgIH1cclxufSIsImltcG9ydCBtZXRhZGF0YSBmcm9tICdsaWJwaG9uZW51bWJlci1qcy9tZXRhZGF0YS5taW4uanNvbidcclxuXHJcbmltcG9ydCB7XHJcblx0cGFyc2VQaG9uZU51bWJlciBhcyBfcGFyc2VQaG9uZU51bWJlcixcclxuXHRmb3JtYXRQaG9uZU51bWJlciBhcyBfZm9ybWF0UGhvbmVOdW1iZXIsXHJcblx0Zm9ybWF0UGhvbmVOdW1iZXJJbnRsIGFzIF9mb3JtYXRQaG9uZU51bWJlckludGwsXHJcblx0aXNWYWxpZFBob25lTnVtYmVyIGFzIF9pc1ZhbGlkUGhvbmVOdW1iZXIsXHJcblx0aXNQb3NzaWJsZVBob25lTnVtYmVyIGFzIF9pc1Bvc3NpYmxlUGhvbmVOdW1iZXIsXHJcblx0Z2V0Q291bnRyaWVzIGFzIF9nZXRDb3VudHJpZXMsXHJcblx0Z2V0Q291bnRyeUNhbGxpbmdDb2RlIGFzIF9nZXRDb3VudHJ5Q2FsbGluZ0NvZGUsXHJcblx0aXNTdXBwb3J0ZWRDb3VudHJ5IGFzIF9pc1N1cHBvcnRlZENvdW50cnlcclxufSBmcm9tICcuLi9jb3JlL2luZGV4J1xyXG5cclxuaW1wb3J0IHsgY3JlYXRlSW5wdXQgfSBmcm9tICcuLi9tb2R1bGVzL1Bob25lSW5wdXRCcm93c2VyJ1xyXG5cclxuZnVuY3Rpb24gY2FsbChmdW5jLCBfYXJndW1lbnRzKSB7XHJcblx0dmFyIGFyZ3MgPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChfYXJndW1lbnRzKVxyXG5cdGFyZ3MucHVzaChtZXRhZGF0YSlcclxuXHRyZXR1cm4gZnVuYy5hcHBseSh0aGlzLCBhcmdzKVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjcmVhdGVJbnB1dChtZXRhZGF0YSlcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVBob25lTnVtYmVyKCkge1xyXG5cdHJldHVybiBjYWxsKF9wYXJzZVBob25lTnVtYmVyLCBhcmd1bWVudHMpXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRQaG9uZU51bWJlcigpIHtcclxuXHRyZXR1cm4gY2FsbChfZm9ybWF0UGhvbmVOdW1iZXIsIGFyZ3VtZW50cylcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGZvcm1hdFBob25lTnVtYmVySW50bCgpIHtcclxuXHRyZXR1cm4gY2FsbChfZm9ybWF0UGhvbmVOdW1iZXJJbnRsLCBhcmd1bWVudHMpXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBpc1ZhbGlkUGhvbmVOdW1iZXIoKSB7XHJcblx0cmV0dXJuIGNhbGwoX2lzVmFsaWRQaG9uZU51bWJlciwgYXJndW1lbnRzKVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNQb3NzaWJsZVBob25lTnVtYmVyKCkge1xyXG5cdHJldHVybiBjYWxsKF9pc1Bvc3NpYmxlUGhvbmVOdW1iZXIsIGFyZ3VtZW50cylcclxufVxyXG5cclxuZXhwb3J0IGZ1bmN0aW9uIGdldENvdW50cmllcygpIHtcclxuXHRyZXR1cm4gY2FsbChfZ2V0Q291bnRyaWVzLCBhcmd1bWVudHMpXHJcbn1cclxuXHJcbmV4cG9ydCBmdW5jdGlvbiBnZXRDb3VudHJ5Q2FsbGluZ0NvZGUoKSB7XHJcblx0cmV0dXJuIGNhbGwoX2dldENvdW50cnlDYWxsaW5nQ29kZSwgYXJndW1lbnRzKVxyXG59XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gaXNTdXBwb3J0ZWRDb3VudHJ5KCkge1xyXG5cdHJldHVybiBjYWxsKF9pc1N1cHBvcnRlZENvdW50cnksIGFyZ3VtZW50cylcclxufSIsImZ1bmN0aW9uIF9leHRlbmRzKCkgeyBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gKHRhcmdldCkgeyBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykgeyB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldOyBmb3IgKHZhciBrZXkgaW4gc291cmNlKSB7IGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc291cmNlLCBrZXkpKSB7IHRhcmdldFtrZXldID0gc291cmNlW2tleV07IH0gfSB9IHJldHVybiB0YXJnZXQ7IH07IHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpOyB9XG5cbmZ1bmN0aW9uIF9zbGljZWRUb0FycmF5KGFyciwgaSkgeyByZXR1cm4gX2FycmF5V2l0aEhvbGVzKGFycikgfHwgX2l0ZXJhYmxlVG9BcnJheUxpbWl0KGFyciwgaSkgfHwgX25vbkl0ZXJhYmxlUmVzdCgpOyB9XG5cbmZ1bmN0aW9uIF9ub25JdGVyYWJsZVJlc3QoKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlXCIpOyB9XG5cbmZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXlMaW1pdChhcnIsIGkpIHsgaWYgKCEoU3ltYm9sLml0ZXJhdG9yIGluIE9iamVjdChhcnIpIHx8IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChhcnIpID09PSBcIltvYmplY3QgQXJndW1lbnRzXVwiKSkgeyByZXR1cm47IH0gdmFyIF9hcnIgPSBbXTsgdmFyIF9uID0gdHJ1ZTsgdmFyIF9kID0gZmFsc2U7IHZhciBfZSA9IHVuZGVmaW5lZDsgdHJ5IHsgZm9yICh2YXIgX2kgPSBhcnJbU3ltYm9sLml0ZXJhdG9yXSgpLCBfczsgIShfbiA9IChfcyA9IF9pLm5leHQoKSkuZG9uZSk7IF9uID0gdHJ1ZSkgeyBfYXJyLnB1c2goX3MudmFsdWUpOyBpZiAoaSAmJiBfYXJyLmxlbmd0aCA9PT0gaSkgYnJlYWs7IH0gfSBjYXRjaCAoZXJyKSB7IF9kID0gdHJ1ZTsgX2UgPSBlcnI7IH0gZmluYWxseSB7IHRyeSB7IGlmICghX24gJiYgX2lbXCJyZXR1cm5cIl0gIT0gbnVsbCkgX2lbXCJyZXR1cm5cIl0oKTsgfSBmaW5hbGx5IHsgaWYgKF9kKSB0aHJvdyBfZTsgfSB9IHJldHVybiBfYXJyOyB9XG5cbmZ1bmN0aW9uIF9hcnJheVdpdGhIb2xlcyhhcnIpIHsgaWYgKEFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIGFycjsgfVxuXG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHNvdXJjZSwgZXhjbHVkZWQpOyB2YXIga2V5LCBpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgc291cmNlU3ltYm9sS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKTsgZm9yIChpID0gMDsgaSA8IHNvdXJjZVN5bWJvbEtleXMubGVuZ3RoOyBpKyspIHsga2V5ID0gc291cmNlU3ltYm9sS2V5c1tpXTsgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTsgaWYgKCFPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoc291cmNlLCBrZXkpKSBjb250aW51ZTsgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTsgfSB9IHJldHVybiB0YXJnZXQ7IH1cblxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IHt9OyB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7IHZhciBrZXksIGk7IGZvciAoaSA9IDA7IGkgPCBzb3VyY2VLZXlzLmxlbmd0aDsgaSsrKSB7IGtleSA9IHNvdXJjZUtleXNbaV07IGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7IHRhcmdldFtrZXldID0gc291cmNlW2tleV07IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCB1c2VQaG9uZURpZ2l0cyBmcm9tICcuL3VzZVBob25lRGlnaXRzJztcblxuZnVuY3Rpb24gUGhvbmVJbnB1dChfcmVmLCByZWYpIHtcbiAgdmFyIENvbXBvbmVudCA9IF9yZWYuQ29tcG9uZW50LFxuICAgICAgY291bnRyeSA9IF9yZWYuY291bnRyeSxcbiAgICAgIGRlZmF1bHRDb3VudHJ5ID0gX3JlZi5kZWZhdWx0Q291bnRyeSxcbiAgICAgIHVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZSA9IF9yZWYudXNlTmF0aW9uYWxGb3JtYXRGb3JEZWZhdWx0Q291bnRyeVZhbHVlLFxuICAgICAgdmFsdWUgPSBfcmVmLnZhbHVlLFxuICAgICAgb25DaGFuZ2UgPSBfcmVmLm9uQ2hhbmdlLFxuICAgICAgbWV0YWRhdGEgPSBfcmVmLm1ldGFkYXRhLFxuICAgICAgaW50ZXJuYXRpb25hbCA9IF9yZWYuaW50ZXJuYXRpb25hbCxcbiAgICAgIHdpdGhDb3VudHJ5Q2FsbGluZ0NvZGUgPSBfcmVmLndpdGhDb3VudHJ5Q2FsbGluZ0NvZGUsXG4gICAgICByZXN0ID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzKF9yZWYsIFtcIkNvbXBvbmVudFwiLCBcImNvdW50cnlcIiwgXCJkZWZhdWx0Q291bnRyeVwiLCBcInVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZVwiLCBcInZhbHVlXCIsIFwib25DaGFuZ2VcIiwgXCJtZXRhZGF0YVwiLCBcImludGVybmF0aW9uYWxcIiwgXCJ3aXRoQ291bnRyeUNhbGxpbmdDb2RlXCJdKTtcblxuICAvLyBcIlBob25lIGRpZ2l0c1wiIGluY2x1ZGVzIG5vdCBvbmx5IFwiZGlnaXRzXCIgYnV0IGFsc28gYSBgK2Agc2lnbi5cbiAgdmFyIF91c2VQaG9uZURpZ2l0cyA9IHVzZVBob25lRGlnaXRzKHtcbiAgICB2YWx1ZTogdmFsdWUsXG4gICAgb25DaGFuZ2U6IG9uQ2hhbmdlLFxuICAgIGNvdW50cnk6IGNvdW50cnksXG4gICAgZGVmYXVsdENvdW50cnk6IGRlZmF1bHRDb3VudHJ5LFxuICAgIGludGVybmF0aW9uYWw6IGludGVybmF0aW9uYWwsXG4gICAgd2l0aENvdW50cnlDYWxsaW5nQ29kZTogd2l0aENvdW50cnlDYWxsaW5nQ29kZSxcbiAgICB1c2VOYXRpb25hbEZvcm1hdEZvckRlZmF1bHRDb3VudHJ5VmFsdWU6IHVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZSxcbiAgICBtZXRhZGF0YTogbWV0YWRhdGFcbiAgfSksXG4gICAgICBfdXNlUGhvbmVEaWdpdHMyID0gX3NsaWNlZFRvQXJyYXkoX3VzZVBob25lRGlnaXRzLCAyKSxcbiAgICAgIHBob25lRGlnaXRzID0gX3VzZVBob25lRGlnaXRzMlswXSxcbiAgICAgIHNldFBob25lRGlnaXRzID0gX3VzZVBob25lRGlnaXRzMlsxXTtcblxuICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChDb21wb25lbnQsIF9leHRlbmRzKHt9LCByZXN0LCB7XG4gICAgcmVmOiByZWYsXG4gICAgbWV0YWRhdGE6IG1ldGFkYXRhLFxuICAgIGludGVybmF0aW9uYWw6IGludGVybmF0aW9uYWwsXG4gICAgd2l0aENvdW50cnlDYWxsaW5nQ29kZTogd2l0aENvdW50cnlDYWxsaW5nQ29kZSxcbiAgICBjb3VudHJ5OiBjb3VudHJ5IHx8IGRlZmF1bHRDb3VudHJ5LFxuICAgIHZhbHVlOiBwaG9uZURpZ2l0cyxcbiAgICBvbkNoYW5nZTogc2V0UGhvbmVEaWdpdHNcbiAgfSkpO1xufVxuXG5QaG9uZUlucHV0ID0gUmVhY3QuZm9yd2FyZFJlZihQaG9uZUlucHV0KTtcblBob25lSW5wdXQucHJvcFR5cGVzID0ge1xuICAvKipcclxuICAgKiBUaGUgcGhvbmUgbnVtYmVyIChpbiBFLjE2NCBmb3JtYXQpLlxyXG4gICAqIEV4YW1wbGVzOiBgdW5kZWZpbmVkYCwgYFwiKzEyXCJgLCBgXCIrMTIxMzM3MzQyNTNcImAuXHJcbiAgICovXG4gIHZhbHVlOiBQcm9wVHlwZXMuc3RyaW5nLFxuXG4gIC8qKlxyXG4gICAqIEEgZnVuY3Rpb24gb2YgYHZhbHVlOiBzdHJpbmc/YC5cclxuICAgKiBVcGRhdGVzIHRoZSBgdmFsdWVgIHByb3BlcnR5LlxyXG4gICAqL1xuICBvbkNoYW5nZTogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcblxuICAvKipcclxuICAgKiBBIHR3by1sZXR0ZXIgY291bnRyeSBjb2RlIGZvciBmb3JtYXR0aW5nIGB2YWx1ZWBcclxuICAgKiBhcyBhIG5hdGlvbmFsIHBob25lIG51bWJlciAoZXhhbXBsZTogYCgyMTMpIDM3My00MjUzYCksXHJcbiAgICogb3IgYXMgYW4gaW50ZXJuYXRpb25hbCBwaG9uZSBudW1iZXIgd2l0aG91dCBcImNvdW50cnkgY2FsbGluZyBjb2RlXCJcclxuICAgKiBpZiBgaW50ZXJuYXRpb25hbGAgcHJvcGVydHkgaXMgcGFzc2VkIChleGFtcGxlOiBgMjEzIDM3MyA0MjUzYCkuXHJcbiAgICogRXhhbXBsZTogXCJVU1wiLlxyXG4gICAqIElmIG5vIGBjb3VudHJ5YCBpcyBwYXNzZWQgdGhlbiBgdmFsdWVgXHJcbiAgICogaXMgZm9ybWF0dGVkIGFzIGFuIGludGVybmF0aW9uYWwgcGhvbmUgbnVtYmVyLlxyXG4gICAqIChleGFtcGxlOiBgKzEgMjEzIDM3MyA0MjUzYClcclxuICAgKi9cbiAgY291bnRyeTogUHJvcFR5cGVzLnN0cmluZyxcblxuICAvKipcclxuICAgKiBBIHR3by1sZXR0ZXIgY291bnRyeSBjb2RlIGZvciBmb3JtYXR0aW5nIGB2YWx1ZWBcclxuICAgKiB3aGVuIGEgdXNlciBpbnB1dHMgYSBuYXRpb25hbCBwaG9uZSBudW1iZXIgKGV4YW1wbGU6IGAoMjEzKSAzNzMtNDI1M2ApLlxyXG4gICAqIFRoZSB1c2VyIGNhbiBzdGlsbCBpbnB1dCBhIHBob25lIG51bWJlciBpbiBpbnRlcm5hdGlvbmFsIGZvcm1hdC5cclxuICAgKiBFeGFtcGxlOiBcIlVTXCIuXHJcbiAgICogYGNvdW50cnlgIGFuZCBgZGVmYXVsdENvdW50cnlgIHByb3BlcnRpZXMgYXJlIG11dHVhbGx5IGV4Y2x1c2l2ZS5cclxuICAgKi9cbiAgZGVmYXVsdENvdW50cnk6IFByb3BUeXBlcy5zdHJpbmcsXG5cbiAgLyoqXHJcbiAgICogSWYgYGNvdW50cnlgIHByb3BlcnR5IGlzIHBhc3NlZCBhbG9uZyB3aXRoIGBpbnRlcm5hdGlvbmFsPXt0cnVlfWAgcHJvcGVydHlcclxuICAgKiB0aGVuIHRoZSBwaG9uZSBudW1iZXIgd2lsbCBiZSBpbnB1dCBpbiBcImludGVybmF0aW9uYWxcIiBmb3JtYXQgZm9yIHRoYXQgYGNvdW50cnlgXHJcbiAgICogKHdpdGhvdXQgXCJjb3VudHJ5IGNhbGxpbmcgY29kZVwiKS5cclxuICAgKiBGb3IgZXhhbXBsZSwgaWYgYGNvdW50cnk9XCJVU1wiYCBwcm9wZXJ0eSBpcyBwYXNzZWQgdG8gXCJ3aXRob3V0IGNvdW50cnkgc2VsZWN0XCIgaW5wdXRcclxuICAgKiB0aGVuIHRoZSBwaG9uZSBudW1iZXIgd2lsbCBiZSBpbnB1dCBpbiB0aGUgXCJuYXRpb25hbFwiIGZvcm1hdCBmb3IgYFVTYCAoYCgyMTMpIDM3My00MjUzYCkuXHJcbiAgICogQnV0IGlmIGJvdGggYGNvdW50cnk9XCJVU1wiYCBhbmQgYGludGVybmF0aW9uYWw9e3RydWV9YCBwcm9wZXJ0aWVzIGFyZSBwYXNzZWQgdGhlblxyXG4gICAqIHRoZSBwaG9uZSBudW1iZXIgd2lsbCBiZSBpbnB1dCBpbiB0aGUgXCJpbnRlcm5hdGlvbmFsXCIgZm9ybWF0IGZvciBgVVNgIChgMjEzIDM3MyA0MjUzYClcclxuICAgKiAod2l0aG91dCBcImNvdW50cnkgY2FsbGluZyBjb2RlXCIgYCsxYCkuXHJcbiAgICovXG4gIGludGVybmF0aW9uYWw6IFByb3BUeXBlcy5ib29sLFxuXG4gIC8qKlxyXG4gICAqIElmIGBjb3VudHJ5YCBhbmQgYGludGVybmF0aW9uYWxgIHByb3BlcnRpZXMgYXJlIHNldCxcclxuICAgKiB0aGVuIGJ5IGRlZmF1bHQgaXQgd29uJ3QgaW5jbHVkZSBcImNvdW50cnkgY2FsbGluZyBjb2RlXCIgaW4gdGhlIGlucHV0IGZpZWxkLlxyXG4gICAqIFRvIGNoYW5nZSB0aGF0LCBwYXNzIGB3aXRoQ291bnRyeUNhbGxpbmdDb2RlYCBwcm9wZXJ0eSxcclxuICAgKiBhbmQgaXQgd2lsbCBpbmNsdWRlIFwiY291bnRyeSBjYWxsaW5nIGNvZGVcIiBpbiB0aGUgaW5wdXQgZmllbGQuXHJcbiAgICovXG4gIHdpdGhDb3VudHJ5Q2FsbGluZ0NvZGU6IFByb3BUeXBlcy5ib29sLFxuXG4gIC8qKlxyXG4gICAqIEEgY29tcG9uZW50IHRoYXQgcmVuZGVycyB0aGUgYDxpbnB1dC8+YCBpdHNlbGYgYW5kIGFsc29cclxuICAgKiBwYXJzZXMgYW5kIGZvcm1hdHMgaXRzIGB2YWx1ZWAgYXMgdGhlIHVzZXIgaW5wdXRzIGl0LlxyXG4gICAqL1xuICBDb21wb25lbnQ6IFByb3BUeXBlcy5lbGVtZW50VHlwZS5pc1JlcXVpcmVkLFxuXG4gIC8qKlxyXG4gICAqIFdoZW4gYGRlZmF1bHRDb3VudHJ5YCBpcyBkZWZpbmVkIGFuZCB0aGUgaW5pdGlhbCBgdmFsdWVgIGNvcnJlc3BvbmRzIHRvIGBkZWZhdWx0Q291bnRyeWAsXHJcbiAgICogdGhlbiB0aGUgYHZhbHVlYCB3aWxsIGJlIGZvcm1hdHRlZCBhcyBhIG5hdGlvbmFsIHBob25lIG51bWJlciBieSBkZWZhdWx0LlxyXG4gICAqIFRvIGZvcm1hdCB0aGUgaW5pdGlhbCBgdmFsdWVgIG9mIGBkZWZhdWx0Q291bnRyeWAgYXMgYW4gaW50ZXJuYXRpb25hbCBudW1iZXIgaW5zdGVhZFxyXG4gICAqIHNldCBgdXNlTmF0aW9uYWxGb3JtYXRGb3JEZWZhdWx0Q291bnRyeVZhbHVlYCBwcm9wZXJ0eSB0byBgdHJ1ZWAuXHJcbiAgICovXG4gIHVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZTogUHJvcFR5cGVzLmJvb2wuaXNSZXF1aXJlZCxcblxuICAvKipcclxuICAgKiBgbGlicGhvbmVudW1iZXItanNgIG1ldGFkYXRhLlxyXG4gICAqL1xuICBtZXRhZGF0YTogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkXG59O1xuUGhvbmVJbnB1dC5kZWZhdWx0UHJvcHMgPSB7XG4gIC8qKlxyXG4gICAqIFNldCB0byBgdHJ1ZWAgdG8gZm9yY2UgaW50ZXJuYXRpb25hbCBwaG9uZSBudW1iZXIgZm9ybWF0XHJcbiAgICogKHdpdGhvdXQgXCJjb3VudHJ5IGNhbGxpbmcgY29kZVwiKSB3aGVuIGBjb3VudHJ5YCBpcyBzcGVjaWZpZWQuXHJcbiAgICovXG4gIC8vIGludGVybmF0aW9uYWw6IGZhbHNlLFxuXG4gIC8qKlxyXG4gICAqIFByZWZlciBuYXRpb25hbCBmb3JtYXQgd2hlbiBmb3JtYXR0aW5nIEUuMTY0IHBob25lIG51bWJlciBgdmFsdWVgXHJcbiAgICogY29ycmVzcG9uZGluZyB0byBgZGVmYXVsdENvdW50cnlgLlxyXG4gICAqL1xuICB1c2VOYXRpb25hbEZvcm1hdEZvckRlZmF1bHRDb3VudHJ5VmFsdWU6IHRydWVcbn07XG5leHBvcnQgZGVmYXVsdCBQaG9uZUlucHV0O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9UGhvbmVJbnB1dC5qcy5tYXAiLCJmdW5jdGlvbiBfZXh0ZW5kcygpIHsgX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHsgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspIHsgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTsgZm9yICh2YXIga2V5IGluIHNvdXJjZSkgeyBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkgeyB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldOyB9IH0gfSByZXR1cm4gdGFyZ2V0OyB9OyByZXR1cm4gX2V4dGVuZHMuYXBwbHkodGhpcywgYXJndW1lbnRzKTsgfVxuXG5mdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IF9vYmplY3RXaXRob3V0UHJvcGVydGllc0xvb3NlKHNvdXJjZSwgZXhjbHVkZWQpOyB2YXIga2V5LCBpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykgeyB2YXIgc291cmNlU3ltYm9sS2V5cyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoc291cmNlKTsgZm9yIChpID0gMDsgaSA8IHNvdXJjZVN5bWJvbEtleXMubGVuZ3RoOyBpKyspIHsga2V5ID0gc291cmNlU3ltYm9sS2V5c1tpXTsgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTsgaWYgKCFPYmplY3QucHJvdG90eXBlLnByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwoc291cmNlLCBrZXkpKSBjb250aW51ZTsgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTsgfSB9IHJldHVybiB0YXJnZXQ7IH1cblxuZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkgeyBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTsgdmFyIHRhcmdldCA9IHt9OyB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7IHZhciBrZXksIGk7IGZvciAoaSA9IDA7IGkgPCBzb3VyY2VLZXlzLmxlbmd0aDsgaSsrKSB7IGtleSA9IHNvdXJjZUtleXNbaV07IGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7IHRhcmdldFtrZXldID0gc291cmNlW2tleV07IH0gcmV0dXJuIHRhcmdldDsgfVxuXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcbmltcG9ydCBQaG9uZUlucHV0XyBmcm9tICcuL1Bob25lSW5wdXQnO1xuaW1wb3J0IElucHV0U21hcnQgZnJvbSAnLi9JbnB1dFNtYXJ0JztcbmltcG9ydCBJbnB1dEJhc2ljIGZyb20gJy4vSW5wdXRCYXNpYyc7XG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlSW5wdXQoZGVmYXVsdE1ldGFkYXRhKSB7XG4gIGZ1bmN0aW9uIFBob25lSW5wdXQoX3JlZiwgcmVmKSB7XG4gICAgdmFyIHNtYXJ0Q2FyZXQgPSBfcmVmLnNtYXJ0Q2FyZXQsXG4gICAgICAgIHJlc3QgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXMoX3JlZiwgW1wic21hcnRDYXJldFwiXSk7XG5cbiAgICByZXR1cm4gUmVhY3QuY3JlYXRlRWxlbWVudChQaG9uZUlucHV0XywgX2V4dGVuZHMoe30sIHJlc3QsIHtcbiAgICAgIHJlZjogcmVmLFxuICAgICAgQ29tcG9uZW50OiBzbWFydENhcmV0ID8gSW5wdXRTbWFydCA6IElucHV0QmFzaWNcbiAgICB9KSk7XG4gIH1cblxuICBQaG9uZUlucHV0ID0gUmVhY3QuZm9yd2FyZFJlZihQaG9uZUlucHV0KTtcbiAgUGhvbmVJbnB1dC5wcm9wVHlwZXMgPSB7XG4gICAgLyoqXHJcbiAgICAgKiBIVE1MIGA8aW5wdXQvPmAgYHR5cGVgIGF0dHJpYnV0ZS5cclxuICAgICAqL1xuICAgIHR5cGU6IFByb3BUeXBlcy5zdHJpbmcsXG5cbiAgICAvKipcclxuICAgICAqIEhUTUwgYDxpbnB1dC8+YCBgYXV0b2NvbXBsZXRlYCBhdHRyaWJ1dGUuXHJcbiAgICAgKi9cbiAgICBhdXRvQ29tcGxldGU6IFByb3BUeXBlcy5zdHJpbmcsXG5cbiAgICAvKipcclxuICAgICAqIEJ5IGRlZmF1bHQsIHRoZSBjYXJldCBwb3NpdGlvbiBpcyBiZWluZyBcImludGVsbGlnZW50bHlcIiBtYW5hZ2VkXHJcbiAgICAgKiB3aGlsZSBhIHVzZXIgaW5wdXRzIGEgcGhvbmUgbnVtYmVyLlxyXG4gICAgICogVGhpcyBcInNtYXJ0XCIgY2FyZXQgYmVoYXZpb3IgY2FuIGJlIHR1cm5lZCBvZmZcclxuICAgICAqIGJ5IHBhc3NpbmcgYHNtYXJ0Q2FyZXQ9e2ZhbHNlfWAgcHJvcGVydHkuXHJcbiAgICAgKiBUaGlzIGlzIGp1c3QgYW4gXCJlc2NhcGUgaGF0Y2hcIiBmb3IgYW55IHBvc3NpYmxlIGNhcmV0IHBvc2l0aW9uIGlzc3Vlcy5cclxuICAgICAqL1xuICAgIC8vIElzIGB0cnVlYCBieSBkZWZhdWx0LlxuICAgIHNtYXJ0Q2FyZXQ6IFByb3BUeXBlcy5ib29sLmlzUmVxdWlyZWQsXG5cbiAgICAvKipcclxuICAgICAqIGBsaWJwaG9uZW51bWJlci1qc2AgbWV0YWRhdGEuXHJcbiAgICAgKi9cbiAgICBtZXRhZGF0YTogUHJvcFR5cGVzLm9iamVjdC5pc1JlcXVpcmVkXG4gIH07XG4gIFBob25lSW5wdXQuZGVmYXVsdFByb3BzID0ge1xuICAgIC8qKlxyXG4gICAgICogSFRNTCBgPGlucHV0Lz5gIGB0eXBlPVwidGVsXCJgLlxyXG4gICAgICovXG4gICAgdHlwZTogJ3RlbCcsXG5cbiAgICAvKipcclxuICAgICAqIFJlbWVtYmVyIChhbmQgYXV0b2ZpbGwpIHRoZSB2YWx1ZSBhcyBhIHBob25lIG51bWJlci5cclxuICAgICAqL1xuICAgIGF1dG9Db21wbGV0ZTogJ3RlbCcsXG5cbiAgICAvKipcclxuICAgICAqIFNldCB0byBgZmFsc2VgIHRvIHVzZSBcImJhc2ljXCIgY2FyZXQgaW5zdGVhZCBvZiB0aGUgXCJzbWFydFwiIG9uZS5cclxuICAgICAqL1xuICAgIHNtYXJ0Q2FyZXQ6IHRydWUsXG5cbiAgICAvKipcclxuICAgICAqIGBsaWJwaG9uZW51bWJlci1qc2AgbWV0YWRhdGEuXHJcbiAgICAgKi9cbiAgICBtZXRhZGF0YTogZGVmYXVsdE1ldGFkYXRhXG4gIH07XG4gIHJldHVybiBQaG9uZUlucHV0O1xufVxuZXhwb3J0IGRlZmF1bHQgY3JlYXRlSW5wdXQoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPVBob25lSW5wdXRCcm93c2VyLmpzLm1hcCIsImZ1bmN0aW9uIF9zbGljZWRUb0FycmF5KGFyciwgaSkgeyByZXR1cm4gX2FycmF5V2l0aEhvbGVzKGFycikgfHwgX2l0ZXJhYmxlVG9BcnJheUxpbWl0KGFyciwgaSkgfHwgX25vbkl0ZXJhYmxlUmVzdCgpOyB9XG5cbmZ1bmN0aW9uIF9ub25JdGVyYWJsZVJlc3QoKSB7IHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gZGVzdHJ1Y3R1cmUgbm9uLWl0ZXJhYmxlIGluc3RhbmNlXCIpOyB9XG5cbmZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXlMaW1pdChhcnIsIGkpIHsgaWYgKCEoU3ltYm9sLml0ZXJhdG9yIGluIE9iamVjdChhcnIpIHx8IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbChhcnIpID09PSBcIltvYmplY3QgQXJndW1lbnRzXVwiKSkgeyByZXR1cm47IH0gdmFyIF9hcnIgPSBbXTsgdmFyIF9uID0gdHJ1ZTsgdmFyIF9kID0gZmFsc2U7IHZhciBfZSA9IHVuZGVmaW5lZDsgdHJ5IHsgZm9yICh2YXIgX2kgPSBhcnJbU3ltYm9sLml0ZXJhdG9yXSgpLCBfczsgIShfbiA9IChfcyA9IF9pLm5leHQoKSkuZG9uZSk7IF9uID0gdHJ1ZSkgeyBfYXJyLnB1c2goX3MudmFsdWUpOyBpZiAoaSAmJiBfYXJyLmxlbmd0aCA9PT0gaSkgYnJlYWs7IH0gfSBjYXRjaCAoZXJyKSB7IF9kID0gdHJ1ZTsgX2UgPSBlcnI7IH0gZmluYWxseSB7IHRyeSB7IGlmICghX24gJiYgX2lbXCJyZXR1cm5cIl0gIT0gbnVsbCkgX2lbXCJyZXR1cm5cIl0oKTsgfSBmaW5hbGx5IHsgaWYgKF9kKSB0aHJvdyBfZTsgfSB9IHJldHVybiBfYXJyOyB9XG5cbmZ1bmN0aW9uIF9hcnJheVdpdGhIb2xlcyhhcnIpIHsgaWYgKEFycmF5LmlzQXJyYXkoYXJyKSkgcmV0dXJuIGFycjsgfVxuXG5pbXBvcnQgeyB1c2VSZWYsIHVzZVN0YXRlLCB1c2VDYWxsYmFjaywgdXNlRWZmZWN0IH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgQXNZb3VUeXBlLCBnZXRDb3VudHJ5Q2FsbGluZ0NvZGUsIHBhcnNlRGlnaXRzIH0gZnJvbSAnbGlicGhvbmVudW1iZXItanMvY29yZSc7XG5pbXBvcnQgZ2V0SW50ZXJuYXRpb25hbFBob25lTnVtYmVyUHJlZml4IGZyb20gJy4vaGVscGVycy9nZXRJbnRlcm5hdGlvbmFsUGhvbmVOdW1iZXJQcmVmaXgnO1xuLyoqXHJcbiAqIFJldHVybnMgYFtwaG9uZURpZ2l0cywgc2V0UGhvbmVEaWdpdHNdYC5cclxuICogXCJQaG9uZSBkaWdpdHNcIiBpbmNsdWRlcyBub3Qgb25seSBcImRpZ2l0c1wiIGJ1dCBhbHNvIGEgYCtgIHNpZ24uXHJcbiAqL1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiB1c2VQaG9uZURpZ2l0cyhfcmVmKSB7XG4gIHZhciBfdGhpcyA9IHRoaXM7XG5cbiAgdmFyIHZhbHVlID0gX3JlZi52YWx1ZSxcbiAgICAgIG9uQ2hhbmdlID0gX3JlZi5vbkNoYW5nZSxcbiAgICAgIGNvdW50cnkgPSBfcmVmLmNvdW50cnksXG4gICAgICBkZWZhdWx0Q291bnRyeSA9IF9yZWYuZGVmYXVsdENvdW50cnksXG4gICAgICBpbnRlcm5hdGlvbmFsID0gX3JlZi5pbnRlcm5hdGlvbmFsLFxuICAgICAgd2l0aENvdW50cnlDYWxsaW5nQ29kZSA9IF9yZWYud2l0aENvdW50cnlDYWxsaW5nQ29kZSxcbiAgICAgIHVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZSA9IF9yZWYudXNlTmF0aW9uYWxGb3JtYXRGb3JEZWZhdWx0Q291bnRyeVZhbHVlLFxuICAgICAgbWV0YWRhdGEgPSBfcmVmLm1ldGFkYXRhO1xuICB2YXIgY291bnRyeU1pc21hdGNoRGV0ZWN0ZWQgPSB1c2VSZWYoKTtcblxuICB2YXIgb25Db3VudHJ5TWlzbWF0Y2ggPSBmdW5jdGlvbiBvbkNvdW50cnlNaXNtYXRjaCh2YWx1ZSwgY291bnRyeSwgYWN0dWFsQ291bnRyeSkge1xuICAgIGNvbnNvbGUuZXJyb3IoXCJbcmVhY3QtcGhvbmUtbnVtYmVyLWlucHV0XSBFeHBlY3RlZCBwaG9uZSBudW1iZXIgXCIuY29uY2F0KHZhbHVlLCBcIiB0byBjb3JyZXNwb25kIHRvIGNvdW50cnkgXCIpLmNvbmNhdChjb3VudHJ5LCBcIiBidXQgXCIpLmNvbmNhdChhY3R1YWxDb3VudHJ5ID8gJ2luIHJlYWxpdHkgaXQgY29ycmVzcG9uZHMgdG8gY291bnRyeSAnICsgYWN0dWFsQ291bnRyeSA6ICdpdCBkb2VzblxcJ3QnLCBcIi5cIikpO1xuICAgIGNvdW50cnlNaXNtYXRjaERldGVjdGVkLmN1cnJlbnQgPSB0cnVlO1xuICB9O1xuXG4gIHZhciBnZXRJbml0aWFsUGhvbmVEaWdpdHMgPSBmdW5jdGlvbiBnZXRJbml0aWFsUGhvbmVEaWdpdHMob3B0aW9ucykge1xuICAgIHJldHVybiBnZXRQaG9uZURpZ2l0c0ZvclZhbHVlKHZhbHVlLCBjb3VudHJ5LCBpbnRlcm5hdGlvbmFsLCB3aXRoQ291bnRyeUNhbGxpbmdDb2RlLCBkZWZhdWx0Q291bnRyeSwgdXNlTmF0aW9uYWxGb3JtYXRGb3JEZWZhdWx0Q291bnRyeVZhbHVlLCBtZXRhZGF0YSwgZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKG9wdGlvbnMgJiYgb3B0aW9ucy5vbkNvdW50cnlNaXNtYXRjaCkge1xuICAgICAgICBvcHRpb25zLm9uQ291bnRyeU1pc21hdGNoKCk7XG4gICAgICB9XG5cbiAgICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgICAgfVxuXG4gICAgICBvbkNvdW50cnlNaXNtYXRjaC5hcHBseShfdGhpcywgYXJncyk7XG4gICAgfSk7XG4gIH07IC8vIFRoaXMgaXMgb25seSB1c2VkIHRvIGRldGVjdCBgY291bnRyeWAgcHJvcGVydHkgY2hhbmdlLlxuXG5cbiAgdmFyIF91c2VTdGF0ZSA9IHVzZVN0YXRlKGNvdW50cnkpLFxuICAgICAgX3VzZVN0YXRlMiA9IF9zbGljZWRUb0FycmF5KF91c2VTdGF0ZSwgMiksXG4gICAgICBwcmV2Q291bnRyeSA9IF91c2VTdGF0ZTJbMF0sXG4gICAgICBzZXRQcmV2Q291bnRyeSA9IF91c2VTdGF0ZTJbMV07IC8vIFRoaXMgaXMgb25seSB1c2VkIHRvIGRldGVjdCBgZGVmYXVsdENvdW50cnlgIHByb3BlcnR5IGNoYW5nZS5cblxuXG4gIHZhciBfdXNlU3RhdGUzID0gdXNlU3RhdGUoZGVmYXVsdENvdW50cnkpLFxuICAgICAgX3VzZVN0YXRlNCA9IF9zbGljZWRUb0FycmF5KF91c2VTdGF0ZTMsIDIpLFxuICAgICAgcHJldkRlZmF1bHRDb3VudHJ5ID0gX3VzZVN0YXRlNFswXSxcbiAgICAgIHNldFByZXZEZWZhdWx0Q291bnRyeSA9IF91c2VTdGF0ZTRbMV07IC8vIGBwaG9uZURpZ2l0c2AgaXMgdGhlIGB2YWx1ZWAgcGFzc2VkIHRvIHRoZSBgPGlucHV0Lz5gLlxuXG5cbiAgdmFyIF91c2VTdGF0ZTUgPSB1c2VTdGF0ZShnZXRJbml0aWFsUGhvbmVEaWdpdHMoKSksXG4gICAgICBfdXNlU3RhdGU2ID0gX3NsaWNlZFRvQXJyYXkoX3VzZVN0YXRlNSwgMiksXG4gICAgICBwaG9uZURpZ2l0cyA9IF91c2VTdGF0ZTZbMF0sXG4gICAgICBzZXRQaG9uZURpZ2l0cyA9IF91c2VTdGF0ZTZbMV07IC8vIFRoaXMgaXMgb25seSB1c2VkIHRvIGRldGVjdCBgdmFsdWVgIHByb3BlcnR5IGNoYW5nZXMuXG5cblxuICB2YXIgX3VzZVN0YXRlNyA9IHVzZVN0YXRlKHZhbHVlKSxcbiAgICAgIF91c2VTdGF0ZTggPSBfc2xpY2VkVG9BcnJheShfdXNlU3RhdGU3LCAyKSxcbiAgICAgIHZhbHVlRm9yUGhvbmVEaWdpdHMgPSBfdXNlU3RhdGU4WzBdLFxuICAgICAgc2V0VmFsdWVGb3JQaG9uZURpZ2l0cyA9IF91c2VTdGF0ZThbMV07IC8vIFJlcmVuZGVyIGhhY2suXG5cblxuICB2YXIgX3VzZVN0YXRlOSA9IHVzZVN0YXRlKCksXG4gICAgICBfdXNlU3RhdGUxMCA9IF9zbGljZWRUb0FycmF5KF91c2VTdGF0ZTksIDIpLFxuICAgICAgcmVyZW5kZXJUcmlnZ2VyID0gX3VzZVN0YXRlMTBbMF0sXG4gICAgICBzZXRSZXJlbmRlclRyaWdnZXIgPSBfdXNlU3RhdGUxMFsxXTtcblxuICB2YXIgcmVyZW5kZXIgPSB1c2VDYWxsYmFjayhmdW5jdGlvbiAoKSB7XG4gICAgcmV0dXJuIHNldFJlcmVuZGVyVHJpZ2dlcih7fSk7XG4gIH0sIFtzZXRSZXJlbmRlclRyaWdnZXJdKTtcblxuICBmdW5jdGlvbiBnZXRWYWx1ZUZvclBob25lRGlnaXRzKHBob25lRGlnaXRzKSB7XG4gICAgdmFyIGFzWW91VHlwZSA9IG5ldyBBc1lvdVR5cGUoY291bnRyeSB8fCBkZWZhdWx0Q291bnRyeSwgbWV0YWRhdGEpO1xuICAgIGFzWW91VHlwZS5pbnB1dChjb3VudHJ5ICYmIGludGVybmF0aW9uYWwgJiYgIXdpdGhDb3VudHJ5Q2FsbGluZ0NvZGUgPyBcIitcIi5jb25jYXQoZ2V0Q291bnRyeUNhbGxpbmdDb2RlKGNvdW50cnksIG1ldGFkYXRhKSkuY29uY2F0KHBob25lRGlnaXRzKSA6IHBob25lRGlnaXRzKTtcbiAgICB2YXIgcGhvbmVOdW1iZXIgPSBhc1lvdVR5cGUuZ2V0TnVtYmVyKCk7IC8vIElmIGl0J3MgYSBcInBvc3NpYmxlXCIgaW5jb21wbGV0ZSBwaG9uZSBudW1iZXIuXG5cbiAgICBpZiAocGhvbmVOdW1iZXIpIHtcbiAgICAgIHJldHVybiBwaG9uZU51bWJlci5udW1iZXI7XG4gICAgfVxuICB9IC8vIElmIGB2YWx1ZWAgcHJvcGVydHkgaGFzIGJlZW4gY2hhbmdlZCBleHRlcm5hbGx5XG4gIC8vIHRoZW4gcmUtaW5pdGlhbGl6ZSB0aGUgY29tcG9uZW50LlxuXG5cbiAgdXNlRWZmZWN0KGZ1bmN0aW9uICgpIHtcbiAgICBpZiAodmFsdWUgIT09IHZhbHVlRm9yUGhvbmVEaWdpdHMpIHtcbiAgICAgIHNldFZhbHVlRm9yUGhvbmVEaWdpdHModmFsdWUpO1xuICAgICAgc2V0UGhvbmVEaWdpdHMoZ2V0SW5pdGlhbFBob25lRGlnaXRzKCkpO1xuICAgIH1cbiAgfSwgW3ZhbHVlXSk7IC8vIElmIHRoZSBgY291bnRyeWAgaGFzIGJlZW4gY2hhbmdlZCB0aGVuIHJlLWluaXRpYWxpemUgdGhlIGNvbXBvbmVudC5cblxuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIGlmIChjb3VudHJ5ICE9PSBwcmV2Q291bnRyeSkge1xuICAgICAgc2V0UHJldkNvdW50cnkoY291bnRyeSk7XG5cbiAgICAgIHZhciBfY291bnRyeU1pc21hdGNoRGV0ZWN0ZWQ7XG5cbiAgICAgIHZhciBfcGhvbmVEaWdpdHMgPSBnZXRJbml0aWFsUGhvbmVEaWdpdHMoe1xuICAgICAgICBvbkNvdW50cnlNaXNtYXRjaDogZnVuY3Rpb24gb25Db3VudHJ5TWlzbWF0Y2goKSB7XG4gICAgICAgICAgX2NvdW50cnlNaXNtYXRjaERldGVjdGVkID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG5cbiAgICAgIHNldFBob25lRGlnaXRzKF9waG9uZURpZ2l0cyk7XG5cbiAgICAgIGlmIChfY291bnRyeU1pc21hdGNoRGV0ZWN0ZWQpIHtcbiAgICAgICAgc2V0VmFsdWVGb3JQaG9uZURpZ2l0cyhnZXRWYWx1ZUZvclBob25lRGlnaXRzKF9waG9uZURpZ2l0cykpO1xuICAgICAgfVxuICAgIH1cbiAgfSwgW2NvdW50cnldKTsgLy8gSWYgdGhlIGBkZWZhdWx0Q291bnRyeWAgaGFzIGJlZW4gY2hhbmdlZCB0aGVuIHJlLWluaXRpYWxpemUgdGhlIGNvbXBvbmVudC5cblxuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIGlmIChkZWZhdWx0Q291bnRyeSAhPT0gcHJldkRlZmF1bHRDb3VudHJ5KSB7XG4gICAgICBzZXRQcmV2RGVmYXVsdENvdW50cnkoZGVmYXVsdENvdW50cnkpO1xuICAgICAgc2V0UGhvbmVEaWdpdHMoZ2V0SW5pdGlhbFBob25lRGlnaXRzKCkpO1xuICAgIH1cbiAgfSwgW2RlZmF1bHRDb3VudHJ5XSk7IC8vIFVwZGF0ZSB0aGUgYHZhbHVlYCBhZnRlciBgdmFsdWVGb3JQaG9uZURpZ2l0c2AgaGFzIGJlZW4gdXBkYXRlZC5cblxuICB1c2VFZmZlY3QoZnVuY3Rpb24gKCkge1xuICAgIGlmICh2YWx1ZUZvclBob25lRGlnaXRzICE9PSB2YWx1ZSkge1xuICAgICAgb25DaGFuZ2UodmFsdWVGb3JQaG9uZURpZ2l0cyk7XG4gICAgfVxuICB9LCBbdmFsdWVGb3JQaG9uZURpZ2l0c10pO1xuICB2YXIgb25TZXRQaG9uZURpZ2l0cyA9IHVzZUNhbGxiYWNrKGZ1bmN0aW9uIChwaG9uZURpZ2l0cykge1xuICAgIHZhciB2YWx1ZTtcblxuICAgIGlmIChjb3VudHJ5KSB7XG4gICAgICBpZiAoaW50ZXJuYXRpb25hbCAmJiB3aXRoQ291bnRyeUNhbGxpbmdDb2RlKSB7XG4gICAgICAgIC8vIFRoZSBgPGlucHV0Lz5gIHZhbHVlIG11c3Qgc3RhcnQgd2l0aCB0aGUgY291bnRyeSBjYWxsaW5nIGNvZGUuXG4gICAgICAgIHZhciBwcmVmaXggPSBnZXRJbnRlcm5hdGlvbmFsUGhvbmVOdW1iZXJQcmVmaXgoY291bnRyeSwgbWV0YWRhdGEpO1xuXG4gICAgICAgIGlmIChwaG9uZURpZ2l0cy5pbmRleE9mKHByZWZpeCkgIT09IDApIHtcbiAgICAgICAgICAvLyBJZiBhIHVzZXIgdGFicyBpbnRvIGEgcGhvbmUgbnVtYmVyIGlucHV0IGZpZWxkXG4gICAgICAgICAgLy8gdGhhdCBpcyBgaW50ZXJuYXRpb25hbGAgYW5kIGB3aXRoQ291bnRyeUNhbGxpbmdDb2RlYCxcbiAgICAgICAgICAvLyBhbmQgdGhlbiBzdGFydHMgaW5wdXR0aW5nIGxvY2FsIHBob25lIG51bWJlciBkaWdpdHMsXG4gICAgICAgICAgLy8gdGhlIGZpcnN0IGRpZ2l0IHdvdWxkIGdldCBcInN3YWxsb3dlZFwiIGlmIHRoZSBmaXggYmVsb3cgd2Fzbid0IGltcGxlbWVudGVkLlxuICAgICAgICAgIC8vIGh0dHBzOi8vZ2l0bGFiLmNvbS9jYXRhbXBoZXRhbWluZS9yZWFjdC1waG9uZS1udW1iZXItaW5wdXQvLS9pc3N1ZXMvNDNcbiAgICAgICAgICBpZiAocGhvbmVEaWdpdHMgJiYgcGhvbmVEaWdpdHNbMF0gIT09ICcrJykge1xuICAgICAgICAgICAgcGhvbmVEaWdpdHMgPSBwcmVmaXggKyBwaG9uZURpZ2l0cztcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgLy8gLy8gUmVzZXQgcGhvbmUgZGlnaXRzIGlmIHRoZXkgZG9uJ3Qgc3RhcnQgd2l0aCB0aGUgY29ycmVjdCBwcmVmaXguXG4gICAgICAgICAgICAvLyAvLyBVbmRvIHRoZSBgPGlucHV0Lz5gIHZhbHVlIGNoYW5nZSBpZiBpdCBkb2Vzbid0LlxuICAgICAgICAgICAgaWYgKGNvdW50cnlNaXNtYXRjaERldGVjdGVkLmN1cnJlbnQpIHsvLyBJbiBjYXNlIG9mIGEgYGNvdW50cnlgL2B2YWx1ZWAgbWlzbWF0Y2gsXG4gICAgICAgICAgICAgIC8vIGlmIGl0IHBlcmZvcm1lZCBhbiBcInVuZG9cIiBoZXJlLCB0aGVuXG4gICAgICAgICAgICAgIC8vIGl0IHdvdWxkbid0IGxldCBhIHVzZXIgZWRpdCB0aGVpciBwaG9uZSBudW1iZXIgYXQgYWxsLFxuICAgICAgICAgICAgICAvLyBzbyB0aGlzIHNwZWNpYWwgY2FzZSBhdCBsZWFzdCBhbGxvd3MgcGhvbmUgbnVtYmVyIGVkaXRpbmdcbiAgICAgICAgICAgICAgLy8gd2hlbiBgdmFsdWVgIGFscmVhZHkgZG9lc24ndCBtYXRjaCB0aGUgYGNvdW50cnlgLlxuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgLy8gSWYgaXQgc2ltcGx5IGRpZCBgcGhvbmVEaWdpdHMgPSBwcmVmaXhgIGhlcmUsXG4gICAgICAgICAgICAgIC8vIHRoZW4gaXQgY291bGQgaGF2ZSBubyBlZmZlY3Qgd2hlbiBlcmFzaW5nIHBob25lIG51bWJlclxuICAgICAgICAgICAgICAvLyB2aWEgQmFja3NwYWNlLCBiZWNhdXNlIGBwaG9uZURpZ2l0c2AgaW4gYHN0YXRlYCB3b3VsZG4ndCBjaGFuZ2VcbiAgICAgICAgICAgICAgLy8gYXMgYSByZXN1bHQsIGJlY2F1c2UgaXQgd2FzIGBwcmVmaXhgIGFuZCBpdCBiZWNhbWUgYHByZWZpeGAsXG4gICAgICAgICAgICAgIC8vIHNvIHRoZSBjb21wb25lbnQgd291bGRuJ3QgcmVyZW5kZXIsIGFuZCB0aGUgdXNlciB3b3VsZCBiZSBhYmxlXG4gICAgICAgICAgICAgIC8vIHRvIGVyYXNlIHRoZSBjb3VudHJ5IGNhbGxpbmcgY29kZSBwYXJ0LCBhbmQgdGhhdCBwYXJ0IGlzXG4gICAgICAgICAgICAgIC8vIGFzc3VtZWQgdG8gYmUgbm9uLWVyYXNlYWJsZS4gVGhhdCdzIHdoeSB0aGUgY29tcG9uZW50IGlzXG4gICAgICAgICAgICAgIC8vIGZvcmNlZnVsbHkgcmVyZW5kZXJlZCBoZXJlLlxuICAgICAgICAgICAgICBzZXRQaG9uZURpZ2l0cyhwcmVmaXgpO1xuICAgICAgICAgICAgICBzZXRWYWx1ZUZvclBob25lRGlnaXRzKHVuZGVmaW5lZCk7IC8vIEZvcmNlIGEgcmUtcmVuZGVyIG9mIHRoZSBgPGlucHV0Lz5gIHdpdGggcHJldmlvdXMgYHBob25lRGlnaXRzYCB2YWx1ZS5cblxuICAgICAgICAgICAgICByZXR1cm4gcmVyZW5kZXIoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIC8vIEVudGVyaW5nIHBob25lIG51bWJlciBlaXRoZXIgaW4gXCJuYXRpb25hbFwiIGZvcm1hdFxuICAgICAgICAvLyB3aGVuIGBjb3VudHJ5YCBoYXMgYmVlbiBzcGVjaWZpZWQsIG9yIGluIFwiaW50ZXJuYXRpb25hbFwiIGZvcm1hdFxuICAgICAgICAvLyB3aGVuIGBjb3VudHJ5YCBoYXMgYmVlbiBzcGVjaWZpZWQgYnV0IGB3aXRoQ291bnRyeUNhbGxpbmdDb2RlYCBoYXNuJ3QuXG4gICAgICAgIC8vIFRoZXJlZm9yZSwgYCtgIGlzIG5vdCBhbGxvd2VkLlxuICAgICAgICBpZiAocGhvbmVEaWdpdHMgJiYgcGhvbmVEaWdpdHNbMF0gPT09ICcrJykge1xuICAgICAgICAgIC8vIFJlbW92ZSB0aGUgYCtgLlxuICAgICAgICAgIHBob25lRGlnaXRzID0gcGhvbmVEaWdpdHMuc2xpY2UoMSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKCFkZWZhdWx0Q291bnRyeSkge1xuICAgICAgLy8gRm9yY2UgYSBgK2AgaW4gdGhlIGJlZ2lubmluZyBvZiBhIGB2YWx1ZWBcbiAgICAgIC8vIHdoZW4gbm8gYGNvdW50cnlgIGFuZCBgZGVmYXVsdENvdW50cnlgIGhhdmUgYmVlbiBzcGVjaWZpZWQuXG4gICAgICBpZiAocGhvbmVEaWdpdHMgJiYgcGhvbmVEaWdpdHNbMF0gIT09ICcrJykge1xuICAgICAgICAvLyBQcmVwZW5kIGEgYCtgLlxuICAgICAgICBwaG9uZURpZ2l0cyA9ICcrJyArIHBob25lRGlnaXRzO1xuICAgICAgfVxuICAgIH0gLy8gQ29udmVydCBgcGhvbmVEaWdpdHNgIHRvIGB2YWx1ZWAuXG5cblxuICAgIGlmIChwaG9uZURpZ2l0cykge1xuICAgICAgdmFsdWUgPSBnZXRWYWx1ZUZvclBob25lRGlnaXRzKHBob25lRGlnaXRzKTtcbiAgICB9XG5cbiAgICBzZXRQaG9uZURpZ2l0cyhwaG9uZURpZ2l0cyk7XG4gICAgc2V0VmFsdWVGb3JQaG9uZURpZ2l0cyh2YWx1ZSk7XG4gIH0sIFtjb3VudHJ5LCBpbnRlcm5hdGlvbmFsLCB3aXRoQ291bnRyeUNhbGxpbmdDb2RlLCBkZWZhdWx0Q291bnRyeSwgbWV0YWRhdGEsIHNldFBob25lRGlnaXRzLCBzZXRWYWx1ZUZvclBob25lRGlnaXRzLCByZXJlbmRlciwgY291bnRyeU1pc21hdGNoRGV0ZWN0ZWRdKTtcbiAgcmV0dXJuIFtwaG9uZURpZ2l0cywgb25TZXRQaG9uZURpZ2l0c107XG59XG4vKipcclxuICogUmV0dXJucyBwaG9uZSBudW1iZXIgaW5wdXQgZmllbGQgdmFsdWUgZm9yIGEgRS4xNjQgcGhvbmUgbnVtYmVyIGB2YWx1ZWAuXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gW3ZhbHVlXVxyXG4gKiBAcGFyYW0gIHtzdHJpbmd9IFtjb3VudHJ5XVxyXG4gKiBAcGFyYW0gIHtib29sZWFufSBbaW50ZXJuYXRpb25hbF1cclxuICogQHBhcmFtICB7Ym9vbGVhbn0gW3dpdGhDb3VudHJ5Q2FsbGluZ0NvZGVdXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gW2RlZmF1bHRDb3VudHJ5XVxyXG4gKiBAcGFyYW0gIHtib29sZWFufSBbdXNlTmF0aW9uYWxGb3JtYXRGb3JEZWZhdWx0Q291bnRyeVZhbHVlXVxyXG4gKiBAcGFyYW0gIHtvYmplY3R9IG1ldGFkYXRhXHJcbiAqIEByZXR1cm4ge3N0cmluZ31cclxuICovXG5cbmZ1bmN0aW9uIGdldFBob25lRGlnaXRzRm9yVmFsdWUodmFsdWUsIGNvdW50cnksIGludGVybmF0aW9uYWwsIHdpdGhDb3VudHJ5Q2FsbGluZ0NvZGUsIGRlZmF1bHRDb3VudHJ5LCB1c2VOYXRpb25hbEZvcm1hdEZvckRlZmF1bHRDb3VudHJ5VmFsdWUsIG1ldGFkYXRhLCBvbkNvdW50cnlNaXNtYXRjaCkge1xuICBpZiAoY291bnRyeSAmJiBpbnRlcm5hdGlvbmFsICYmIHdpdGhDb3VudHJ5Q2FsbGluZ0NvZGUpIHtcbiAgICB2YXIgcHJlZml4ID0gZ2V0SW50ZXJuYXRpb25hbFBob25lTnVtYmVyUHJlZml4KGNvdW50cnksIG1ldGFkYXRhKTtcblxuICAgIGlmICh2YWx1ZSkge1xuICAgICAgaWYgKHZhbHVlLmluZGV4T2YocHJlZml4KSAhPT0gMCkge1xuICAgICAgICBvbkNvdW50cnlNaXNtYXRjaCh2YWx1ZSwgY291bnRyeSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG5cbiAgICByZXR1cm4gcHJlZml4O1xuICB9XG5cbiAgaWYgKCF2YWx1ZSkge1xuICAgIHJldHVybiAnJztcbiAgfVxuXG4gIGlmICghY291bnRyeSAmJiAhZGVmYXVsdENvdW50cnkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICB2YXIgYXNZb3VUeXBlID0gbmV3IEFzWW91VHlwZSh1bmRlZmluZWQsIG1ldGFkYXRhKTtcbiAgYXNZb3VUeXBlLmlucHV0KHZhbHVlKTtcbiAgdmFyIHBob25lTnVtYmVyID0gYXNZb3VUeXBlLmdldE51bWJlcigpO1xuXG4gIGlmIChwaG9uZU51bWJlcikge1xuICAgIGlmIChjb3VudHJ5KSB7XG4gICAgICBpZiAocGhvbmVOdW1iZXIuY291bnRyeSAmJiBwaG9uZU51bWJlci5jb3VudHJ5ICE9PSBjb3VudHJ5KSB7XG4gICAgICAgIG9uQ291bnRyeU1pc21hdGNoKHZhbHVlLCBjb3VudHJ5LCBwaG9uZU51bWJlci5jb3VudHJ5KTtcbiAgICAgIH0gZWxzZSBpZiAocGhvbmVOdW1iZXIuY291bnRyeUNhbGxpbmdDb2RlICE9PSBnZXRDb3VudHJ5Q2FsbGluZ0NvZGUoY291bnRyeSwgbWV0YWRhdGEpKSB7XG4gICAgICAgIG9uQ291bnRyeU1pc21hdGNoKHZhbHVlLCBjb3VudHJ5KTtcbiAgICAgIH1cblxuICAgICAgaWYgKGludGVybmF0aW9uYWwpIHtcbiAgICAgICAgcmV0dXJuIHBob25lTnVtYmVyLm5hdGlvbmFsTnVtYmVyO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gcGFyc2VEaWdpdHMocGhvbmVOdW1iZXIuZm9ybWF0TmF0aW9uYWwoKSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIC8vIGBwaG9uZU51bWJlci5jb3VudHJ5Q2FsbGluZ0NvZGVgIGlzIGNvbXBhcmVkIGhlcmUgIGluc3RlYWQgb2ZcbiAgICAgIC8vIGBwaG9uZU51bWJlci5jb3VudHJ5YCwgYmVjYXVzZSwgZm9yIGV4YW1wbGUsIGEgcGVyc29uIGNvdWxkIGhhdmVcbiAgICAgIC8vIHByZXZpb3VzbHkgaW5wdXQgYSBwaG9uZSBudW1iZXIgKGluIFwibmF0aW9uYWxcIiBmb3JtYXQpIHRoYXQgaXNuJ3RcbiAgICAgIC8vIDEwMCUgdmFsaWQgZm9yIHRoZSBgZGVmYXVsdENvdW50cnlgLCBhbmQgaWYgYHBob25lTnVtYmVyLmNvdW50cnlgXG4gICAgICAvLyB3YXMgY29tcGFyZWQsIHRoZW4gaXQgd291bGRuJ3QgbWF0Y2gsIGFuZCBzdWNoIHBob25lIG51bWJlclxuICAgICAgLy8gd291bGRuJ3QgYmUgZm9ybWF0dGVkIGFzIGEgXCJuYXRpb25hbFwiIG9uZSwgYW5kIGluc3RlYWQgd291bGQgYmVcbiAgICAgIC8vIGZvcm1hdHRlZCBhcyBhbiBcImludGVybmF0aW9uYWxcIiBvbmUsIGNvbmZ1c2luZyB0aGUgdXNlci5cbiAgICAgIC8vIENvbXBhcmluZyBgcGhvbmVOdW1iZXIuY291bnRyeUNhbGxpbmdDb2RlYCB3b3JrcyBhcm91bmQgc3VjaCBpc3N1ZXMuXG4gICAgICAvL1xuICAgICAgLy8gRXhhbXBsZTogYGRlZmF1bHRDb3VudHJ5PVwiVVNcImAgYW5kIHRoZSBgPGlucHV0Lz5gIGlzIGVtcHR5LlxuICAgICAgLy8gVGhlIHVzZXIgaW5wdXRzOiBcIjIyMiAzMzMgNDQ0NFwiLCB3aGljaCBnZXRzIGZvcm1hdHRlZCB0byBcIigyMjIpIDMzMy00NDQ0XCIuXG4gICAgICAvLyBUaGUgdXNlciB0aGVuIGNsaWNrcyBcIlNhdmVcIiwgdGhlIHBhZ2UgaXMgcmVmcmVzaGVkLCBhbmQgdGhlIHVzZXIgc2Vlc1xuICAgICAgLy8gdGhhdCB0aGUgYDxpbnB1dC8+YCB2YWx1ZSBpcyBub3cgXCIrMSAyMjIgMzMzIDQ0NDRcIiB3aGljaCBjb25mdXNlcyB0aGUgdXNlcjpcbiAgICAgIC8vIHRoZSB1c2VyIGV4cGVjdGVkIHRoZSBgPGlucHV0Lz5gIHZhbHVlIHRvIGJlIFwiKDIyMikgMzMzLTQ0NDRcIiwgc2FtZSBhcyBpdFxuICAgICAgLy8gd2FzIHdoZW4gdGhleSd2ZSBqdXN0IHR5cGVkIGl0IGluLiBUaGUgY2F1c2Ugb2YgdGhlIGlzc3VlIGlzIHRoYXQgXCIyMjIgMzMzIDQ0NDRcIlxuICAgICAgLy8gaXMgbm90IGEgdmFsaWQgbmF0aW9uYWwgbnVtYmVyIGZvciBVUywgYW5kIGBwaG9uZU51bWJlci5jb3VudHJ5YCBpcyBjb21wYXJlZFxuICAgICAgLy8gaW5zdGVhZCBvZiBgcGhvbmVOdW1iZXIuY291bnRyeUNhbGxpbmdDb2RlYC4gQWZ0ZXIgdGhlIGBwaG9uZU51bWJlci5jb3VudHJ5YFxuICAgICAgLy8gY29tcGFyaXNvbiBpcyByZXBsYWNlZCB3aXRoIGBwaG9uZU51bWJlci5jb3VudHJ5Q2FsbGluZ0NvZGVgIG9uZSwgdGhlIGlzc3VlXG4gICAgICAvLyBpcyBubyBsb25nZXIgdGhlIGNhc2UuXG4gICAgICAvL1xuICAgICAgaWYgKHBob25lTnVtYmVyLmNvdW50cnlDYWxsaW5nQ29kZSAmJiBwaG9uZU51bWJlci5jb3VudHJ5Q2FsbGluZ0NvZGUgPT09IGdldENvdW50cnlDYWxsaW5nQ29kZShkZWZhdWx0Q291bnRyeSwgbWV0YWRhdGEpICYmIHVzZU5hdGlvbmFsRm9ybWF0Rm9yRGVmYXVsdENvdW50cnlWYWx1ZSkge1xuICAgICAgICByZXR1cm4gcGFyc2VEaWdpdHMocGhvbmVOdW1iZXIuZm9ybWF0TmF0aW9uYWwoKSk7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuICcnO1xuICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD11c2VQaG9uZURpZ2l0cy5qcy5tYXAiXSwibmFtZXMiOlsiSGVhZCIsInVzZVN0YXRlIiwidXNlUm91dGVyIiwidXNlQ29va2llcyIsIlBob25lSW5wdXQiLCJEYXRhIiwidXNlcnMiLCJ1c2VyIiwidGVscyIsInRva2VuIiwicm91dGVyIiwiY29va2llIiwic2V0Q29va2llIiwicmVtb3ZlQ29va2llIiwic2hvd01vZGFsTmV3VXNlciIsInNldFNob3dNb2RhbE5ld1VzZXIiLCJzaG93TW9kYWxOZXdQaG9uZSIsInNldFNob3dNb2RhbE5ld1Bob25lIiwiaW52YWxpZFBhc3N3b3JkIiwic2V0SW52YWxpZFBhc3N3b3JkIiwibG9jYWxVc2VycyIsInNldExvY2FsVXNlcnMiLCJsb2NhbFRlbHMiLCJzZXRMb2NhbFRlbHMiLCJwaG9uZSIsInNldFBob25lIiwib25DbGlja1NhaXIiLCJldmVudCIsImNvbnNvbGUiLCJsb2ciLCJwdXNoIiwicmVsb2FkVXNlcnMiLCJmZXRjaCIsImhlYWRlcnMiLCJtZXRob2QiLCJyZXMiLCJzdGF0dXMiLCJqc29uIiwiYWRkTmV3UGhvbmUiLCJhZGROZXdVc2VyIiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJwYXNzd29yZCIsInZhbHVlIiwicGFzc3dvcmRyZXBlYXQiLCJib2R5IiwiSlNPTiIsInN0cmluZ2lmeSIsInVzZXJuYW1lIiwiZW1haWwiLCJjb25maXJtZWQiLCJibG9ja2VkIiwicm9sZSIsImlkIiwiZGVsZXRlVXNlciIsInVzZXJJRCIsIm1hcCIsInVzciIsImluZGV4IiwidGVsIiwibm9tZSIsInRlbGVmb25lIl0sInNvdXJjZVJvb3QiOiIifQ==