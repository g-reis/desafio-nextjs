"use strict";
self["webpackHotUpdate_N_E"]("pages/data",{

/***/ "./pages/data.js":
/*!***********************!*\
  !*** ./pages/data.js ***!
  \***********************/
/***/ (function(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "__N_SSP": function() { return /* binding */ __N_SSP; },
/* harmony export */   "default": function() { return /* binding */ Data; }
/* harmony export */ });
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/router */ "./node_modules/next/router.js");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-cookie */ "./node_modules/react-cookie/es6/index.js");
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-phone-number-input/input */ "./node_modules/react-phone-number-input/input/index.js");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-phone-number-input/style.css */ "./node_modules/react-phone-number-input/style.css");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__);
/* module decorator */ module = __webpack_require__.hmd(module);



var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\data.js",
    _s = $RefreshSig$();










var __N_SSP = true;
function Data(_ref) {
  _s();

  var _this = this;

  var users = _ref.users,
      user = _ref.user,
      tels = _ref.tels,
      token = _ref.token;
  var router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();

  var _useCookies = (0,react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies)(["user"]),
      _useCookies2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__.default)(_useCookies, 3),
      cookie = _useCookies2[0],
      setCookie = _useCookies2[1],
      removeCookie = _useCookies2[2];

  var _useState = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewUser = _useState[0],
      setShowModalNewUser = _useState[1];

  var _useState2 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalNewPhone = _useState2[0],
      setShowModalNewPhone = _useState2[1];

  var _useState3 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      invalidPassword = _useState3[0],
      setInvalidPassword = _useState3[1];

  var _useState4 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalEditUser = _useState4[0],
      setShowModalEditUser = _useState4[1];

  var _useState5 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(false),
      showModalEditPhone = _useState5[0],
      setShowModalEditPhone = _useState5[1];

  var _useState6 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(users),
      localUsers = _useState6[0],
      setLocalUsers = _useState6[1];

  var _useState7 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(tels),
      localTels = _useState7[0],
      setLocalTels = _useState7[1];

  var _useState8 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phone = _useState8[0],
      setPhone = _useState8[1];

  var _useState9 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      userToEdit = _useState9[0],
      setUserToEdit = _useState9[1];

  var _useState10 = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)(),
      phoneToEdit = _useState10[0],
      setPhoneToEdit = _useState10[1];

  var onClickSair = /*#__PURE__*/function () {
    var _ref2 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee(event) {
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              console.log("Sair");
              removeCookie("user");
              router.push('/');

            case 3:
            case "end":
              return _context.stop();
          }
        }
      }, _callee);
    }));

    return function onClickSair(_x) {
      return _ref2.apply(this, arguments);
    };
  }();

  function reloadTels() {
    return _reloadTels.apply(this, arguments);
  }

  function _reloadTels() {
    _reloadTels = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee6() {
      var resTel;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee6$(_context6) {
        while (1) {
          switch (_context6.prev = _context6.next) {
            case 0:
              _context6.next = 2;
              return fetch('http://localhost:1337/user-data?users_permissions_user.id=' + user.userid, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              resTel = _context6.sent;
              _context6.t0 = setLocalTels;
              _context6.next = 6;
              return resTel.json();

            case 6:
              _context6.t1 = _context6.sent;
              (0, _context6.t0)(_context6.t1);

            case 8:
            case "end":
              return _context6.stop();
          }
        }
      }, _callee6);
    }));
    return _reloadTels.apply(this, arguments);
  }

  function reloadUsers() {
    return _reloadUsers.apply(this, arguments);
  }

  function _reloadUsers() {
    _reloadUsers = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee7() {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee7$(_context7) {
        while (1) {
          switch (_context7.prev = _context7.next) {
            case 0:
              _context7.next = 2;
              return fetch('http://localhost:1337/users', {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'GET'
              });

            case 2:
              res = _context7.sent;

              if (!(res.status == 200)) {
                _context7.next = 9;
                break;
              }

              _context7.t0 = setLocalUsers;
              _context7.next = 7;
              return res.json();

            case 7:
              _context7.t1 = _context7.sent;
              (0, _context7.t0)(_context7.t1);

            case 9:
            case "end":
              return _context7.stop();
          }
        }
      }, _callee7);
    }));
    return _reloadUsers.apply(this, arguments);
  }

  var editPhone = /*#__PURE__*/function () {
    var _ref3 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee2(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee2$(_context2) {
        while (1) {
          switch (_context2.prev = _context2.next) {
            case 0:
              event.preventDefault();
              _context2.next = 3;
              return fetch('http://localhost:1337/user-data/' + event.target.phoneIdHidden.value, {
                body: JSON.stringify({
                  nome: event.target.name.value,
                  telefone: event.target.phone.value
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'PUT'
              });

            case 3:
              res = _context2.sent;

              if (res.status == 200) {
                setShowModalEditPhone(false);
                reloadTels();
              }

            case 5:
            case "end":
              return _context2.stop();
          }
        }
      }, _callee2);
    }));

    return function editPhone(_x2) {
      return _ref3.apply(this, arguments);
    };
  }();

  var addNewPhone = /*#__PURE__*/function () {
    var _ref4 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee3(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee3$(_context3) {
        while (1) {
          switch (_context3.prev = _context3.next) {
            case 0:
              event.preventDefault();
              console.log(event.target.phone);
              _context3.next = 4;
              return fetch('http://localhost:1337/user-data', {
                body: JSON.stringify({
                  nome: event.target.name.value,
                  telefone: event.target.phone.value,
                  users_permissions_user: {
                    id: user.userid
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 4:
              res = _context3.sent;

              if (res.status == 200) {
                reloadTels();
                setShowModalNewPhone(false);
              }

            case 6:
            case "end":
              return _context3.stop();
          }
        }
      }, _callee3);
    }));

    return function addNewPhone(_x3) {
      return _ref4.apply(this, arguments);
    };
  }();

  function deletePhone(_x4) {
    return _deletePhone.apply(this, arguments);
  }

  function _deletePhone() {
    _deletePhone = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee8(phoneID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee8$(_context8) {
        while (1) {
          switch (_context8.prev = _context8.next) {
            case 0:
              _context8.next = 2;
              return fetch('http://localhost:1337/user-data/' + phoneID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context8.sent;

              if (res.status == 200) {
                reloadTels();
              }

            case 4:
            case "end":
              return _context8.stop();
          }
        }
      }, _callee8);
    }));
    return _deletePhone.apply(this, arguments);
  }

  var editUser = /*#__PURE__*/function () {
    var _ref5 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee4(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee4$(_context4) {
        while (1) {
          switch (_context4.prev = _context4.next) {
            case 0:
              event.preventDefault();

              if (!(event.target.password.value !== event.target.passwordrepeat.value)) {
                _context4.next = 4;
                break;
              }

              setInvalidPassword(true);
              return _context4.abrupt("return");

            case 4:
              _context4.next = 6;
              return fetch('http://localhost:1337/users/' + event.target.useridHidden.value, {
                body: JSON.stringify({
                  password: event.target.password.value
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'PUT'
              });

            case 6:
              res = _context4.sent;
              if (res.status == 200) setShowModalEditUser(false);

            case 8:
            case "end":
              return _context4.stop();
          }
        }
      }, _callee4);
    }));

    return function editUser(_x5) {
      return _ref5.apply(this, arguments);
    };
  }();

  var addNewUser = /*#__PURE__*/function () {
    var _ref6 = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee5(event) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee5$(_context5) {
        while (1) {
          switch (_context5.prev = _context5.next) {
            case 0:
              event.preventDefault();

              if (!(event.target.password.value !== event.target.passwordrepeat.value)) {
                _context5.next = 4;
                break;
              }

              setInvalidPassword(true);
              return _context5.abrupt("return");

            case 4:
              _context5.next = 6;
              return fetch('http://localhost:1337/users', {
                body: JSON.stringify({
                  username: event.target.username.value,
                  email: event.target.email.value,
                  password: event.target.password.value,
                  confirmed: true,
                  blocked: false,
                  role: {
                    id: 1
                  }
                }),
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': 'Bearer ' + token
                },
                method: 'POST'
              });

            case 6:
              res = _context5.sent;

              if (res.status == 201) {
                reloadUsers();
                setShowModalNewUser(false);
              }

            case 8:
            case "end":
              return _context5.stop();
          }
        }
      }, _callee5);
    }));

    return function addNewUser(_x6) {
      return _ref6.apply(this, arguments);
    };
  }();

  function deleteUser(_x7) {
    return _deleteUser.apply(this, arguments);
  }

  function _deleteUser() {
    _deleteUser = (0,C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__.default)( /*#__PURE__*/C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().mark(function _callee9(userID) {
      var res;
      return C_Users_gabis_OneDrive_Ambiente_de_Trabalho_Carbonext_Carbonext_Next_JS_carbonext_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default().wrap(function _callee9$(_context9) {
        while (1) {
          switch (_context9.prev = _context9.next) {
            case 0:
              _context9.next = 2;
              return fetch('http://localhost:1337/users/' + userID, {
                headers: {
                  'Authorization': 'Bearer ' + token
                },
                method: 'DELETE'
              });

            case 2:
              res = _context9.sent;

              if (res.status == 200) {
                reloadUsers();
              }

            case 4:
            case "end":
              return _context9.stop();
          }
        }
      }, _callee9);
    }));
    return _deleteUser.apply(this, arguments);
  }

  console.log(users);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_3___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("title", {
        children: "Desafio - Area Restrita"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 201,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 200,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
      className: "bg-gray-50 min-h-screen",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex bg-green-50 shadow",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "justify-between w-full flex justfy-between p-3",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
            className: "self-center text-lg",
            children: ["Bem vindo, ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
              className: "font-bold",
              children: user.username
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 206,
              columnNumber: 74
            }, this), "!"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 206,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
            onClick: onClickSair,
            className: "bg-green-500 text-white rounded-lg px-2 py-2 font-bold flex flex-row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              "class": "h-6 w-6 mr-2",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "currentColor",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
                "stroke-linecap": "round",
                "stroke-linejoin": "round",
                "stroke-width": "2",
                d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 209,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 208,
              columnNumber: 29
            }, this), "Sair"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 207,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 205,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 204,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "flex flex-row",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "flex-grow",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "m-5",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
              onClick: function onClick() {
                setUserToEdit({
                  username: '',
                  email: '',
                  id: ''
                });
                setShowModalNewUser(true);
              },
              className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
              children: "Novo Usu\xE1rio"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 219,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 218,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "m-5 border border-b border-gray-200 flex-grow",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
              className: "min-w-full divide-y divide-gray-200",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
                className: "bg-gray-50",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Nome de Usu\xE1rio"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 232,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "E-mail"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 235,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 238,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 241,
                    columnNumber: 41
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 231,
                  columnNumber: 37
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 230,
                columnNumber: 33
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
                className: "bg-white divide-y divide-gray-200",
                children: localUsers.map(function (usr, index) {
                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                          className: "flex items-center",
                          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                            className: "flex-shrink-0 h-10 w-10",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("svg", {
                              xmlns: "http://www.w3.org/2000/svg",
                              fill: "none",
                              viewBox: "0 0 24 24",
                              stroke: "currentColor",
                              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: "2",
                                d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                              }, void 0, false, {
                                fileName: _jsxFileName,
                                lineNumber: 256,
                                columnNumber: 69
                              }, _this)
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 255,
                              columnNumber: 65
                            }, _this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 254,
                            columnNumber: 61
                          }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                            className: "ml-3",
                            children: usr.username
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 259,
                            columnNumber: 61
                          }, _this)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 253,
                          columnNumber: 57
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 252,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: usr.email
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 262,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            setUserToEdit(usr);
                            setShowModalEditUser(true);
                          },
                          children: "Editar"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 263,
                          columnNumber: 110
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 263,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: usr.username == user.username ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                            href: "javascript:void(0)",
                            onClick: function onClick() {
                              return deleteUser(usr.id);
                            },
                            children: "Excluir"
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 267,
                            columnNumber: 152
                          }, _this)
                        }, void 0, false)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 267,
                        columnNumber: 53
                      }, _this)]
                    }, "{ index }", true, {
                      fileName: _jsxFileName,
                      lineNumber: 251,
                      columnNumber: 49
                    }, _this)
                  }, void 0, false);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 246,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 229,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 228,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 217,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "flex-grow",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "m-5",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
              onClick: function onClick() {
                setPhoneToEdit({
                  telefone: '',
                  nome: '',
                  id: ''
                });
                setPhone(null);
                setShowModalNewPhone(true);
              },
              className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
              children: "Novo Telefone"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 282,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 281,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "m-5 border border-b border-gray-200 flex-grow",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("table", {
              className: "min-w-full divide-y divide-gray-200",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("thead", {
                className: "bg-gray-50",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Nome"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 298,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Telefone"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 301,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 304,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 307,
                    columnNumber: 41
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 297,
                  columnNumber: 37
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 296,
                columnNumber: 33
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tbody", {
                className: "bg-white divide-y divide-gray-200",
                children: localTels.map(function (tel, index) {
                  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("tr", {
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap",
                        children: tel.nome
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 318,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: tel.telefone
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 319,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            setPhoneToEdit(tel);
                            setPhone('+55' + tel.telefone);
                            setShowModalEditPhone(true);
                          },
                          children: "Editar"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 320,
                          columnNumber: 110
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 320,
                        columnNumber: 53
                      }, _this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("td", {
                        className: "px-6 py-4 whitespace-nowrap items-center",
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                          href: "javascript:void(0)",
                          onClick: function onClick() {
                            return deletePhone(tel.id);
                          },
                          children: "Excluir"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 326,
                          columnNumber: 110
                        }, _this)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 326,
                        columnNumber: 53
                      }, _this)]
                    }, "{ index }", true, {
                      fileName: _jsxFileName,
                      lineNumber: 317,
                      columnNumber: 49
                    }, _this)
                  }, void 0, false);
                })
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 312,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 295,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 294,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 280,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 216,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 203,
      columnNumber: 13
    }, this), showModalNewUser || showModalEditUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewUser ? 'Novo Usuário' : null, showModalEditUser ? 'Editar Usuário' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 346,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 345,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: showModalNewUser ? addNewUser : editUser,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "username",
                    className: "mb-3 block text-gray-700",
                    children: "Nome de Usu\xE1rio:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 354,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "username",
                    value: userToEdit.username,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome de Usu\xE1rio",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 355,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 353,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "email",
                    className: "mb-3 block text-gray-700",
                    children: "E-mail:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 360,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "email",
                    id: "email",
                    value: userToEdit.email,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "E-mail",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 361,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 359,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "flex flex-row",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "mr-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "password",
                        className: "mb-3 block text-gray-700",
                        children: "Senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 369,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "password",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Senha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 370,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 368,
                      columnNumber: 49
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                      className: "ml-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                        htmlFor: "passwordrepeat",
                        className: "mb-3 block text-gray-700",
                        children: "Repita a senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 375,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                        type: "password",
                        id: "passwordrepeat",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Repita a enha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 376,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 374,
                      columnNumber: 49
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 367,
                    columnNumber: 45
                  }, this), invalidPassword ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                    className: "mt-1 text-red-400",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("a", {
                      href: "#",
                      children: "As senhas digitadas s\xE3o diferentes"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 383,
                      columnNumber: 53
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 382,
                    columnNumber: 49
                  }, this) : null]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 366,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                  type: "hidden",
                  id: "useridHidden",
                  value: userToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 386,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      setShowModalNewUser(false);
                      setShowModalEditUser(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 388,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    type: "submit",
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 392,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 387,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 352,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 351,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 344,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 343,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 342,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 399,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null, showModalNewPhone || showModalEditPhone ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewPhone ? 'Novo Telefone' : null, showModalEditPhone ? 'Editar Telefone' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 410,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 409,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("form", {
                onSubmit: showModalNewPhone ? addNewPhone : editPhone,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "name",
                    className: "mb-3 block text-gray-700",
                    children: "Nome:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 418,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                    type: "text",
                    id: "name",
                    value: phoneToEdit.nome,
                    onChange: setPhoneToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 419,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 417,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("label", {
                    htmlFor: "phone",
                    className: "mb-3 block text-gray-700",
                    children: "Telefone:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 424,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)(react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_9__.default, {
                    id: "phone",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Telefone",
                    value: phone,
                    country: "BR",
                    onChange: setPhone
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 425,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 423,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("input", {
                  type: "hidden",
                  id: "phoneIdHidden",
                  value: phoneToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 431,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    onClick: function onClick() {
                      setShowModalNewPhone(false);
                      setShowModalEditPhone(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 433,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 437,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 432,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 416,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 415,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 408,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 407,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 406,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 444,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null]
  }, void 0, true);
}

_s(Data, "B6/YLcTC4jCMCb1WxjnN03pgVmY=", false, function () {
  return [next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter, react_cookie__WEBPACK_IMPORTED_MODULE_8__.useCookies];
});

_c = Data;

var _c;

$RefreshReg$(_c, "Data");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.id);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }


/***/ })

});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvZGF0YS5mYWJmZmZjYmM4NTg2NjI4NDYzMC5ob3QtdXBkYXRlLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FBRWUsU0FBU0ssSUFBVCxPQUE0QztBQUFBOztBQUFBOztBQUFBLE1BQTVCQyxLQUE0QixRQUE1QkEsS0FBNEI7QUFBQSxNQUFyQkMsSUFBcUIsUUFBckJBLElBQXFCO0FBQUEsTUFBZkMsSUFBZSxRQUFmQSxJQUFlO0FBQUEsTUFBVEMsS0FBUyxRQUFUQSxLQUFTO0FBQ3ZELE1BQU1DLE1BQU0sR0FBR1Isc0RBQVMsRUFBeEI7O0FBRUEsb0JBQTBDQyx3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXBEO0FBQUE7QUFBQSxNQUFPUSxNQUFQO0FBQUEsTUFBZUMsU0FBZjtBQUFBLE1BQTBCQyxZQUExQjs7QUFDQSxrQkFBZ0RaLCtDQUFRLENBQUMsS0FBRCxDQUF4RDtBQUFBLE1BQU9hLGdCQUFQO0FBQUEsTUFBeUJDLG1CQUF6Qjs7QUFDQSxtQkFBa0RkLCtDQUFRLENBQUMsS0FBRCxDQUExRDtBQUFBLE1BQU9lLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBOENoQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEQ7QUFBQSxNQUFPaUIsZUFBUDtBQUFBLE1BQXdCQyxrQkFBeEI7O0FBQ0EsbUJBQWtEbEIsK0NBQVEsQ0FBQyxLQUFELENBQTFEO0FBQUEsTUFBT21CLGlCQUFQO0FBQUEsTUFBMEJDLG9CQUExQjs7QUFDQSxtQkFBb0RwQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBNUQ7QUFBQSxNQUFPcUIsa0JBQVA7QUFBQSxNQUEyQkMscUJBQTNCOztBQUNBLG1CQUFvQ3RCLCtDQUFRLENBQUNLLEtBQUQsQ0FBNUM7QUFBQSxNQUFPa0IsVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxtQkFBa0N4QiwrQ0FBUSxDQUFDTyxJQUFELENBQTFDO0FBQUEsTUFBT2tCLFNBQVA7QUFBQSxNQUFrQkMsWUFBbEI7O0FBQ0EsbUJBQTBCMUIsK0NBQVEsRUFBbEM7QUFBQSxNQUFPMkIsS0FBUDtBQUFBLE1BQWNDLFFBQWQ7O0FBQ0EsbUJBQW9DNUIsK0NBQVEsRUFBNUM7QUFBQSxNQUFPNkIsVUFBUDtBQUFBLE1BQW1CQyxhQUFuQjs7QUFDQSxvQkFBc0M5QiwrQ0FBUSxFQUE5QztBQUFBLE1BQU8rQixXQUFQO0FBQUEsTUFBb0JDLGNBQXBCOztBQUVBLE1BQU1DLFdBQVc7QUFBQSxzWEFBRyxpQkFBTUMsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2hCQyxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0F4QixjQUFBQSxZQUFZLENBQUMsTUFBRCxDQUFaO0FBQ0FILGNBQUFBLE1BQU0sQ0FBQzRCLElBQVAsQ0FBWSxHQUFaOztBQUhnQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYSixXQUFXO0FBQUE7QUFBQTtBQUFBLEtBQWpCOztBQWZ1RCxXQXFCeENLLFVBckJ3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx3WEFxQnZEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQ3lCQyxLQUFLLENBQ3RCLCtEQUErRGpDLElBQUksQ0FBQ2tDLE1BRDlDLEVBRXRCO0FBQ0lDLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBSUlrQyxnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGc0IsQ0FEOUI7O0FBQUE7QUFDVUMsY0FBQUEsTUFEVjtBQUFBLDZCQVdJakIsWUFYSjtBQUFBO0FBQUEscUJBV3VCaUIsTUFBTSxDQUFDQyxJQUFQLEVBWHZCOztBQUFBO0FBQUE7QUFBQTs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQXJCdUQ7QUFBQTtBQUFBOztBQUFBLFdBbUN4Q0MsV0FuQ3dDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQW1DdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JOLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0lFLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBSUlrQyxnQkFBQUEsTUFBTSxFQUFFO0FBSlosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFBQSxvQkFVUUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FWdEI7QUFBQTtBQUFBO0FBQUE7O0FBQUEsNkJBV1F2QixhQVhSO0FBQUE7QUFBQSxxQkFXNEJzQixHQUFHLENBQUNGLElBQUosRUFYNUI7O0FBQUE7QUFBQTtBQUFBOztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBbkN1RDtBQUFBO0FBQUE7O0FBbUR2RCxNQUFNSSxTQUFTO0FBQUEsc1hBQUcsa0JBQU1kLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2RBLGNBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQURjO0FBQUEscUJBRUlWLEtBQUssQ0FDbkIscUNBQXFDTCxLQUFLLENBQUNnQixNQUFOLENBQWFDLGFBQWIsQ0FBMkJDLEtBRDdDLEVBRW5CO0FBQ0lDLGdCQUFBQSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2pCQyxrQkFBQUEsSUFBSSxFQUFFdEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFhTyxJQUFiLENBQWtCTCxLQURQO0FBRWpCTSxrQkFBQUEsUUFBUSxFQUFFeEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFhdkIsS0FBYixDQUFtQnlCO0FBRlosaUJBQWYsQ0FEVjtBQUtJWCxnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVlqQztBQUZ4QixpQkFMYjtBQVNJa0MsZ0JBQUFBLE1BQU0sRUFBRTtBQVRaLGVBRm1CLENBRlQ7O0FBQUE7QUFFUkksY0FBQUEsR0FGUTs7QUFnQmQsa0JBQUlBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CekIsZ0JBQUFBLHFCQUFxQixDQUFDLEtBQUQsQ0FBckI7QUFDQWdCLGdCQUFBQSxVQUFVO0FBQ2I7O0FBbkJhO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVRVLFNBQVM7QUFBQTtBQUFBO0FBQUEsS0FBZjs7QUF1QkEsTUFBTVcsV0FBVztBQUFBLHNYQUFHLGtCQUFNekIsS0FBTjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDaEJBLGNBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQUNBZCxjQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsS0FBSyxDQUFDZ0IsTUFBTixDQUFhdkIsS0FBekI7QUFGZ0I7QUFBQSxxQkFHRVksS0FBSyxDQUNuQixpQ0FEbUIsRUFFbkI7QUFDSWMsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJDLGtCQUFBQSxJQUFJLEVBQUV0QixLQUFLLENBQUNnQixNQUFOLENBQWFPLElBQWIsQ0FBa0JMLEtBRFA7QUFFakJNLGtCQUFBQSxRQUFRLEVBQUV4QixLQUFLLENBQUNnQixNQUFOLENBQWF2QixLQUFiLENBQW1CeUIsS0FGWjtBQUdqQlEsa0JBQUFBLHNCQUFzQixFQUFFO0FBQ3BCQyxvQkFBQUEsRUFBRSxFQUFFdkQsSUFBSSxDQUFDa0M7QUFEVztBQUhQLGlCQUFmLENBRFY7QUFRSUMsZ0JBQUFBLE9BQU8sRUFBRTtBQUNMLGtDQUFnQixrQkFEWDtBQUVMLG1DQUFpQixZQUFZakM7QUFGeEIsaUJBUmI7QUFhSWtDLGdCQUFBQSxNQUFNLEVBQUU7QUFiWixlQUZtQixDQUhQOztBQUFBO0FBR1ZJLGNBQUFBLEdBSFU7O0FBcUJoQixrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ1Z0QixnQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNIOztBQXhCZTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUFIOztBQUFBLG9CQUFYMkMsV0FBVztBQUFBO0FBQUE7QUFBQSxLQUFqQjs7QUExRXVELFdBcUd4Q0csV0FyR3dDO0FBQUE7QUFBQTs7QUFBQTtBQUFBLHlYQXFHdkQsa0JBQTJCQyxPQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUNzQnhCLEtBQUssQ0FDbkIscUNBQXFDd0IsT0FEbEIsRUFFbkI7QUFDSXRCLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBS0lrQyxnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULGdCQUFBQSxVQUFVO0FBQ2I7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FyR3VEO0FBQUE7QUFBQTs7QUFzSHZELE1BQU0wQixRQUFRO0FBQUEsc1hBQUcsa0JBQU05QixLQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNiQSxjQUFBQSxLQUFLLENBQUNlLGNBQU47O0FBRGEsb0JBRVRmLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWUsUUFBYixDQUFzQmIsS0FBdEIsS0FBZ0NsQixLQUFLLENBQUNnQixNQUFOLENBQWFnQixjQUFiLENBQTRCZCxLQUZuRDtBQUFBO0FBQUE7QUFBQTs7QUFHVGxDLGNBQUFBLGtCQUFrQixDQUFDLElBQUQsQ0FBbEI7QUFIUzs7QUFBQTtBQUFBO0FBQUEscUJBTUtxQixLQUFLLENBQ25CLGlDQUFpQ0wsS0FBSyxDQUFDZ0IsTUFBTixDQUFhaUIsWUFBYixDQUEwQmYsS0FEeEMsRUFFbkI7QUFDSUMsZ0JBQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJVLGtCQUFBQSxRQUFRLEVBQUUvQixLQUFLLENBQUNnQixNQUFOLENBQWFlLFFBQWIsQ0FBc0JiO0FBRGYsaUJBQWYsQ0FEVjtBQUlJWCxnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVlqQztBQUZ4QixpQkFKYjtBQVFJa0MsZ0JBQUFBLE1BQU0sRUFBRTtBQVJaLGVBRm1CLENBTlY7O0FBQUE7QUFNUEksY0FBQUEsR0FOTztBQW1CYixrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFDSTNCLG9CQUFvQixDQUFDLEtBQUQsQ0FBcEI7O0FBcEJTO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEtBQUg7O0FBQUEsb0JBQVI0QyxRQUFRO0FBQUE7QUFBQTtBQUFBLEtBQWQ7O0FBdUJBLE1BQU1JLFVBQVU7QUFBQSxzWEFBRyxrQkFBTWxDLEtBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ2ZBLGNBQUFBLEtBQUssQ0FBQ2UsY0FBTjs7QUFEZSxvQkFFWGYsS0FBSyxDQUFDZ0IsTUFBTixDQUFhZSxRQUFiLENBQXNCYixLQUF0QixLQUFnQ2xCLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWdCLGNBQWIsQ0FBNEJkLEtBRmpEO0FBQUE7QUFBQTtBQUFBOztBQUdYbEMsY0FBQUEsa0JBQWtCLENBQUMsSUFBRCxDQUFsQjtBQUhXOztBQUFBO0FBQUE7QUFBQSxxQkFNR3FCLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0ljLGdCQUFBQSxJQUFJLEVBQUVDLElBQUksQ0FBQ0MsU0FBTCxDQUFlO0FBQ2pCYyxrQkFBQUEsUUFBUSxFQUFFbkMsS0FBSyxDQUFDZ0IsTUFBTixDQUFhbUIsUUFBYixDQUFzQmpCLEtBRGY7QUFFakJrQixrQkFBQUEsS0FBSyxFQUFFcEMsS0FBSyxDQUFDZ0IsTUFBTixDQUFhb0IsS0FBYixDQUFtQmxCLEtBRlQ7QUFHakJhLGtCQUFBQSxRQUFRLEVBQUUvQixLQUFLLENBQUNnQixNQUFOLENBQWFlLFFBQWIsQ0FBc0JiLEtBSGY7QUFJakJtQixrQkFBQUEsU0FBUyxFQUFFLElBSk07QUFLakJDLGtCQUFBQSxPQUFPLEVBQUUsS0FMUTtBQU1qQkMsa0JBQUFBLElBQUksRUFBRTtBQUFFWixvQkFBQUEsRUFBRSxFQUFFO0FBQU47QUFOVyxpQkFBZixDQURWO0FBU0lwQixnQkFBQUEsT0FBTyxFQUFFO0FBQ0wsa0NBQWdCLGtCQURYO0FBRUwsbUNBQWlCLFlBQVlqQztBQUZ4QixpQkFUYjtBQWNJa0MsZ0JBQUFBLE1BQU0sRUFBRTtBQWRaLGVBRm1CLENBTlI7O0FBQUE7QUFNVEksY0FBQUEsR0FOUzs7QUF5QmYsa0JBQUlBLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CRixnQkFBQUEsV0FBVztBQUNYL0IsZ0JBQUFBLG1CQUFtQixDQUFDLEtBQUQsQ0FBbkI7QUFDSDs7QUE1QmM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FBSDs7QUFBQSxvQkFBVnNELFVBQVU7QUFBQTtBQUFBO0FBQUEsS0FBaEI7O0FBN0l1RCxXQTRLeENNLFVBNUt3QztBQUFBO0FBQUE7O0FBQUE7QUFBQSx3WEE0S3ZELGtCQUEwQkMsTUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFDc0JwQyxLQUFLLENBQ25CLGlDQUFpQ29DLE1BRGQsRUFFbkI7QUFDSWxDLGdCQUFBQSxPQUFPLEVBQUU7QUFDTCxtQ0FBaUIsWUFBWWpDO0FBRHhCLGlCQURiO0FBS0lrQyxnQkFBQUEsTUFBTSxFQUFFO0FBTFosZUFGbUIsQ0FEM0I7O0FBQUE7QUFDVUksY0FBQUEsR0FEVjs7QUFZSSxrQkFBSUEsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJGLGdCQUFBQSxXQUFXO0FBQ2Q7O0FBZEw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0E1S3VEO0FBQUE7QUFBQTs7QUE2THZEVixFQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWS9CLEtBQVo7QUFDQSxzQkFDSTtBQUFBLDRCQUNJLDhEQUFDLGtEQUFEO0FBQUEsNkJBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREosZUFJSTtBQUFLLGVBQVMsRUFBQyx5QkFBZjtBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyx5QkFBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyxnREFBZjtBQUFBLGtDQUNJO0FBQU0scUJBQVMsRUFBQyxxQkFBaEI7QUFBQSxtREFBaUQ7QUFBTSx1QkFBUyxFQUFDLFdBQWhCO0FBQUEsd0JBQTZCQyxJQUFJLENBQUMrRDtBQUFsQztBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREosZUFFSTtBQUFRLG1CQUFPLEVBQUVwQyxXQUFqQjtBQUE4QixxQkFBUyxFQUFDLHNFQUF4QztBQUFBLG9DQUNJO0FBQUssbUJBQUssRUFBQyw0QkFBWDtBQUF3Qyx1QkFBTSxjQUE5QztBQUE2RCxrQkFBSSxFQUFDLE1BQWxFO0FBQXlFLHFCQUFPLEVBQUMsV0FBakY7QUFBNkYsb0JBQU0sRUFBQyxjQUFwRztBQUFBLHFDQUNJO0FBQU0sa0NBQWUsT0FBckI7QUFBNkIsbUNBQWdCLE9BQTdDO0FBQXFELGdDQUFhLEdBQWxFO0FBQXNFLGlCQUFDLEVBQUM7QUFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQWFJO0FBQUssaUJBQVMsRUFBQyxlQUFmO0FBQUEsZ0NBQ0k7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxrQ0FDSTtBQUFLLHFCQUFTLEVBQUMsS0FBZjtBQUFBLG1DQUNJO0FBQVEscUJBQU8sRUFBRSxtQkFBTTtBQUNuQkgsZ0JBQUFBLGFBQWEsQ0FBQztBQUNWdUMsa0JBQUFBLFFBQVEsRUFBRSxFQURBO0FBRVZDLGtCQUFBQSxLQUFLLEVBQUUsRUFGRztBQUdWVCxrQkFBQUEsRUFBRSxFQUFFO0FBSE0saUJBQUQsQ0FBYjtBQUtBL0MsZ0JBQUFBLG1CQUFtQixDQUFDLElBQUQsQ0FBbkI7QUFDSCxlQVBEO0FBT0csdUJBQVMsRUFBQyx3REFQYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREosZUFXSTtBQUFLLHFCQUFTLEVBQUMsK0NBQWY7QUFBQSxtQ0FDSTtBQUFPLHVCQUFTLEVBQUMscUNBQWpCO0FBQUEsc0NBQ0k7QUFBTyx5QkFBUyxFQUFDLFlBQWpCO0FBQUEsdUNBQ0k7QUFBQSwwQ0FDSTtBQUFJLHlCQUFLLEVBQUMsS0FBVjtBQUFnQiw2QkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUlJO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUpKLGVBT0k7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVBKLGVBVUk7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREosZUFpQkk7QUFBTyx5QkFBUyxFQUFDLG1DQUFqQjtBQUFBLDBCQUdRUyxVQUFVLENBQUNxRCxHQUFYLENBQWUsVUFBQ0MsR0FBRCxFQUFNQyxLQUFOO0FBQUEsc0NBQ1g7QUFBQSwyQ0FDSTtBQUFBLDhDQUNJO0FBQUksaUNBQVMsRUFBQyw2QkFBZDtBQUFBLCtDQUNJO0FBQUssbUNBQVMsRUFBQyxtQkFBZjtBQUFBLGtEQUNJO0FBQUsscUNBQVMsRUFBQyx5QkFBZjtBQUFBLG1EQUNJO0FBQUssbUNBQUssRUFBQyw0QkFBWDtBQUF3QyxrQ0FBSSxFQUFDLE1BQTdDO0FBQW9ELHFDQUFPLEVBQUMsV0FBNUQ7QUFBd0Usb0NBQU0sRUFBQyxjQUEvRTtBQUFBLHFEQUNJO0FBQU0sNkNBQWEsRUFBQyxPQUFwQjtBQUE0Qiw4Q0FBYyxFQUFDLE9BQTNDO0FBQW1ELDJDQUFXLEVBQUMsR0FBL0Q7QUFBbUUsaUNBQUMsRUFBQztBQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREosZUFNSTtBQUFLLHFDQUFTLEVBQUMsTUFBZjtBQUFBLHNDQUF1QkQsR0FBRyxDQUFDUjtBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREosZUFXSTtBQUFJLGlDQUFTLEVBQUMsMENBQWQ7QUFBQSxrQ0FBMERRLEdBQUcsQ0FBQ1A7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFYSixlQVlJO0FBQUksaUNBQVMsRUFBQywwQ0FBZDtBQUFBLCtDQUF5RDtBQUFHLDhCQUFJLEVBQUMsb0JBQVI7QUFBNkIsaUNBQU8sRUFBRSxtQkFBTTtBQUNqR3hDLDRCQUFBQSxhQUFhLENBQUMrQyxHQUFELENBQWI7QUFDQXpELDRCQUFBQSxvQkFBb0IsQ0FBQyxJQUFELENBQXBCO0FBQ0gsMkJBSHdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBWkosZUFnQkk7QUFBSSxpQ0FBUyxFQUFDLDBDQUFkO0FBQUEsa0NBQTBEeUQsR0FBRyxDQUFDUixRQUFKLElBQWdCL0QsSUFBSSxDQUFDK0QsUUFBckIsR0FBZ0MsSUFBaEMsZ0JBQXVDO0FBQUEsaURBQUU7QUFBRyxnQ0FBSSxFQUFDLG9CQUFSO0FBQTZCLG1DQUFPLEVBQUU7QUFBQSxxQ0FBTUssVUFBVSxDQUFDRyxHQUFHLENBQUNoQixFQUFMLENBQWhCO0FBQUEsNkJBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUY7QUFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFoQko7QUFBQSx1QkFBUSxXQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQ0FEVztBQUFBLGlCQUFmO0FBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBREosZUFnRUk7QUFBSyxtQkFBUyxFQUFDLFdBQWY7QUFBQSxrQ0FDSTtBQUFLLHFCQUFTLEVBQUMsS0FBZjtBQUFBLG1DQUNJO0FBQVEscUJBQU8sRUFDWCxtQkFBTTtBQUNGN0IsZ0JBQUFBLGNBQWMsQ0FBQztBQUNYMEIsa0JBQUFBLFFBQVEsRUFBRSxFQURDO0FBRVhGLGtCQUFBQSxJQUFJLEVBQUUsRUFGSztBQUdYSyxrQkFBQUEsRUFBRSxFQUFFO0FBSE8saUJBQUQsQ0FBZDtBQUtBakMsZ0JBQUFBLFFBQVEsQ0FBQyxJQUFELENBQVI7QUFDQVosZ0JBQUFBLG9CQUFvQixDQUFDLElBQUQsQ0FBcEI7QUFDSCxlQVRMO0FBVUUsdUJBQVMsRUFBQyx3REFWWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBREosZUFjSTtBQUFLLHFCQUFTLEVBQUMsK0NBQWY7QUFBQSxtQ0FDSTtBQUFPLHVCQUFTLEVBQUMscUNBQWpCO0FBQUEsc0NBQ0k7QUFBTyx5QkFBUyxFQUFDLFlBQWpCO0FBQUEsdUNBQ0k7QUFBQSwwQ0FDSTtBQUFJLHlCQUFLLEVBQUMsS0FBVjtBQUFnQiw2QkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUlJO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUMsZ0ZBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUpKLGVBT0k7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVBKLGVBVUk7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQztBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsc0JBREosZUFpQkk7QUFBTyx5QkFBUyxFQUFDLG1DQUFqQjtBQUFBLDBCQUdRUyxTQUFTLENBQUNtRCxHQUFWLENBQWMsVUFBQ0csR0FBRCxFQUFNRCxLQUFOO0FBQUEsc0NBQ1Y7QUFBQSwyQ0FDSTtBQUFBLDhDQUNJO0FBQUksaUNBQVMsRUFBQyw2QkFBZDtBQUFBLGtDQUE2Q0MsR0FBRyxDQUFDdkI7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFESixlQUVJO0FBQUksaUNBQVMsRUFBQywwQ0FBZDtBQUFBLGtDQUEwRHVCLEdBQUcsQ0FBQ3JCO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRkosZUFHSTtBQUFJLGlDQUFTLEVBQUMsMENBQWQ7QUFBQSwrQ0FBeUQ7QUFBRyw4QkFBSSxFQUFDLG9CQUFSO0FBQTZCLGlDQUFPLEVBQUUsbUJBQU07QUFDakcxQiw0QkFBQUEsY0FBYyxDQUFDK0MsR0FBRCxDQUFkO0FBQ0FuRCw0QkFBQUEsUUFBUSxDQUFDLFFBQVFtRCxHQUFHLENBQUNyQixRQUFiLENBQVI7QUFDQXBDLDRCQUFBQSxxQkFBcUIsQ0FBQyxJQUFELENBQXJCO0FBQ0gsMkJBSndEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSEosZUFTSTtBQUFJLGlDQUFTLEVBQUMsMENBQWQ7QUFBQSwrQ0FBeUQ7QUFBRyw4QkFBSSxFQUFDLG9CQUFSO0FBQTZCLGlDQUFPLEVBQUU7QUFBQSxtQ0FBTXdDLFdBQVcsQ0FBQ2lCLEdBQUcsQ0FBQ2xCLEVBQUwsQ0FBakI7QUFBQSwyQkFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFUSjtBQUFBLHVCQUFRLFdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLG1DQURVO0FBQUEsaUJBQWQ7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFoRUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBSkosRUE2SUtoRCxnQkFBZ0IsSUFBSU0saUJBQXBCLGdCQUNHO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLHVIQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHNHQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBGQUFmO0FBQUEscUNBQ0k7QUFBTSx5QkFBUyxFQUFDLGVBQWhCO0FBQUEsMkJBQ0tOLGdCQUFnQixHQUFHLGNBQUgsR0FBb0IsSUFEekMsRUFFS00saUJBQWlCLEdBQUcsZ0JBQUgsR0FBc0IsSUFGNUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQU9JO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLHFDQUNJO0FBQU0sd0JBQVEsRUFBRU4sZ0JBQWdCLEdBQUd1RCxVQUFILEdBQWdCSixRQUFoRDtBQUFBLHdDQUNJO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLFVBQWY7QUFBMEIsNkJBQVMsRUFBQywwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFPLHdCQUFJLEVBQUMsTUFBWjtBQUFtQixzQkFBRSxFQUFDLFVBQXRCO0FBQWlDLHlCQUFLLEVBQUVuQyxVQUFVLENBQUN3QyxRQUFuRDtBQUE2RCw0QkFBUSxFQUFFdkMsYUFBdkU7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxvQkFGaEI7QUFFa0MsNEJBQVEsRUFBRSxDQUFDWCxpQkFGN0M7QUFFZ0UsNEJBQVEsRUFBRUE7QUFGMUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREosZUFPSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQU8sMkJBQU8sRUFBQyxPQUFmO0FBQXVCLDZCQUFTLEVBQUMsMEJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBRUk7QUFBTyx3QkFBSSxFQUFDLE9BQVo7QUFBb0Isc0JBQUUsRUFBQyxPQUF2QjtBQUErQix5QkFBSyxFQUFFVSxVQUFVLENBQUN5QyxLQUFqRDtBQUF3RCw0QkFBUSxFQUFFeEMsYUFBbEU7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxRQUZoQjtBQUV5Qiw0QkFBUSxFQUFFLENBQUNYLGlCQUZwQztBQUV1RCw0QkFBUSxFQUFFQTtBQUZqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQSixlQWNJO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBSyw2QkFBUyxFQUFDLGVBQWY7QUFBQSw0Q0FDSTtBQUFLLCtCQUFTLEVBQUMsTUFBZjtBQUFBLDhDQUNJO0FBQU8sK0JBQU8sRUFBQyxVQUFmO0FBQTBCLGlDQUFTLEVBQUMsMEJBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDhCQURKLGVBRUk7QUFBTyw0QkFBSSxFQUFDLFVBQVo7QUFBdUIsMEJBQUUsRUFBQyxVQUExQjtBQUNJLGlDQUFTLEVBQUMsMEVBRGQ7QUFFSSxtQ0FBVyxFQUFDLE9BRmhCO0FBRXdCLGdDQUFRO0FBRmhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQURKLGVBT0k7QUFBSywrQkFBUyxFQUFDLE1BQWY7QUFBQSw4Q0FDSTtBQUFPLCtCQUFPLEVBQUMsZ0JBQWY7QUFBZ0MsaUNBQVMsRUFBQywwQkFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREosZUFFSTtBQUFPLDRCQUFJLEVBQUMsVUFBWjtBQUF1QiwwQkFBRSxFQUFDLGdCQUExQjtBQUNJLGlDQUFTLEVBQUMsMEVBRGQ7QUFFSSxtQ0FBVyxFQUFDLGVBRmhCO0FBRWdDLGdDQUFRO0FBRnhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixFQWVLRixlQUFlLGdCQUNaO0FBQUssNkJBQVMsRUFBQyxtQkFBZjtBQUFBLDJDQUNJO0FBQUcsMEJBQUksRUFBQyxHQUFSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFEWSxHQUdILElBbEJqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZEosZUFrQ0k7QUFBTyxzQkFBSSxFQUFDLFFBQVo7QUFBcUIsb0JBQUUsRUFBQyxjQUF4QjtBQUF1Qyx1QkFBSyxFQUFFWSxVQUFVLENBQUNnQztBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQWxDSixlQW1DSTtBQUFLLDJCQUFTLEVBQUMsd0ZBQWY7QUFBQSwwQ0FDSTtBQUFRLDJCQUFPLEVBQUUsbUJBQU07QUFDbkIvQyxzQkFBQUEsbUJBQW1CLENBQUMsS0FBRCxDQUFuQjtBQUNBTSxzQkFBQUEsb0JBQW9CLENBQUMsS0FBRCxDQUFwQjtBQUNILHFCQUhEO0FBR0csNkJBQVMsRUFBQywyREFIYjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUtJO0FBQVEsd0JBQUksRUFBQyxRQUFiO0FBQXNCLDZCQUFTLEVBQUMsd0RBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBMERJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0ExREo7QUFBQSxvQkFESCxHQTZERyxJQTFNUixFQTZNS0wsaUJBQWlCLElBQUlNLGtCQUFyQixnQkFDRztBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyx1SEFBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyx3Q0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxzR0FBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQywwRkFBZjtBQUFBLHFDQUNJO0FBQU0seUJBQVMsRUFBQyxlQUFoQjtBQUFBLDJCQUNLTixpQkFBaUIsR0FBRyxlQUFILEdBQXFCLElBRDNDLEVBRUtNLGtCQUFrQixHQUFHLGlCQUFILEdBQXVCLElBRjlDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFPSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSxxQ0FDSTtBQUFNLHdCQUFRLEVBQUVOLGlCQUFpQixHQUFHNEMsV0FBSCxHQUFpQlgsU0FBbEQ7QUFBQSx3Q0FDSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQU8sMkJBQU8sRUFBQyxNQUFmO0FBQXNCLDZCQUFTLEVBQUMsMEJBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBRUk7QUFBTyx3QkFBSSxFQUFDLE1BQVo7QUFBbUIsc0JBQUUsRUFBQyxNQUF0QjtBQUE2Qix5QkFBSyxFQUFFakIsV0FBVyxDQUFDeUIsSUFBaEQ7QUFBc0QsNEJBQVEsRUFBRXhCLGNBQWhFO0FBQ0ksNkJBQVMsRUFBQywwRUFEZDtBQUVJLCtCQUFXLEVBQUMsTUFGaEI7QUFFdUIsNEJBQVE7QUFGL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBREosZUFPSTtBQUFLLDJCQUFTLEVBQUMsTUFBZjtBQUFBLDBDQUNJO0FBQU8sMkJBQU8sRUFBQyxPQUFmO0FBQXVCLDZCQUFTLEVBQUMsMEJBQWpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBRUksOERBQUMsbUVBQUQ7QUFBWSxzQkFBRSxFQUFDLE9BQWY7QUFBdUIsNkJBQVMsRUFBQywwRUFBakM7QUFDSSwrQkFBVyxFQUFDLFVBRGhCO0FBRUkseUJBQUssRUFBRUwsS0FGWDtBQUdJLDJCQUFPLEVBQUMsSUFIWjtBQUlJLDRCQUFRLEVBQUVDO0FBSmQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBUEosZUFlSTtBQUFPLHNCQUFJLEVBQUMsUUFBWjtBQUFxQixvQkFBRSxFQUFDLGVBQXhCO0FBQXdDLHVCQUFLLEVBQUVHLFdBQVcsQ0FBQzhCO0FBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBZkosZUFnQkk7QUFBSywyQkFBUyxFQUFDLHdGQUFmO0FBQUEsMENBQ0k7QUFBUSwyQkFBTyxFQUFFLG1CQUFNO0FBQ25CN0Msc0JBQUFBLG9CQUFvQixDQUFDLEtBQUQsQ0FBcEI7QUFDQU0sc0JBQUFBLHFCQUFxQixDQUFDLEtBQUQsQ0FBckI7QUFDSCxxQkFIRDtBQUdHLDZCQUFTLEVBQUMsMkRBSGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFLSTtBQUFRLDZCQUFTLEVBQUMsd0RBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBdUNJO0FBQUssaUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0F2Q0o7QUFBQSxvQkFESCxHQTBDRyxJQXZQUjtBQUFBLGtCQURKO0FBMlBIOztHQXpidUJsQjtVQUNMSCxvREFFMkJDOzs7S0FIdEJFIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vX05fRS8uL3BhZ2VzL2RhdGEuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJ1xyXG5pbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xyXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICduZXh0L3JvdXRlcidcclxuaW1wb3J0IHsgdXNlQ29va2llcyB9IGZyb20gXCJyZWFjdC1jb29raWVcIlxyXG5pbXBvcnQgUGhvbmVJbnB1dCBmcm9tICdyZWFjdC1waG9uZS1udW1iZXItaW5wdXQvaW5wdXQnXHJcbmltcG9ydCAncmVhY3QtcGhvbmUtbnVtYmVyLWlucHV0L3N0eWxlLmNzcydcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIERhdGEoeyB1c2VycywgdXNlciwgdGVscywgdG9rZW4gfSkge1xyXG4gICAgY29uc3Qgcm91dGVyID0gdXNlUm91dGVyKClcclxuXHJcbiAgICBjb25zdCBbY29va2llLCBzZXRDb29raWUsIHJlbW92ZUNvb2tpZV0gPSB1c2VDb29raWVzKFtcInVzZXJcIl0pXHJcbiAgICBjb25zdCBbc2hvd01vZGFsTmV3VXNlciwgc2V0U2hvd01vZGFsTmV3VXNlcl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxOZXdQaG9uZSwgc2V0U2hvd01vZGFsTmV3UGhvbmVdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbaW52YWxpZFBhc3N3b3JkLCBzZXRJbnZhbGlkUGFzc3dvcmRdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbc2hvd01vZGFsRWRpdFVzZXIsIHNldFNob3dNb2RhbEVkaXRVc2VyXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbEVkaXRQaG9uZSwgc2V0U2hvd01vZGFsRWRpdFBob25lXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW2xvY2FsVXNlcnMsIHNldExvY2FsVXNlcnNdID0gdXNlU3RhdGUodXNlcnMpXHJcbiAgICBjb25zdCBbbG9jYWxUZWxzLCBzZXRMb2NhbFRlbHNdID0gdXNlU3RhdGUodGVscylcclxuICAgIGNvbnN0IFtwaG9uZSwgc2V0UGhvbmVdID0gdXNlU3RhdGUoKVxyXG4gICAgY29uc3QgW3VzZXJUb0VkaXQsIHNldFVzZXJUb0VkaXRdID0gdXNlU3RhdGUoKTtcclxuICAgIGNvbnN0IFtwaG9uZVRvRWRpdCwgc2V0UGhvbmVUb0VkaXRdID0gdXNlU3RhdGUoKTtcclxuXHJcbiAgICBjb25zdCBvbkNsaWNrU2FpciA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBjb25zb2xlLmxvZyhcIlNhaXJcIilcclxuICAgICAgICByZW1vdmVDb29raWUoXCJ1c2VyXCIpXHJcbiAgICAgICAgcm91dGVyLnB1c2goJy8nKVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHJlbG9hZFRlbHMoKSB7XHJcbiAgICAgICAgY29uc3QgcmVzVGVsID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhP3VzZXJzX3Blcm1pc3Npb25zX3VzZXIuaWQ9JyArIHVzZXIudXNlcmlkLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgc2V0TG9jYWxUZWxzKGF3YWl0IHJlc1RlbC5qc29uKCkpXHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gcmVsb2FkVXNlcnMoKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMnLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgc2V0TG9jYWxVc2Vycyhhd2FpdCByZXMuanNvbigpKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZWRpdFBob25lID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VyLWRhdGEvJyArIGV2ZW50LnRhcmdldC5waG9uZUlkSGlkZGVuLnZhbHVlLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgbm9tZTogZXZlbnQudGFyZ2V0Lm5hbWUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsZWZvbmU6IGV2ZW50LnRhcmdldC5waG9uZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BVVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFBob25lKGZhbHNlKVxyXG4gICAgICAgICAgICByZWxvYWRUZWxzKClcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFkZE5ld1Bob25lID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBjb25zb2xlLmxvZyhldmVudC50YXJnZXQucGhvbmUpXHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhJyxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIG5vbWU6IGV2ZW50LnRhcmdldC5uYW1lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbGVmb25lOiBldmVudC50YXJnZXQucGhvbmUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXNlcnNfcGVybWlzc2lvbnNfdXNlcjoge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZDogdXNlci51c2VyaWRcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVGVscygpXHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1Bob25lKGZhbHNlKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiBkZWxldGVQaG9uZShwaG9uZUlEKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhLycgKyBwaG9uZUlELFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdERUxFVEUnXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMCkge1xyXG4gICAgICAgICAgICByZWxvYWRUZWxzKClcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgY29uc3QgZWRpdFVzZXIgPSBhc3luYyBldmVudCA9PiB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIGlmIChldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUgIT09IGV2ZW50LnRhcmdldC5wYXNzd29yZHJlcGVhdC52YWx1ZSkge1xyXG4gICAgICAgICAgICBzZXRJbnZhbGlkUGFzc3dvcmQodHJ1ZSlcclxuICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzLycgKyBldmVudC50YXJnZXQudXNlcmlkSGlkZGVuLnZhbHVlLFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGV2ZW50LnRhcmdldC5wYXNzd29yZC52YWx1ZSxcclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BVVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApXHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRVc2VyKGZhbHNlKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGFkZE5ld1VzZXIgPSBhc3luYyBldmVudCA9PiB7XHJcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxyXG4gICAgICAgIGlmIChldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUgIT09IGV2ZW50LnRhcmdldC5wYXNzd29yZHJlcGVhdC52YWx1ZSkge1xyXG4gICAgICAgICAgICBzZXRJbnZhbGlkUGFzc3dvcmQodHJ1ZSlcclxuICAgICAgICAgICAgcmV0dXJuXHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzJyxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiBldmVudC50YXJnZXQudXNlcm5hbWUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgZW1haWw6IGV2ZW50LnRhcmdldC5lbWFpbC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBwYXNzd29yZDogZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbmZpcm1lZDogdHJ1ZSxcclxuICAgICAgICAgICAgICAgICAgICBibG9ja2VkOiBmYWxzZSxcclxuICAgICAgICAgICAgICAgICAgICByb2xlOiB7IGlkOiAxIH1cclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXHJcbiAgICAgICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQT1NUJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIGlmIChyZXMuc3RhdHVzID09IDIwMSkge1xyXG4gICAgICAgICAgICByZWxvYWRVc2VycygpXHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIoZmFsc2UpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVVzZXIodXNlcklEKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMvJyArIHVzZXJJRCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJ1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZyh1c2VycylcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8dGl0bGU+RGVzYWZpbyAtIEFyZWEgUmVzdHJpdGE8L3RpdGxlPlxyXG4gICAgICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdiZy1ncmF5LTUwIG1pbi1oLXNjcmVlbic+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctZ3JlZW4tNTAgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGZsZXgganVzdGZ5LWJldHdlZW4gcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nc2VsZi1jZW50ZXIgdGV4dC1sZyc+QmVtIHZpbmRvLCA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtYm9sZCc+e3VzZXIudXNlcm5hbWV9PC9zcGFuPiE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja1NhaXJ9IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtMiBweS0yIGZvbnQtYm9sZCBmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBjbGFzcz1cImgtNiB3LTYgbXItMlwiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImN1cnJlbnRDb2xvclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwYXRoIHN0cm9rZS1saW5lY2FwPVwicm91bmRcIiBzdHJva2UtbGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZS13aWR0aD1cIjJcIiBkPVwiTTE3IDE2bDQtNG0wIDBsLTQtNG00IDRIN202IDR2MWEzIDMgMCAwMS0zIDNINmEzIDMgMCAwMS0zLTNWN2EzIDMgMCAwMTMtM2g0YTMgMyAwIDAxMyAzdjFcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBTYWlyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVzZXJUb0VkaXQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVtYWlsOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ6ICcnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fSBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5Ob3ZvIFVzdcOhcmlvPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNSBib3JkZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIGZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9tZSBkZSBVc3XDoXJpb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEUtbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxVc2Vycy5tYXAoKHVzciwgaW5kZXgpID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHIga2V5PVwieyBpbmRleCB9XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtc2hyaW5rLTAgaC0xMCB3LTEwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3ZnIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiBmaWxsPVwibm9uZVwiIHZpZXdCb3g9XCIwIDAgMjQgMjRcIiBzdHJva2U9XCJjdXJyZW50Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8cGF0aCBzdHJva2VMaW5lY2FwPVwicm91bmRcIiBzdHJva2VMaW5lam9pbj1cInJvdW5kXCIgc3Ryb2tlV2lkdGg9XCIyXCIgZD1cIk0xNiA3YTQgNCAwIDExLTggMCA0IDQgMCAwMTggMHpNMTIgMTRhNyA3IDAgMDAtNyA3aDE0YTcgNyAwIDAwLTctN3pcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9zdmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1sLTNcIj57dXNyLnVzZXJuYW1lfTwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3Vzci5lbWFpbH08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPSdqYXZhc2NyaXB0OnZvaWQoMCknIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRVc2VyVG9FZGl0KHVzcilcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0VXNlcih0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0+RWRpdGFyPC9hPjwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt1c3IudXNlcm5hbWUgPT0gdXNlci51c2VybmFtZSA/IG51bGwgOiA8PjxhIGhyZWY9J2phdmFzY3JpcHQ6dm9pZCgwKScgb25DbGljaz17KCkgPT4gZGVsZXRlVXNlcih1c3IuaWQpfT5FeGNsdWlyPC9hPjwvPn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZVRvRWRpdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZWxlZm9uZTogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub21lOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZShudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZSh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+Tm92byBUZWxlZm9uZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTUgYm9yZGVyIGJvcmRlci1iIGJvcmRlci1ncmF5LTIwMCBmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0YWJsZSBjbGFzc05hbWU9XCJtaW4tdy1mdWxsIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aGVhZCBjbGFzc05hbWU9XCJiZy1ncmF5LTUwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIE5vbWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUZWxlZm9uZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxUZWxzLm1hcCgodGVsLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ciBrZXk9XCJ7IGluZGV4IH1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj57dGVsLm5vbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3RlbC50ZWxlZm9uZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPSdqYXZhc2NyaXB0OnZvaWQoMCknIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZVRvRWRpdCh0ZWwpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGhvbmUoJys1NScgKyB0ZWwudGVsZWZvbmUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFBob25lKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9PkVkaXRhcjwvYT48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPSdqYXZhc2NyaXB0OnZvaWQoMCknIG9uQ2xpY2s9eygpID0+IGRlbGV0ZVBob25lKHRlbC5pZCl9PkV4Y2x1aXI8L2E+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90Ym9keT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGFibGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgey8qIE1vZGFsIE5ld1VzZXIgKi99XHJcbiAgICAgICAgICAgIHtzaG93TW9kYWxOZXdVc2VyIHx8IHNob3dNb2RhbEVkaXRVc2VyID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBmbGV4IG92ZXJmbG93LXgtaGlkZGVuIG92ZXJmbG93LXktYXV0byBmaXhlZCBpbnNldC0wIHotNTAgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctYXV0byBteS0yIG14LWF1dG8gbWF4LXctM3hsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci0wIHJvdW5kZWQtbGcgc2hhZG93LWxnIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgdy1mdWxsIGJnLXdoaXRlIG91dGxpbmUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIHAtNSBib3JkZXItYiBib3JkZXItc29saWQgYm9yZGVyLWJsdWVHcmF5LTIwMCByb3VuZGVkLXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dNb2RhbE5ld1VzZXIgPyAnTm92byBVc3XDoXJpbycgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dNb2RhbEVkaXRVc2VyID8gJ0VkaXRhciBVc3XDoXJpbycgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTYgZmxleC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtzaG93TW9kYWxOZXdVc2VyID8gYWRkTmV3VXNlciA6IGVkaXRVc2VyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwidXNlcm5hbWVcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5Ob21lIGRlIFVzdcOhcmlvOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgaWQ9XCJ1c2VybmFtZVwiIHZhbHVlPXt1c2VyVG9FZGl0LnVzZXJuYW1lfSBvbkNoYW5nZT17c2V0VXNlclRvRWRpdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJOb21lIGRlIFVzdcOhcmlvXCIgcmVxdWlyZWQ9eyFzaG93TW9kYWxFZGl0VXNlcn0gZGlzYWJsZWQ9e3Nob3dNb2RhbEVkaXRVc2VyfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cImVtYWlsXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+RS1tYWlsOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJlbWFpbFwiIGlkPVwiZW1haWxcIiB2YWx1ZT17dXNlclRvRWRpdC5lbWFpbH0gb25DaGFuZ2U9e3NldFVzZXJUb0VkaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiRS1tYWlsXCIgcmVxdWlyZWQ9eyFzaG93TW9kYWxFZGl0VXNlcn0gZGlzYWJsZWQ9e3Nob3dNb2RhbEVkaXRVc2VyfSAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21iLTYnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXJvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nbXItMic+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBhc3N3b3JkXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+U2VuaGE6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwicGFzc3dvcmRcIiBpZD1cInBhc3N3b3JkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiU2VuaGFcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21sLTInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZHJlcGVhdFwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPlJlcGl0YSBhIHNlbmhhOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJwYXNzd29yZHJlcGVhdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlJlcGl0YSBhIGVuaGFcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aW52YWxpZFBhc3N3b3JkID9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtdC0xIHRleHQtcmVkLTQwMFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIj5BcyBzZW5oYXMgZGlnaXRhZGFzIHPDo28gZGlmZXJlbnRlczwvYT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+IDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9J2hpZGRlbicgaWQ9J3VzZXJpZEhpZGRlbicgdmFsdWU9e3VzZXJUb0VkaXQuaWR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC1iXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRVc2VyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBteC0yIGZvbnQtYm9sZFwiPkZlY2hhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gdHlwZT0nc3VibWl0JyBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWx2YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTI1IGZpeGVkIGluc2V0LTAgei00MCBiZy1ibGFja1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG5cclxuICAgICAgICAgICAgey8qIE1vZGFsIE5ld1Bob25lICovfVxyXG4gICAgICAgICAgICB7c2hvd01vZGFsTmV3UGhvbmUgfHwgc2hvd01vZGFsRWRpdFBob25lID8gKFxyXG4gICAgICAgICAgICAgICAgPD5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlciBmbGV4IG92ZXJmbG93LXgtaGlkZGVuIG92ZXJmbG93LXktYXV0byBmaXhlZCBpbnNldC0wIHotNTAgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHctYXV0byBteS0yIG14LWF1dG8gbWF4LXctM3hsXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlci0wIHJvdW5kZWQtbGcgc2hhZG93LWxnIHJlbGF0aXZlIGZsZXggZmxleC1jb2wgdy1mdWxsIGJnLXdoaXRlIG91dGxpbmUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtc3RhcnQganVzdGlmeS1iZXR3ZWVuIHAtNSBib3JkZXItYiBib3JkZXItc29saWQgYm9yZGVyLWJsdWVHcmF5LTIwMCByb3VuZGVkLXRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1zZW1pYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dNb2RhbE5ld1Bob25lID8gJ05vdm8gVGVsZWZvbmUnIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93TW9kYWxFZGl0UGhvbmUgPyAnRWRpdGFyIFRlbGVmb25lJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiBmbGV4LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3Nob3dNb2RhbE5ld1Bob25lID8gYWRkTmV3UGhvbmUgOiBlZGl0UGhvbmV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJuYW1lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+Tm9tZTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwibmFtZVwiIHZhbHVlPXtwaG9uZVRvRWRpdC5ub21lfSBvbkNoYW5nZT17c2V0UGhvbmVUb0VkaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZVwiIHJlcXVpcmVkIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGhvbmVcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5UZWxlZm9uZTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQaG9uZUlucHV0IGlkPVwicGhvbmVcIiBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlRlbGVmb25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3Bob25lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb3VudHJ5PVwiQlJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17c2V0UGhvbmV9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPSdoaWRkZW4nIGlkPSdwaG9uZUlkSGlkZGVuJyB2YWx1ZT17cGhvbmVUb0VkaXQuaWR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktZW5kIHB0LTYgYm9yZGVyLXQgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC1iXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1Bob25lKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0UGhvbmUoZmFsc2UpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX0gY2xhc3NOYW1lPVwiYmctcmVkLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIG14LTIgZm9udC1ib2xkXCI+RmVjaGFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJiZy1ncmVlbi01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBmb250LWJvbGRcIj5TYWx2YXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Zvcm0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJvcGFjaXR5LTI1IGZpeGVkIGluc2V0LTAgei00MCBiZy1ibGFja1wiPjwvZGl2PlxyXG4gICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICkgOiBudWxsfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKVxyXG59XHJcblxyXG5cclxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlcnZlclNpZGVQcm9wcyhjdHgsIHJlcSkge1xyXG4gICAgaWYgKCFjdHgucmVxLmNvb2tpZXMudXNlcilcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICByZWRpcmVjdDoge1xyXG4gICAgICAgICAgICAgICAgcGVybWFuZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uOiBcIi9cIixcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcHJvcHM6IHt9LFxyXG4gICAgICAgIH07XHJcbiAgICBjb25zdCB0b2tlbiA9IEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpLnRva2VuXHJcbiAgICBjb25zdCB1c2VyaWQgPSBKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS51c2VyaWRcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMnLFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiAnQmVhcmVyICcgKyB0b2tlblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGlmIChyZXMuc3RhdHVzICE9IDIwMCkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIHJlZGlyZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBwZXJtYW5lbnQ6IGZhbHNlLFxyXG4gICAgICAgICAgICAgICAgZGVzdGluYXRpb246IFwiL2xvZ2luXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHByb3BzOiB7fSxcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHJlc1RlbCA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhP3VzZXJzX3Blcm1pc3Npb25zX3VzZXIuaWQ9JyArIHVzZXJpZCxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBjb25zdCB1c2VycyA9IGF3YWl0IHJlcy5qc29uKClcclxuICAgIGNvbnN0IHRlbHMgPSBhd2FpdCByZXNUZWwuanNvbigpXHJcbiAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcilcclxuICAgIGNvbnNvbGUubG9nKEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpLnRva2VuKVxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgICBwcm9wczoge1xyXG4gICAgICAgICAgICB1c2VycyxcclxuICAgICAgICAgICAgdXNlcixcclxuICAgICAgICAgICAgdGVscyxcclxuICAgICAgICAgICAgdG9rZW5cclxuICAgICAgICB9LFxyXG5cclxuICAgIH1cclxufSJdLCJuYW1lcyI6WyJIZWFkIiwidXNlU3RhdGUiLCJ1c2VSb3V0ZXIiLCJ1c2VDb29raWVzIiwiUGhvbmVJbnB1dCIsIkRhdGEiLCJ1c2VycyIsInVzZXIiLCJ0ZWxzIiwidG9rZW4iLCJyb3V0ZXIiLCJjb29raWUiLCJzZXRDb29raWUiLCJyZW1vdmVDb29raWUiLCJzaG93TW9kYWxOZXdVc2VyIiwic2V0U2hvd01vZGFsTmV3VXNlciIsInNob3dNb2RhbE5ld1Bob25lIiwic2V0U2hvd01vZGFsTmV3UGhvbmUiLCJpbnZhbGlkUGFzc3dvcmQiLCJzZXRJbnZhbGlkUGFzc3dvcmQiLCJzaG93TW9kYWxFZGl0VXNlciIsInNldFNob3dNb2RhbEVkaXRVc2VyIiwic2hvd01vZGFsRWRpdFBob25lIiwic2V0U2hvd01vZGFsRWRpdFBob25lIiwibG9jYWxVc2VycyIsInNldExvY2FsVXNlcnMiLCJsb2NhbFRlbHMiLCJzZXRMb2NhbFRlbHMiLCJwaG9uZSIsInNldFBob25lIiwidXNlclRvRWRpdCIsInNldFVzZXJUb0VkaXQiLCJwaG9uZVRvRWRpdCIsInNldFBob25lVG9FZGl0Iiwib25DbGlja1NhaXIiLCJldmVudCIsImNvbnNvbGUiLCJsb2ciLCJwdXNoIiwicmVsb2FkVGVscyIsImZldGNoIiwidXNlcmlkIiwiaGVhZGVycyIsIm1ldGhvZCIsInJlc1RlbCIsImpzb24iLCJyZWxvYWRVc2VycyIsInJlcyIsInN0YXR1cyIsImVkaXRQaG9uZSIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwicGhvbmVJZEhpZGRlbiIsInZhbHVlIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJub21lIiwibmFtZSIsInRlbGVmb25lIiwiYWRkTmV3UGhvbmUiLCJ1c2Vyc19wZXJtaXNzaW9uc191c2VyIiwiaWQiLCJkZWxldGVQaG9uZSIsInBob25lSUQiLCJlZGl0VXNlciIsInBhc3N3b3JkIiwicGFzc3dvcmRyZXBlYXQiLCJ1c2VyaWRIaWRkZW4iLCJhZGROZXdVc2VyIiwidXNlcm5hbWUiLCJlbWFpbCIsImNvbmZpcm1lZCIsImJsb2NrZWQiLCJyb2xlIiwiZGVsZXRlVXNlciIsInVzZXJJRCIsIm1hcCIsInVzciIsImluZGV4IiwidGVsIl0sInNvdXJjZVJvb3QiOiIifQ==