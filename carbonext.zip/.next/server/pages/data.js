(() => {
var exports = {};
exports.id = "pages/data";
exports.ids = ["pages/data"];
exports.modules = {

/***/ "./pages/data.js":
/*!***********************!*\
  !*** ./pages/data.js ***!
  \***********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Data),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-cookie */ "react-cookie");
/* harmony import */ var react_cookie__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_cookie__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-phone-number-input/input */ "react-phone-number-input/input");
/* harmony import */ var react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-phone-number-input/style.css */ "./node_modules/react-phone-number-input/style.css");
/* harmony import */ var react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_phone_number_input_style_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__);
var _jsxFileName = "C:\\Users\\gabis\\OneDrive\\Ambiente de Trabalho\\Carbonext\\Carbonext Next.JS\\carbonext\\pages\\data.js";








function Data({
  users,
  user,
  tels,
  token
}) {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
  const [cookie, setCookie, removeCookie] = (0,react_cookie__WEBPACK_IMPORTED_MODULE_3__.useCookies)(["user"]);
  const {
    0: showModalNewUser,
    1: setShowModalNewUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: showModalNewPhone,
    1: setShowModalNewPhone
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: invalidPassword,
    1: setInvalidPassword
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: showModalEditUser,
    1: setShowModalEditUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: showModalEditPhone,
    1: setShowModalEditPhone
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: erroUser,
    1: setErroUser
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
  const {
    0: localUsers,
    1: setLocalUsers
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(users);
  const {
    0: localTels,
    1: setLocalTels
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(tels);
  const {
    0: phone,
    1: setPhone
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
  const {
    0: userToEdit,
    1: setUserToEdit
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();
  const {
    0: phoneToEdit,
    1: setPhoneToEdit
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)();

  const onClickSair = async event => {
    console.log("Sair");
    removeCookie("user");
    router.push('/');
  };

  async function reloadTels() {
    const resTel = await fetch('http://localhost:1337/user-data?users_permissions_user.id=' + user.userid, {
      headers: {
        'Authorization': 'Bearer ' + token
      },
      method: 'GET'
    });
    setLocalTels(await resTel.json());
  }

  async function reloadUsers() {
    const res = await fetch('http://localhost:1337/users', {
      headers: {
        'Authorization': 'Bearer ' + token
      },
      method: 'GET'
    });

    if (res.status == 200) {
      setLocalUsers(await res.json());
    }
  }

  const editPhone = async event => {
    event.preventDefault();
    const res = await fetch('http://localhost:1337/user-data/' + event.target.phoneIdHidden.value, {
      body: JSON.stringify({
        nome: event.target.name.value,
        telefone: event.target.phone.value
      }),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      method: 'PUT'
    });

    if (res.status == 200) {
      setShowModalEditPhone(false);
      reloadTels();
    }
  };

  const addNewPhone = async event => {
    event.preventDefault();
    console.log(event.target.phone);
    const res = await fetch('http://localhost:1337/user-data', {
      body: JSON.stringify({
        nome: event.target.name.value,
        telefone: event.target.phone.value,
        users_permissions_user: {
          id: user.userid
        }
      }),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      method: 'POST'
    });

    if (res.status == 200) {
      reloadTels();
      setShowModalNewPhone(false);
    }
  };

  async function deletePhone(phoneID) {
    const res = await fetch('http://localhost:1337/user-data/' + phoneID, {
      headers: {
        'Authorization': 'Bearer ' + token
      },
      method: 'DELETE'
    });

    if (res.status == 200) {
      reloadTels();
    }
  }

  const editUser = async event => {
    event.preventDefault();

    if (event.target.password.value !== event.target.passwordrepeat.value) {
      setInvalidPassword(true);
      return;
    }

    const res = await fetch('http://localhost:1337/users/' + event.target.useridHidden.value, {
      body: JSON.stringify({
        password: event.target.password.value
      }),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      method: 'PUT'
    });
    if (res.status == 200) setShowModalEditUser(false);
  };

  const addNewUser = async event => {
    event.preventDefault();

    if (event.target.password.value !== event.target.passwordrepeat.value) {
      setInvalidPassword(true);
      return;
    }

    const res = await fetch('http://localhost:1337/users', {
      body: JSON.stringify({
        username: event.target.username.value,
        email: event.target.email.value,
        password: event.target.password.value,
        confirmed: true,
        blocked: false,
        role: {
          id: 1
        }
      }),
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer ' + token
      },
      method: 'POST'
    });

    if (res.status == 201) {
      reloadUsers();
      setShowModalNewUser(false);
    } else {
      setErroUser(true);
    }
  };

  async function deleteUser(userID) {
    const res = await fetch('http://localhost:1337/users/' + userID, {
      headers: {
        'Authorization': 'Bearer ' + token
      },
      method: 'DELETE'
    });

    if (res.status == 200) {
      reloadUsers();
    }
  }

  console.log(users);
  return /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((next_head__WEBPACK_IMPORTED_MODULE_0___default()), {
      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("title", {
        children: "Desafio - Area Restrita"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 206,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 205,
      columnNumber: 13
    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
      className: "bg-gray-50 min-h-screen",
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "flex bg-green-50 shadow",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "justify-between w-full flex justfy-between p-3",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
            className: "self-center text-lg",
            children: ["Bem vindo, ", /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
              className: "font-bold",
              children: user.username
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 211,
              columnNumber: 74
            }, this), "!"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 211,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
            onClick: onClickSair,
            className: "bg-green-500 text-white rounded-lg pl-4 pr-5 py-2 font-bold flex flex-row",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("svg", {
              xmlns: "http://www.w3.org/2000/svg",
              className: "h-6 w-6 mr-3",
              fill: "none",
              viewBox: "0 0 24 24",
              stroke: "white",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("path", {
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: "2",
                d: "M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 214,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 213,
              columnNumber: 29
            }, this), "Sair"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 212,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 210,
          columnNumber: 21
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 209,
        columnNumber: 17
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "flex flex-row",
        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "flex-grow",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "m-5",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
              onClick: () => {
                setUserToEdit({
                  username: '',
                  email: '',
                  id: ''
                });
                setErroUser(false);
                setShowModalNewUser(true);
              },
              className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
              children: "Novo Usu\xE1rio"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 224,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 223,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "m-5 border border-gray-200 flex-grow",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "text-center border-b border-gray-200 text-lg",
              children: "Usu\xE1rios"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 235,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("table", {
              className: "min-w-full divide-y divide-gray-200",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("thead", {
                className: "bg-gray-50",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Nome de Usu\xE1rio"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 239,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "E-mail"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 242,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 245,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 248,
                    columnNumber: 41
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 238,
                  columnNumber: 37
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 237,
                columnNumber: 33
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tbody", {
                className: "bg-white divide-y divide-gray-200",
                children: localUsers.map(usr => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                        className: "flex items-center",
                        children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                          className: "flex-shrink-0 h-10 w-10",
                          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            stroke: "black",
                            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("path", {
                              strokeLinecap: "round",
                              strokeLinejoin: "round",
                              strokeWidth: "2",
                              d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            }, void 0, false, {
                              fileName: _jsxFileName,
                              lineNumber: 263,
                              columnNumber: 69
                            }, this)
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 262,
                            columnNumber: 65
                          }, this)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 261,
                          columnNumber: 61
                        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                          className: "ml-3",
                          children: usr.username
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 266,
                          columnNumber: 61
                        }, this)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 260,
                        columnNumber: 57
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 259,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.email
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 269,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("a", {
                        href: "#",
                        onClick: () => {
                          setUserToEdit(usr);
                          setShowModalEditUser(true);
                        },
                        children: "Editar"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 270,
                        columnNumber: 110
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 270,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: usr.username == user.username ? null : /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
                        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("a", {
                          href: "#",
                          onClick: () => deleteUser(usr.id),
                          children: "Excluir"
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 274,
                          columnNumber: 152
                        }, this)
                      }, void 0, false)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 274,
                      columnNumber: 53
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 258,
                    columnNumber: 49
                  }, this)
                }, void 0, false))
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 253,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 236,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 234,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 222,
          columnNumber: 21
        }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "flex-grow",
          children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "m-5",
            children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
              onClick: () => {
                setPhoneToEdit({
                  telefone: '',
                  nome: '',
                  id: ''
                });
                setPhone(null);
                setShowModalNewPhone(true);
              },
              className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
              children: "Novo Telefone"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 289,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 288,
            columnNumber: 25
          }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "m-5 border border-gray-200 flex-grow",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "text-center border-b border-gray-200 text-lg",
              children: "Telefones"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 302,
              columnNumber: 29
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("table", {
              className: "min-w-full divide-y divide-gray-200",
              children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("thead", {
                className: "bg-gray-50",
                children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tr", {
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Nome"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 306,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider",
                    children: "Telefone"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 309,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 312,
                    columnNumber: 41
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("th", {
                    scope: "col",
                    className: "relative px-6 py-3"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 315,
                    columnNumber: 41
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 305,
                  columnNumber: 37
                }, this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 304,
                columnNumber: 33
              }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tbody", {
                className: "bg-white divide-y divide-gray-200",
                children: localTels.map(tel => /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
                  children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("tr", {
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap",
                      children: tel.nome
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 326,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: tel.telefone
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 327,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("a", {
                        href: "#",
                        onClick: () => {
                          setPhoneToEdit(tel);
                          setPhone('+55' + tel.telefone);
                          setShowModalEditPhone(true);
                        },
                        children: "Editar"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 328,
                        columnNumber: 110
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 328,
                      columnNumber: 53
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("td", {
                      className: "px-6 py-4 whitespace-nowrap items-center",
                      children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("a", {
                        href: "#",
                        onClick: () => deletePhone(tel.id),
                        children: "Excluir"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 334,
                        columnNumber: 110
                      }, this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 334,
                      columnNumber: 53
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 325,
                    columnNumber: 49
                  }, this)
                }, void 0, false))
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 320,
                columnNumber: 33
              }, this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 303,
              columnNumber: 29
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 301,
            columnNumber: 25
          }, this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 287,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 221,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 208,
      columnNumber: 13
    }, this), showModalNewUser || showModalEditUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewUser ? 'Novo Usuário' : null, showModalEditUser ? 'Editar Usuário' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 354,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 353,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("form", {
                onSubmit: showModalNewUser ? addNewUser : editUser,
                children: [erroUser ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative space-x-1 mb-4 text-center",
                  role: "alert",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("strong", {
                    className: "font-bold",
                    children: "Erro!"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 363,
                    columnNumber: 49
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
                    className: "block sm:inline",
                    children: "O nome de usu\xE1rio j\xE1 existe"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 364,
                    columnNumber: 49
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 362,
                  columnNumber: 45
                }, this) : null, /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                    htmlFor: "username",
                    className: "mb-3 block text-gray-700",
                    children: "Nome de Usu\xE1rio:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 367,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                    type: "text",
                    id: "username",
                    value: userToEdit.username,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome de Usu\xE1rio",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 368,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 366,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                    htmlFor: "email",
                    className: "mb-3 block text-gray-700",
                    children: "E-mail:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 373,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                    type: "email",
                    id: "email",
                    value: userToEdit.email,
                    onChange: setUserToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "E-mail",
                    required: !showModalEditUser,
                    disabled: showModalEditUser
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 374,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 372,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                    className: "flex flex-row",
                    children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                      className: "mr-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                        htmlFor: "password",
                        className: "mb-3 block text-gray-700",
                        children: "Senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 382,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                        type: "password",
                        id: "password",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Senha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 383,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 381,
                      columnNumber: 49
                    }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                      className: "ml-2",
                      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                        htmlFor: "passwordrepeat",
                        className: "mb-3 block text-gray-700",
                        children: "Repita a senha:"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 388,
                        columnNumber: 53
                      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                        type: "password",
                        id: "passwordrepeat",
                        className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                        placeholder: "Repita a enha",
                        required: true
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 389,
                        columnNumber: 53
                      }, this)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 387,
                      columnNumber: 49
                    }, this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 380,
                    columnNumber: 45
                  }, this), invalidPassword ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                    className: "mt-1 text-red-400",
                    children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("a", {
                      href: "#",
                      children: "As senhas digitadas s\xE3o diferentes"
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 396,
                      columnNumber: 53
                    }, this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 395,
                    columnNumber: 49
                  }, this) : null]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 379,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                  type: "hidden",
                  id: "useridHidden",
                  value: userToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 399,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
                    onClick: () => {
                      setShowModalNewUser(false);
                      setShowModalEditUser(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 401,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
                    type: "submit",
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 405,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 400,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 360,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 359,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 352,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 351,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 350,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 412,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null, showModalNewPhone || showModalEditPhone ? /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.Fragment, {
      children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "justify-center items-center flex overflow-x-hidden overflow-y-auto fixed inset-0 z-50 outline-none focus:outline-none",
        children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
          className: "relative w-auto my-2 mx-auto max-w-3xl",
          children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
            className: "border-0 rounded-lg shadow-lg relative flex flex-col w-full bg-white outline-none focus:outline-none",
            children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "flex items-start justify-between p-5 border-b border-solid border-blueGray-200 rounded-t",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("span", {
                className: "font-semibold",
                children: [showModalNewPhone ? 'Novo Telefone' : null, showModalEditPhone ? 'Editar Telefone' : null]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 423,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 422,
              columnNumber: 33
            }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
              className: "relative p-6 flex-auto",
              children: /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("form", {
                onSubmit: showModalNewPhone ? addNewPhone : editPhone,
                children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                    htmlFor: "name",
                    className: "mb-3 block text-gray-700",
                    children: "Nome:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 431,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                    type: "text",
                    id: "name",
                    value: phoneToEdit.nome,
                    onChange: setPhoneToEdit,
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Nome",
                    required: true
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 432,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 430,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "mb-6",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("label", {
                    htmlFor: "phone",
                    className: "mb-3 block text-gray-700",
                    children: "Telefone:"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 437,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)((react_phone_number_input_input__WEBPACK_IMPORTED_MODULE_4___default()), {
                    id: "phone",
                    className: "bg-white rounded-md border border-gray-400 p-3 focus:outline-none w-full",
                    placeholder: "Telefone",
                    value: phone,
                    country: "BR",
                    onChange: setPhone
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 438,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 436,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("input", {
                  type: "hidden",
                  id: "phoneIdHidden",
                  value: phoneToEdit.id
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 444,
                  columnNumber: 41
                }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
                  className: "flex items-center justify-end pt-6 border-t border-solid border-blueGray-200 rounded-b",
                  children: [/*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
                    onClick: () => {
                      setShowModalNewPhone(false);
                      setShowModalEditPhone(false);
                    },
                    className: "bg-red-500 text-white rounded-lg px-5 py-2 mx-2 font-bold",
                    children: "Fechar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 446,
                    columnNumber: 45
                  }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("button", {
                    className: "bg-green-500 text-white rounded-lg px-5 py-2 font-bold",
                    children: "Salvar"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 450,
                    columnNumber: 45
                  }, this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 445,
                  columnNumber: 41
                }, this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 429,
                columnNumber: 37
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 428,
              columnNumber: 33
            }, this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 421,
            columnNumber: 29
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 420,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 419,
        columnNumber: 21
      }, this), /*#__PURE__*/(0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxDEV)("div", {
        className: "opacity-25 fixed inset-0 z-40 bg-black"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 457,
        columnNumber: 21
      }, this)]
    }, void 0, true) : null]
  }, void 0, true);
}
async function getServerSideProps(ctx, req) {
  if (!ctx.req.cookies.user) return {
    redirect: {
      permanent: false,
      destination: "/"
    },
    props: {}
  };
  const token = JSON.parse(ctx.req.cookies.user).token;
  const userid = JSON.parse(ctx.req.cookies.user).userid;
  const res = await fetch('http://localhost:1337/users', {
    headers: {
      'Authorization': 'Bearer ' + token
    },
    method: 'GET'
  });

  if (res.status != 200) {
    return {
      redirect: {
        permanent: false,
        destination: "/login"
      },
      props: {}
    };
  }

  const resTel = await fetch('http://localhost:1337/user-data?users_permissions_user.id=' + userid, {
    headers: {
      'Authorization': 'Bearer ' + token
    },
    method: 'GET'
  });
  const users = await res.json();
  const tels = await resTel.json();
  const user = JSON.parse(ctx.req.cookies.user);
  console.log(JSON.parse(ctx.req.cookies.user).token);
  return {
    props: {
      users,
      user,
      tels,
      token
    }
  };
}

/***/ }),

/***/ "./node_modules/react-phone-number-input/style.css":
/*!*********************************************************!*\
  !*** ./node_modules/react-phone-number-input/style.css ***!
  \*********************************************************/
/***/ (() => {



/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-cookie":
/*!*******************************!*\
  !*** external "react-cookie" ***!
  \*******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-cookie");

/***/ }),

/***/ "react-phone-number-input/input":
/*!*************************************************!*\
  !*** external "react-phone-number-input/input" ***!
  \*************************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-phone-number-input/input");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/data.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZXMvZGF0YS5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7OztBQUVlLFNBQVNLLElBQVQsQ0FBYztBQUFFQyxFQUFBQSxLQUFGO0FBQVNDLEVBQUFBLElBQVQ7QUFBZUMsRUFBQUEsSUFBZjtBQUFxQkMsRUFBQUE7QUFBckIsQ0FBZCxFQUE0QztBQUN2RCxRQUFNQyxNQUFNLEdBQUdSLHNEQUFTLEVBQXhCO0FBRUEsUUFBTSxDQUFDUyxNQUFELEVBQVNDLFNBQVQsRUFBb0JDLFlBQXBCLElBQW9DVix3REFBVSxDQUFDLENBQUMsTUFBRCxDQUFELENBQXBEO0FBQ0EsUUFBTTtBQUFBLE9BQUNXLGdCQUFEO0FBQUEsT0FBbUJDO0FBQW5CLE1BQTBDZCwrQ0FBUSxDQUFDLEtBQUQsQ0FBeEQ7QUFDQSxRQUFNO0FBQUEsT0FBQ2UsaUJBQUQ7QUFBQSxPQUFvQkM7QUFBcEIsTUFBNENoQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBMUQ7QUFDQSxRQUFNO0FBQUEsT0FBQ2lCLGVBQUQ7QUFBQSxPQUFrQkM7QUFBbEIsTUFBd0NsQiwrQ0FBUSxDQUFDLEtBQUQsQ0FBdEQ7QUFDQSxRQUFNO0FBQUEsT0FBQ21CLGlCQUFEO0FBQUEsT0FBb0JDO0FBQXBCLE1BQTRDcEIsK0NBQVEsQ0FBQyxLQUFELENBQTFEO0FBQ0EsUUFBTTtBQUFBLE9BQUNxQixrQkFBRDtBQUFBLE9BQXFCQztBQUFyQixNQUE4Q3RCLCtDQUFRLENBQUMsS0FBRCxDQUE1RDtBQUVBLFFBQU07QUFBQSxPQUFDdUIsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJ4QiwrQ0FBUSxDQUFDLEtBQUQsQ0FBeEM7QUFFQSxRQUFNO0FBQUEsT0FBQ3lCLFVBQUQ7QUFBQSxPQUFhQztBQUFiLE1BQThCMUIsK0NBQVEsQ0FBQ0ssS0FBRCxDQUE1QztBQUNBLFFBQU07QUFBQSxPQUFDc0IsU0FBRDtBQUFBLE9BQVlDO0FBQVosTUFBNEI1QiwrQ0FBUSxDQUFDTyxJQUFELENBQTFDO0FBQ0EsUUFBTTtBQUFBLE9BQUNzQixLQUFEO0FBQUEsT0FBUUM7QUFBUixNQUFvQjlCLCtDQUFRLEVBQWxDO0FBQ0EsUUFBTTtBQUFBLE9BQUMrQixVQUFEO0FBQUEsT0FBYUM7QUFBYixNQUE4QmhDLCtDQUFRLEVBQTVDO0FBQ0EsUUFBTTtBQUFBLE9BQUNpQyxXQUFEO0FBQUEsT0FBY0M7QUFBZCxNQUFnQ2xDLCtDQUFRLEVBQTlDOztBQUVBLFFBQU1tQyxXQUFXLEdBQUcsTUFBTUMsS0FBTixJQUFlO0FBQy9CQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBQ0ExQixJQUFBQSxZQUFZLENBQUMsTUFBRCxDQUFaO0FBQ0FILElBQUFBLE1BQU0sQ0FBQzhCLElBQVAsQ0FBWSxHQUFaO0FBQ0gsR0FKRDs7QUFNQSxpQkFBZUMsVUFBZixHQUE0QjtBQUN4QixVQUFNQyxNQUFNLEdBQUcsTUFBTUMsS0FBSyxDQUN0QiwrREFBK0RwQyxJQUFJLENBQUNxQyxNQUQ5QyxFQUV0QjtBQUNJQyxNQUFBQSxPQUFPLEVBQUU7QUFDTCx5QkFBaUIsWUFBWXBDO0FBRHhCLE9BRGI7QUFJSXFDLE1BQUFBLE1BQU0sRUFBRTtBQUpaLEtBRnNCLENBQTFCO0FBVUFqQixJQUFBQSxZQUFZLENBQUMsTUFBTWEsTUFBTSxDQUFDSyxJQUFQLEVBQVAsQ0FBWjtBQUNIOztBQUVELGlCQUFlQyxXQUFmLEdBQTZCO0FBQ3pCLFVBQU1DLEdBQUcsR0FBRyxNQUFNTixLQUFLLENBQ25CLDZCQURtQixFQUVuQjtBQUNJRSxNQUFBQSxPQUFPLEVBQUU7QUFDTCx5QkFBaUIsWUFBWXBDO0FBRHhCLE9BRGI7QUFJSXFDLE1BQUFBLE1BQU0sRUFBRTtBQUpaLEtBRm1CLENBQXZCOztBQVNBLFFBQUlHLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CdkIsTUFBQUEsYUFBYSxDQUFDLE1BQU1zQixHQUFHLENBQUNGLElBQUosRUFBUCxDQUFiO0FBQ0g7QUFFSjs7QUFFRCxRQUFNSSxTQUFTLEdBQUcsTUFBTWQsS0FBTixJQUFlO0FBQzdCQSxJQUFBQSxLQUFLLENBQUNlLGNBQU47QUFDQSxVQUFNSCxHQUFHLEdBQUcsTUFBTU4sS0FBSyxDQUNuQixxQ0FBcUNOLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYUMsYUFBYixDQUEyQkMsS0FEN0MsRUFFbkI7QUFDSUMsTUFBQUEsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFdEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFhTyxJQUFiLENBQWtCTCxLQURQO0FBRWpCTSxRQUFBQSxRQUFRLEVBQUV4QixLQUFLLENBQUNnQixNQUFOLENBQWF2QixLQUFiLENBQW1CeUI7QUFGWixPQUFmLENBRFY7QUFLSVYsTUFBQUEsT0FBTyxFQUFFO0FBQ0wsd0JBQWdCLGtCQURYO0FBRUwseUJBQWlCLFlBQVlwQztBQUZ4QixPQUxiO0FBU0lxQyxNQUFBQSxNQUFNLEVBQUU7QUFUWixLQUZtQixDQUF2Qjs7QUFjQSxRQUFJRyxHQUFHLENBQUNDLE1BQUosSUFBYyxHQUFsQixFQUF1QjtBQUNuQjNCLE1BQUFBLHFCQUFxQixDQUFDLEtBQUQsQ0FBckI7QUFDQWtCLE1BQUFBLFVBQVU7QUFDYjtBQUVKLEdBckJEOztBQXVCQSxRQUFNcUIsV0FBVyxHQUFHLE1BQU16QixLQUFOLElBQWU7QUFDL0JBLElBQUFBLEtBQUssQ0FBQ2UsY0FBTjtBQUNBZCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUYsS0FBSyxDQUFDZ0IsTUFBTixDQUFhdkIsS0FBekI7QUFDQSxVQUFNbUIsR0FBRyxHQUFHLE1BQU1OLEtBQUssQ0FDbkIsaUNBRG1CLEVBRW5CO0FBQ0lhLE1BQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJDLFFBQUFBLElBQUksRUFBRXRCLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYU8sSUFBYixDQUFrQkwsS0FEUDtBQUVqQk0sUUFBQUEsUUFBUSxFQUFFeEIsS0FBSyxDQUFDZ0IsTUFBTixDQUFhdkIsS0FBYixDQUFtQnlCLEtBRlo7QUFHakJRLFFBQUFBLHNCQUFzQixFQUFFO0FBQ3BCQyxVQUFBQSxFQUFFLEVBQUV6RCxJQUFJLENBQUNxQztBQURXO0FBSFAsT0FBZixDQURWO0FBUUlDLE1BQUFBLE9BQU8sRUFBRTtBQUNMLHdCQUFnQixrQkFEWDtBQUVMLHlCQUFpQixZQUFZcEM7QUFGeEIsT0FSYjtBQWFJcUMsTUFBQUEsTUFBTSxFQUFFO0FBYlosS0FGbUIsQ0FBdkI7O0FBa0JBLFFBQUlHLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CVCxNQUFBQSxVQUFVO0FBQ1Z4QixNQUFBQSxvQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0g7QUFDSixHQXpCRDs7QUEyQkEsaUJBQWVnRCxXQUFmLENBQTJCQyxPQUEzQixFQUFvQztBQUNoQyxVQUFNakIsR0FBRyxHQUFHLE1BQU1OLEtBQUssQ0FDbkIscUNBQXFDdUIsT0FEbEIsRUFFbkI7QUFDSXJCLE1BQUFBLE9BQU8sRUFBRTtBQUNMLHlCQUFpQixZQUFZcEM7QUFEeEIsT0FEYjtBQUtJcUMsTUFBQUEsTUFBTSxFQUFFO0FBTFosS0FGbUIsQ0FBdkI7O0FBV0EsUUFBSUcsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkJULE1BQUFBLFVBQVU7QUFDYjtBQUNKOztBQUVELFFBQU0wQixRQUFRLEdBQUcsTUFBTTlCLEtBQU4sSUFBZTtBQUM1QkEsSUFBQUEsS0FBSyxDQUFDZSxjQUFOOztBQUNBLFFBQUlmLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWUsUUFBYixDQUFzQmIsS0FBdEIsS0FBZ0NsQixLQUFLLENBQUNnQixNQUFOLENBQWFnQixjQUFiLENBQTRCZCxLQUFoRSxFQUF1RTtBQUNuRXBDLE1BQUFBLGtCQUFrQixDQUFDLElBQUQsQ0FBbEI7QUFDQTtBQUNIOztBQUNELFVBQU04QixHQUFHLEdBQUcsTUFBTU4sS0FBSyxDQUNuQixpQ0FBaUNOLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWlCLFlBQWIsQ0FBMEJmLEtBRHhDLEVBRW5CO0FBQ0lDLE1BQUFBLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDakJVLFFBQUFBLFFBQVEsRUFBRS9CLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWUsUUFBYixDQUFzQmI7QUFEZixPQUFmLENBRFY7QUFJSVYsTUFBQUEsT0FBTyxFQUFFO0FBQ0wsd0JBQWdCLGtCQURYO0FBRUwseUJBQWlCLFlBQVlwQztBQUZ4QixPQUpiO0FBUUlxQyxNQUFBQSxNQUFNLEVBQUU7QUFSWixLQUZtQixDQUF2QjtBQWFBLFFBQUlHLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQ0k3QixvQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ1AsR0FyQkQ7O0FBdUJBLFFBQU1rRCxVQUFVLEdBQUcsTUFBTWxDLEtBQU4sSUFBZTtBQUM5QkEsSUFBQUEsS0FBSyxDQUFDZSxjQUFOOztBQUNBLFFBQUlmLEtBQUssQ0FBQ2dCLE1BQU4sQ0FBYWUsUUFBYixDQUFzQmIsS0FBdEIsS0FBZ0NsQixLQUFLLENBQUNnQixNQUFOLENBQWFnQixjQUFiLENBQTRCZCxLQUFoRSxFQUF1RTtBQUNuRXBDLE1BQUFBLGtCQUFrQixDQUFDLElBQUQsQ0FBbEI7QUFDQTtBQUNIOztBQUNELFVBQU04QixHQUFHLEdBQUcsTUFBTU4sS0FBSyxDQUNuQiw2QkFEbUIsRUFFbkI7QUFDSWEsTUFBQUEsSUFBSSxFQUFFQyxJQUFJLENBQUNDLFNBQUwsQ0FBZTtBQUNqQmMsUUFBQUEsUUFBUSxFQUFFbkMsS0FBSyxDQUFDZ0IsTUFBTixDQUFhbUIsUUFBYixDQUFzQmpCLEtBRGY7QUFFakJrQixRQUFBQSxLQUFLLEVBQUVwQyxLQUFLLENBQUNnQixNQUFOLENBQWFvQixLQUFiLENBQW1CbEIsS0FGVDtBQUdqQmEsUUFBQUEsUUFBUSxFQUFFL0IsS0FBSyxDQUFDZ0IsTUFBTixDQUFhZSxRQUFiLENBQXNCYixLQUhmO0FBSWpCbUIsUUFBQUEsU0FBUyxFQUFFLElBSk07QUFLakJDLFFBQUFBLE9BQU8sRUFBRSxLQUxRO0FBTWpCQyxRQUFBQSxJQUFJLEVBQUU7QUFBRVosVUFBQUEsRUFBRSxFQUFFO0FBQU47QUFOVyxPQUFmLENBRFY7QUFTSW5CLE1BQUFBLE9BQU8sRUFBRTtBQUNMLHdCQUFnQixrQkFEWDtBQUVMLHlCQUFpQixZQUFZcEM7QUFGeEIsT0FUYjtBQWNJcUMsTUFBQUEsTUFBTSxFQUFFO0FBZFosS0FGbUIsQ0FBdkI7O0FBbUJBLFFBQUlHLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CRixNQUFBQSxXQUFXO0FBQ1hqQyxNQUFBQSxtQkFBbUIsQ0FBQyxLQUFELENBQW5CO0FBQ0gsS0FIRCxNQUdPO0FBQ0hVLE1BQUFBLFdBQVcsQ0FBQyxJQUFELENBQVg7QUFDSDtBQUNKLEdBL0JEOztBQWlDQSxpQkFBZW9ELFVBQWYsQ0FBMEJDLE1BQTFCLEVBQWtDO0FBQzlCLFVBQU03QixHQUFHLEdBQUcsTUFBTU4sS0FBSyxDQUNuQixpQ0FBaUNtQyxNQURkLEVBRW5CO0FBQ0lqQyxNQUFBQSxPQUFPLEVBQUU7QUFDTCx5QkFBaUIsWUFBWXBDO0FBRHhCLE9BRGI7QUFLSXFDLE1BQUFBLE1BQU0sRUFBRTtBQUxaLEtBRm1CLENBQXZCOztBQVdBLFFBQUlHLEdBQUcsQ0FBQ0MsTUFBSixJQUFjLEdBQWxCLEVBQXVCO0FBQ25CRixNQUFBQSxXQUFXO0FBQ2Q7QUFDSjs7QUFFRFYsRUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlqQyxLQUFaO0FBQ0Esc0JBQ0k7QUFBQSw0QkFDSSw4REFBQyxrREFBRDtBQUFBLDZCQUNJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBSUk7QUFBSyxlQUFTLEVBQUMseUJBQWY7QUFBQSw4QkFDSTtBQUFLLGlCQUFTLEVBQUMseUJBQWY7QUFBQSwrQkFDSTtBQUFLLG1CQUFTLEVBQUMsZ0RBQWY7QUFBQSxrQ0FDSTtBQUFNLHFCQUFTLEVBQUMscUJBQWhCO0FBQUEsbURBQWlEO0FBQU0sdUJBQVMsRUFBQyxXQUFoQjtBQUFBLHdCQUE2QkMsSUFBSSxDQUFDaUU7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURKLGVBRUk7QUFBUSxtQkFBTyxFQUFFcEMsV0FBakI7QUFBOEIscUJBQVMsRUFBQywyRUFBeEM7QUFBQSxvQ0FDSTtBQUFLLG1CQUFLLEVBQUMsNEJBQVg7QUFBd0MsdUJBQVMsRUFBQyxjQUFsRDtBQUFpRSxrQkFBSSxFQUFDLE1BQXRFO0FBQTZFLHFCQUFPLEVBQUMsV0FBckY7QUFBaUcsb0JBQU0sRUFBQyxPQUF4RztBQUFBLHFDQUNJO0FBQU0sNkJBQWEsRUFBQyxPQUFwQjtBQUE0Qiw4QkFBYyxFQUFDLE9BQTNDO0FBQW1ELDJCQUFXLEVBQUMsR0FBL0Q7QUFBbUUsaUJBQUMsRUFBQztBQUFyRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsa0JBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQURKLGVBYUk7QUFBSyxpQkFBUyxFQUFDLGVBQWY7QUFBQSxnQ0FDSTtBQUFLLG1CQUFTLEVBQUMsV0FBZjtBQUFBLGtDQUNJO0FBQUsscUJBQVMsRUFBQyxLQUFmO0FBQUEsbUNBQ0k7QUFBUSxxQkFBTyxFQUFFLE1BQU07QUFDbkJILGdCQUFBQSxhQUFhLENBQUM7QUFDVnVDLGtCQUFBQSxRQUFRLEVBQUUsRUFEQTtBQUVWQyxrQkFBQUEsS0FBSyxFQUFFLEVBRkc7QUFHVlQsa0JBQUFBLEVBQUUsRUFBRTtBQUhNLGlCQUFELENBQWI7QUFLQXZDLGdCQUFBQSxXQUFXLENBQUMsS0FBRCxDQUFYO0FBQ0FWLGdCQUFBQSxtQkFBbUIsQ0FBQyxJQUFELENBQW5CO0FBQ0gsZUFSRDtBQVFHLHVCQUFTLEVBQUMsd0RBUmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURKLGVBWUk7QUFBSyxxQkFBUyxFQUFDLHNDQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDhDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBRUk7QUFBTyx1QkFBUyxFQUFDLHFDQUFqQjtBQUFBLHNDQUNJO0FBQU8seUJBQVMsRUFBQyxZQUFqQjtBQUFBLHVDQUNJO0FBQUEsMENBQ0k7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFJSTtBQUFJLHlCQUFLLEVBQUMsS0FBVjtBQUFnQiw2QkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFKSixlQU9JO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFQSixlQVVJO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURKLGVBaUJJO0FBQU8seUJBQVMsRUFBQyxtQ0FBakI7QUFBQSwwQkFHUVcsVUFBVSxDQUFDcUQsR0FBWCxDQUFnQkMsR0FBRCxpQkFDWDtBQUFBLHlDQUNJO0FBQUEsNENBQ0k7QUFBSSwrQkFBUyxFQUFDLDZCQUFkO0FBQUEsNkNBQ0k7QUFBSyxpQ0FBUyxFQUFDLG1CQUFmO0FBQUEsZ0RBQ0k7QUFBSyxtQ0FBUyxFQUFDLHlCQUFmO0FBQUEsaURBQ0k7QUFBSyxpQ0FBSyxFQUFDLDRCQUFYO0FBQXdDLGdDQUFJLEVBQUMsTUFBN0M7QUFBb0QsbUNBQU8sRUFBQyxXQUE1RDtBQUF3RSxrQ0FBTSxFQUFDLE9BQS9FO0FBQUEsbURBQ0k7QUFBTSwyQ0FBYSxFQUFDLE9BQXBCO0FBQTRCLDRDQUFjLEVBQUMsT0FBM0M7QUFBbUQseUNBQVcsRUFBQyxHQUEvRDtBQUFtRSwrQkFBQyxFQUFDO0FBQXJFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQ0FESixlQU1JO0FBQUssbUNBQVMsRUFBQyxNQUFmO0FBQUEsb0NBQXVCQSxHQUFHLENBQUNSO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0NBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFESixlQVdJO0FBQUksK0JBQVMsRUFBQywwQ0FBZDtBQUFBLGdDQUEwRFEsR0FBRyxDQUFDUDtBQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVhKLGVBWUk7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsNkNBQXlEO0FBQUcsNEJBQUksRUFBQyxHQUFSO0FBQVksK0JBQU8sRUFBRSxNQUFNO0FBQ2hGeEMsMEJBQUFBLGFBQWEsQ0FBQytDLEdBQUQsQ0FBYjtBQUNBM0QsMEJBQUFBLG9CQUFvQixDQUFDLElBQUQsQ0FBcEI7QUFDSCx5QkFId0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFaSixlQWdCSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSxnQ0FBMEQyRCxHQUFHLENBQUNSLFFBQUosSUFBZ0JqRSxJQUFJLENBQUNpRSxRQUFyQixHQUFnQyxJQUFoQyxnQkFBdUM7QUFBQSwrQ0FBRTtBQUFHLDhCQUFJLEVBQUMsR0FBUjtBQUFZLGlDQUFPLEVBQUUsTUFBTUssVUFBVSxDQUFDRyxHQUFHLENBQUNoQixFQUFMLENBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUY7QUFBakc7QUFBQTtBQUFBO0FBQUE7QUFBQSw0QkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosaUNBREo7QUFIUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQVpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFESixlQWtFSTtBQUFLLG1CQUFTLEVBQUMsV0FBZjtBQUFBLGtDQUNJO0FBQUsscUJBQVMsRUFBQyxLQUFmO0FBQUEsbUNBQ0k7QUFBUSxxQkFBTyxFQUNYLE1BQU07QUFDRjdCLGdCQUFBQSxjQUFjLENBQUM7QUFDWDBCLGtCQUFBQSxRQUFRLEVBQUUsRUFEQztBQUVYRixrQkFBQUEsSUFBSSxFQUFFLEVBRks7QUFHWEssa0JBQUFBLEVBQUUsRUFBRTtBQUhPLGlCQUFELENBQWQ7QUFLQWpDLGdCQUFBQSxRQUFRLENBQUMsSUFBRCxDQUFSO0FBQ0FkLGdCQUFBQSxvQkFBb0IsQ0FBQyxJQUFELENBQXBCO0FBQ0gsZUFUTDtBQVVFLHVCQUFTLEVBQUMsd0RBVlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGtCQURKLGVBY0k7QUFBSyxxQkFBUyxFQUFDLHNDQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDhDQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQURKLGVBRUk7QUFBTyx1QkFBUyxFQUFDLHFDQUFqQjtBQUFBLHNDQUNJO0FBQU8seUJBQVMsRUFBQyxZQUFqQjtBQUFBLHVDQUNJO0FBQUEsMENBQ0k7QUFBSSx5QkFBSyxFQUFDLEtBQVY7QUFBZ0IsNkJBQVMsRUFBQyxnRkFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFJSTtBQUFJLHlCQUFLLEVBQUMsS0FBVjtBQUFnQiw2QkFBUyxFQUFDLGdGQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFKSixlQU9JO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFQSixlQVVJO0FBQUkseUJBQUssRUFBQyxLQUFWO0FBQWdCLDZCQUFTLEVBQUM7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHNCQURKLGVBaUJJO0FBQU8seUJBQVMsRUFBQyxtQ0FBakI7QUFBQSwwQkFHUVcsU0FBUyxDQUFDbUQsR0FBVixDQUFlRSxHQUFELGlCQUNWO0FBQUEseUNBQ0k7QUFBQSw0Q0FDSTtBQUFJLCtCQUFTLEVBQUMsNkJBQWQ7QUFBQSxnQ0FBNkNBLEdBQUcsQ0FBQ3RCO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREosZUFFSTtBQUFJLCtCQUFTLEVBQUMsMENBQWQ7QUFBQSxnQ0FBMERzQixHQUFHLENBQUNwQjtBQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUZKLGVBR0k7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsNkNBQXlEO0FBQUcsNEJBQUksRUFBQyxHQUFSO0FBQVksK0JBQU8sRUFBRSxNQUFNO0FBQ2hGMUIsMEJBQUFBLGNBQWMsQ0FBQzhDLEdBQUQsQ0FBZDtBQUNBbEQsMEJBQUFBLFFBQVEsQ0FBQyxRQUFRa0QsR0FBRyxDQUFDcEIsUUFBYixDQUFSO0FBQ0F0QywwQkFBQUEscUJBQXFCLENBQUMsSUFBRCxDQUFyQjtBQUNILHlCQUp3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQUhKLGVBU0k7QUFBSSwrQkFBUyxFQUFDLDBDQUFkO0FBQUEsNkNBQXlEO0FBQUcsNEJBQUksRUFBQyxHQUFSO0FBQVksK0JBQU8sRUFBRSxNQUFNMEMsV0FBVyxDQUFDZ0IsR0FBRyxDQUFDakIsRUFBTCxDQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLDRCQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlDQURKO0FBSFI7QUFBQTtBQUFBO0FBQUE7QUFBQSxzQkFqQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBbEVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQUpKLEVBZ0pLbEQsZ0JBQWdCLElBQUlNLGlCQUFwQixnQkFDRztBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyx1SEFBZjtBQUFBLCtCQUNJO0FBQUssbUJBQVMsRUFBQyx3Q0FBZjtBQUFBLGlDQUNJO0FBQUsscUJBQVMsRUFBQyxzR0FBZjtBQUFBLG9DQUNJO0FBQUssdUJBQVMsRUFBQywwRkFBZjtBQUFBLHFDQUNJO0FBQU0seUJBQVMsRUFBQyxlQUFoQjtBQUFBLDJCQUNLTixnQkFBZ0IsR0FBRyxjQUFILEdBQW9CLElBRHpDLEVBRUtNLGlCQUFpQixHQUFHLGdCQUFILEdBQXNCLElBRjVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBREosZUFPSTtBQUFLLHVCQUFTLEVBQUMsd0JBQWY7QUFBQSxxQ0FDSTtBQUFNLHdCQUFRLEVBQUVOLGdCQUFnQixHQUFHeUQsVUFBSCxHQUFnQkosUUFBaEQ7QUFBQSwyQkFDSzNDLFFBQVEsZ0JBQ0w7QUFBSywyQkFBUyxFQUFDLHFHQUFmO0FBQXFILHNCQUFJLEVBQUMsT0FBMUg7QUFBQSwwQ0FDSTtBQUFRLDZCQUFTLEVBQUMsV0FBbEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFNLDZCQUFTLEVBQUMsaUJBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESyxHQUlJLElBTGpCLGVBTUk7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsVUFBZjtBQUEwQiw2QkFBUyxFQUFDLDBCQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxNQUFaO0FBQW1CLHNCQUFFLEVBQUMsVUFBdEI7QUFBaUMseUJBQUssRUFBRVEsVUFBVSxDQUFDd0MsUUFBbkQ7QUFBNkQsNEJBQVEsRUFBRXZDLGFBQXZFO0FBQ0ksNkJBQVMsRUFBQywwRUFEZDtBQUVJLCtCQUFXLEVBQUMsb0JBRmhCO0FBRWtDLDRCQUFRLEVBQUUsQ0FBQ2IsaUJBRjdDO0FBRWdFLDRCQUFRLEVBQUVBO0FBRjFFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQU5KLGVBWUk7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFPLDJCQUFPLEVBQUMsT0FBZjtBQUF1Qiw2QkFBUyxFQUFDLDBCQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFESixlQUVJO0FBQU8sd0JBQUksRUFBQyxPQUFaO0FBQW9CLHNCQUFFLEVBQUMsT0FBdkI7QUFBK0IseUJBQUssRUFBRVksVUFBVSxDQUFDeUMsS0FBakQ7QUFBd0QsNEJBQVEsRUFBRXhDLGFBQWxFO0FBQ0ksNkJBQVMsRUFBQywwRUFEZDtBQUVJLCtCQUFXLEVBQUMsUUFGaEI7QUFFeUIsNEJBQVEsRUFBRSxDQUFDYixpQkFGcEM7QUFFdUQsNEJBQVEsRUFBRUE7QUFGakU7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBWkosZUFtQkk7QUFBSywyQkFBUyxFQUFDLE1BQWY7QUFBQSwwQ0FDSTtBQUFLLDZCQUFTLEVBQUMsZUFBZjtBQUFBLDRDQUNJO0FBQUssK0JBQVMsRUFBQyxNQUFmO0FBQUEsOENBQ0k7QUFBTywrQkFBTyxFQUFDLFVBQWY7QUFBMEIsaUNBQVMsRUFBQywwQkFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsOEJBREosZUFFSTtBQUFPLDRCQUFJLEVBQUMsVUFBWjtBQUF1QiwwQkFBRSxFQUFDLFVBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsT0FGaEI7QUFFd0IsZ0NBQVE7QUFGaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBREosZUFPSTtBQUFLLCtCQUFTLEVBQUMsTUFBZjtBQUFBLDhDQUNJO0FBQU8sK0JBQU8sRUFBQyxnQkFBZjtBQUFnQyxpQ0FBUyxFQUFDLDBCQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFESixlQUVJO0FBQU8sNEJBQUksRUFBQyxVQUFaO0FBQXVCLDBCQUFFLEVBQUMsZ0JBQTFCO0FBQ0ksaUNBQVMsRUFBQywwRUFEZDtBQUVJLG1DQUFXLEVBQUMsZUFGaEI7QUFFZ0MsZ0NBQVE7QUFGeEM7QUFBQTtBQUFBO0FBQUE7QUFBQSw4QkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLEVBZUtGLGVBQWUsZ0JBQ1o7QUFBSyw2QkFBUyxFQUFDLG1CQUFmO0FBQUEsMkNBQ0k7QUFBRywwQkFBSSxFQUFDLEdBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURZLEdBR0gsSUFsQmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFuQkosZUF1Q0k7QUFBTyxzQkFBSSxFQUFDLFFBQVo7QUFBcUIsb0JBQUUsRUFBQyxjQUF4QjtBQUF1Qyx1QkFBSyxFQUFFYyxVQUFVLENBQUNnQztBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXZDSixlQXdDSTtBQUFLLDJCQUFTLEVBQUMsd0ZBQWY7QUFBQSwwQ0FDSTtBQUFRLDJCQUFPLEVBQUUsTUFBTTtBQUNuQmpELHNCQUFBQSxtQkFBbUIsQ0FBQyxLQUFELENBQW5CO0FBQ0FNLHNCQUFBQSxvQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0gscUJBSEQ7QUFHRyw2QkFBUyxFQUFDLDJEQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBS0k7QUFBUSx3QkFBSSxFQUFDLFFBQWI7QUFBc0IsNkJBQVMsRUFBQyx3REFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHdCQXhDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG9CQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBREosZUErREk7QUFBSyxpQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQS9ESjtBQUFBLG9CQURILEdBa0VHLElBbE5SLEVBcU5LTCxpQkFBaUIsSUFBSU0sa0JBQXJCLGdCQUNHO0FBQUEsOEJBQ0k7QUFBSyxpQkFBUyxFQUFDLHVIQUFmO0FBQUEsK0JBQ0k7QUFBSyxtQkFBUyxFQUFDLHdDQUFmO0FBQUEsaUNBQ0k7QUFBSyxxQkFBUyxFQUFDLHNHQUFmO0FBQUEsb0NBQ0k7QUFBSyx1QkFBUyxFQUFDLDBGQUFmO0FBQUEscUNBQ0k7QUFBTSx5QkFBUyxFQUFDLGVBQWhCO0FBQUEsMkJBQ0tOLGlCQUFpQixHQUFHLGVBQUgsR0FBcUIsSUFEM0MsRUFFS00sa0JBQWtCLEdBQUcsaUJBQUgsR0FBdUIsSUFGOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxvQkFESixlQU9JO0FBQUssdUJBQVMsRUFBQyx3QkFBZjtBQUFBLHFDQUNJO0FBQU0sd0JBQVEsRUFBRU4saUJBQWlCLEdBQUc4QyxXQUFILEdBQWlCWCxTQUFsRDtBQUFBLHdDQUNJO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLE1BQWY7QUFBc0IsNkJBQVMsRUFBQywwQkFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSTtBQUFPLHdCQUFJLEVBQUMsTUFBWjtBQUFtQixzQkFBRSxFQUFDLE1BQXRCO0FBQTZCLHlCQUFLLEVBQUVqQixXQUFXLENBQUN5QixJQUFoRDtBQUFzRCw0QkFBUSxFQUFFeEIsY0FBaEU7QUFDSSw2QkFBUyxFQUFDLDBFQURkO0FBRUksK0JBQVcsRUFBQyxNQUZoQjtBQUV1Qiw0QkFBUTtBQUYvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFESixlQU9JO0FBQUssMkJBQVMsRUFBQyxNQUFmO0FBQUEsMENBQ0k7QUFBTywyQkFBTyxFQUFDLE9BQWY7QUFBdUIsNkJBQVMsRUFBQywwQkFBakM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMEJBREosZUFFSSw4REFBQyx1RUFBRDtBQUFZLHNCQUFFLEVBQUMsT0FBZjtBQUF1Qiw2QkFBUyxFQUFDLDBFQUFqQztBQUNJLCtCQUFXLEVBQUMsVUFEaEI7QUFFSSx5QkFBSyxFQUFFTCxLQUZYO0FBR0ksMkJBQU8sRUFBQyxJQUhaO0FBSUksNEJBQVEsRUFBRUM7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFQSixlQWVJO0FBQU8sc0JBQUksRUFBQyxRQUFaO0FBQXFCLG9CQUFFLEVBQUMsZUFBeEI7QUFBd0MsdUJBQUssRUFBRUcsV0FBVyxDQUFDOEI7QUFBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx3QkFmSixlQWdCSTtBQUFLLDJCQUFTLEVBQUMsd0ZBQWY7QUFBQSwwQ0FDSTtBQUFRLDJCQUFPLEVBQUUsTUFBTTtBQUNuQi9DLHNCQUFBQSxvQkFBb0IsQ0FBQyxLQUFELENBQXBCO0FBQ0FNLHNCQUFBQSxxQkFBcUIsQ0FBQyxLQUFELENBQXJCO0FBQ0gscUJBSEQ7QUFHRyw2QkFBUyxFQUFDLDJEQUhiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDBCQURKLGVBS0k7QUFBUSw2QkFBUyxFQUFDLHdEQUFsQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwwQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsd0JBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQXVDSTtBQUFLLGlCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBdkNKO0FBQUEsb0JBREgsR0EwQ0csSUEvUFI7QUFBQSxrQkFESjtBQW1RSDtBQUdNLGVBQWUyRCxrQkFBZixDQUFrQ0MsR0FBbEMsRUFBdUNDLEdBQXZDLEVBQTRDO0FBQy9DLE1BQUksQ0FBQ0QsR0FBRyxDQUFDQyxHQUFKLENBQVFDLE9BQVIsQ0FBZ0I5RSxJQUFyQixFQUNJLE9BQU87QUFDSCtFLElBQUFBLFFBQVEsRUFBRTtBQUNOQyxNQUFBQSxTQUFTLEVBQUUsS0FETDtBQUVOQyxNQUFBQSxXQUFXLEVBQUU7QUFGUCxLQURQO0FBS0hDLElBQUFBLEtBQUssRUFBRTtBQUxKLEdBQVA7QUFPSixRQUFNaEYsS0FBSyxHQUFHZ0QsSUFBSSxDQUFDaUMsS0FBTCxDQUFXUCxHQUFHLENBQUNDLEdBQUosQ0FBUUMsT0FBUixDQUFnQjlFLElBQTNCLEVBQWlDRSxLQUEvQztBQUNBLFFBQU1tQyxNQUFNLEdBQUdhLElBQUksQ0FBQ2lDLEtBQUwsQ0FBV1AsR0FBRyxDQUFDQyxHQUFKLENBQVFDLE9BQVIsQ0FBZ0I5RSxJQUEzQixFQUFpQ3FDLE1BQWhEO0FBQ0EsUUFBTUssR0FBRyxHQUFHLE1BQU1OLEtBQUssQ0FDbkIsNkJBRG1CLEVBRW5CO0FBQ0lFLElBQUFBLE9BQU8sRUFBRTtBQUNMLHVCQUFpQixZQUFZcEM7QUFEeEIsS0FEYjtBQUlJcUMsSUFBQUEsTUFBTSxFQUFFO0FBSlosR0FGbUIsQ0FBdkI7O0FBVUEsTUFBSUcsR0FBRyxDQUFDQyxNQUFKLElBQWMsR0FBbEIsRUFBdUI7QUFDbkIsV0FBTztBQUNIb0MsTUFBQUEsUUFBUSxFQUFFO0FBQ05DLFFBQUFBLFNBQVMsRUFBRSxLQURMO0FBRU5DLFFBQUFBLFdBQVcsRUFBRTtBQUZQLE9BRFA7QUFLSEMsTUFBQUEsS0FBSyxFQUFFO0FBTEosS0FBUDtBQU9IOztBQUVELFFBQU0vQyxNQUFNLEdBQUcsTUFBTUMsS0FBSyxDQUN0QiwrREFBK0RDLE1BRHpDLEVBRXRCO0FBQ0lDLElBQUFBLE9BQU8sRUFBRTtBQUNMLHVCQUFpQixZQUFZcEM7QUFEeEIsS0FEYjtBQUlJcUMsSUFBQUEsTUFBTSxFQUFFO0FBSlosR0FGc0IsQ0FBMUI7QUFVQSxRQUFNeEMsS0FBSyxHQUFHLE1BQU0yQyxHQUFHLENBQUNGLElBQUosRUFBcEI7QUFDQSxRQUFNdkMsSUFBSSxHQUFHLE1BQU1rQyxNQUFNLENBQUNLLElBQVAsRUFBbkI7QUFDQSxRQUFNeEMsSUFBSSxHQUFHa0QsSUFBSSxDQUFDaUMsS0FBTCxDQUFXUCxHQUFHLENBQUNDLEdBQUosQ0FBUUMsT0FBUixDQUFnQjlFLElBQTNCLENBQWI7QUFDQStCLEVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZa0IsSUFBSSxDQUFDaUMsS0FBTCxDQUFXUCxHQUFHLENBQUNDLEdBQUosQ0FBUUMsT0FBUixDQUFnQjlFLElBQTNCLEVBQWlDRSxLQUE3QztBQUNBLFNBQU87QUFDSGdGLElBQUFBLEtBQUssRUFBRTtBQUNIbkYsTUFBQUEsS0FERztBQUVIQyxNQUFBQSxJQUZHO0FBR0hDLE1BQUFBLElBSEc7QUFJSEMsTUFBQUE7QUFKRztBQURKLEdBQVA7QUFTSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdGdCRDs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQTs7Ozs7Ozs7Ozs7QUNBQSIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzL2RhdGEuanMiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9oZWFkXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9yb3V0ZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWNvb2tpZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LXBob25lLW51bWJlci1pbnB1dC9pbnB1dFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgdXNlUm91dGVyIH0gZnJvbSAnbmV4dC9yb3V0ZXInXHJcbmltcG9ydCB7IHVzZUNvb2tpZXMgfSBmcm9tIFwicmVhY3QtY29va2llXCJcclxuaW1wb3J0IFBob25lSW5wdXQgZnJvbSAncmVhY3QtcGhvbmUtbnVtYmVyLWlucHV0L2lucHV0J1xyXG5pbXBvcnQgJ3JlYWN0LXBob25lLW51bWJlci1pbnB1dC9zdHlsZS5jc3MnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBEYXRhKHsgdXNlcnMsIHVzZXIsIHRlbHMsIHRva2VuIH0pIHtcclxuICAgIGNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXHJcblxyXG4gICAgY29uc3QgW2Nvb2tpZSwgc2V0Q29va2llLCByZW1vdmVDb29raWVdID0gdXNlQ29va2llcyhbXCJ1c2VyXCJdKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbE5ld1VzZXIsIHNldFNob3dNb2RhbE5ld1VzZXJdID0gdXNlU3RhdGUoZmFsc2UpXHJcbiAgICBjb25zdCBbc2hvd01vZGFsTmV3UGhvbmUsIHNldFNob3dNb2RhbE5ld1Bob25lXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW2ludmFsaWRQYXNzd29yZCwgc2V0SW52YWxpZFBhc3N3b3JkXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG4gICAgY29uc3QgW3Nob3dNb2RhbEVkaXRVc2VyLCBzZXRTaG93TW9kYWxFZGl0VXNlcl0gPSB1c2VTdGF0ZShmYWxzZSlcclxuICAgIGNvbnN0IFtzaG93TW9kYWxFZGl0UGhvbmUsIHNldFNob3dNb2RhbEVkaXRQaG9uZV0gPSB1c2VTdGF0ZShmYWxzZSlcclxuXHJcbiAgICBjb25zdCBbZXJyb1VzZXIsIHNldEVycm9Vc2VyXSA9IHVzZVN0YXRlKGZhbHNlKVxyXG5cclxuICAgIGNvbnN0IFtsb2NhbFVzZXJzLCBzZXRMb2NhbFVzZXJzXSA9IHVzZVN0YXRlKHVzZXJzKVxyXG4gICAgY29uc3QgW2xvY2FsVGVscywgc2V0TG9jYWxUZWxzXSA9IHVzZVN0YXRlKHRlbHMpXHJcbiAgICBjb25zdCBbcGhvbmUsIHNldFBob25lXSA9IHVzZVN0YXRlKClcclxuICAgIGNvbnN0IFt1c2VyVG9FZGl0LCBzZXRVc2VyVG9FZGl0XSA9IHVzZVN0YXRlKCk7XHJcbiAgICBjb25zdCBbcGhvbmVUb0VkaXQsIHNldFBob25lVG9FZGl0XSA9IHVzZVN0YXRlKCk7XHJcblxyXG4gICAgY29uc3Qgb25DbGlja1NhaXIgPSBhc3luYyBldmVudCA9PiB7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJTYWlyXCIpXHJcbiAgICAgICAgcmVtb3ZlQ29va2llKFwidXNlclwiKVxyXG4gICAgICAgIHJvdXRlci5wdXNoKCcvJylcclxuICAgIH1cclxuXHJcbiAgICBhc3luYyBmdW5jdGlvbiByZWxvYWRUZWxzKCkge1xyXG4gICAgICAgIGNvbnN0IHJlc1RlbCA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YT91c2Vyc19wZXJtaXNzaW9uc191c2VyLmlkPScgKyB1c2VyLnVzZXJpZCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIHNldExvY2FsVGVscyhhd2FpdCByZXNUZWwuanNvbigpKVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIHJlbG9hZFVzZXJzKCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzJyxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdHRVQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHNldExvY2FsVXNlcnMoYXdhaXQgcmVzLmpzb24oKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGVkaXRQaG9uZSA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlci1kYXRhLycgKyBldmVudC50YXJnZXQucGhvbmVJZEhpZGRlbi52YWx1ZSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIG5vbWU6IGV2ZW50LnRhcmdldC5uYW1lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbGVmb25lOiBldmVudC50YXJnZXQucGhvbmUudmFsdWUsXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQVVQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRQaG9uZShmYWxzZSlcclxuICAgICAgICAgICAgcmVsb2FkVGVscygpXHJcbiAgICAgICAgfVxyXG5cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhZGROZXdQaG9uZSA9IGFzeW5jIGV2ZW50ID0+IHtcclxuICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXHJcbiAgICAgICAgY29uc29sZS5sb2coZXZlbnQudGFyZ2V0LnBob25lKVxyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YScsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICBub21lOiBldmVudC50YXJnZXQubmFtZS52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICB0ZWxlZm9uZTogZXZlbnQudGFyZ2V0LnBob25lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVzZXJzX3Blcm1pc3Npb25zX3VzZXI6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaWQ6IHVzZXIudXNlcmlkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSksXHJcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcblxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKSB7XHJcbiAgICAgICAgICAgIHJlbG9hZFRlbHMoKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZShmYWxzZSlcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgYXN5bmMgZnVuY3Rpb24gZGVsZXRlUGhvbmUocGhvbmVJRCkge1xyXG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKFxyXG4gICAgICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YS8nICsgcGhvbmVJRCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJ1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVGVscygpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IGVkaXRVc2VyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlICE9PSBldmVudC50YXJnZXQucGFzc3dvcmRyZXBlYXQudmFsdWUpIHtcclxuICAgICAgICAgICAgc2V0SW52YWxpZFBhc3N3b3JkKHRydWUpXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2Vycy8nICsgZXZlbnQudGFyZ2V0LnVzZXJpZEhpZGRlbi52YWx1ZSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiBldmVudC50YXJnZXQucGFzc3dvcmQudmFsdWUsXHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBtZXRob2Q6ICdQVVQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgaWYgKHJlcy5zdGF0dXMgPT0gMjAwKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0VXNlcihmYWxzZSlcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBhZGROZXdVc2VyID0gYXN5bmMgZXZlbnQgPT4ge1xyXG4gICAgICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcclxuICAgICAgICBpZiAoZXZlbnQudGFyZ2V0LnBhc3N3b3JkLnZhbHVlICE9PSBldmVudC50YXJnZXQucGFzc3dvcmRyZXBlYXQudmFsdWUpIHtcclxuICAgICAgICAgICAgc2V0SW52YWxpZFBhc3N3b3JkKHRydWUpXHJcbiAgICAgICAgICAgIHJldHVyblxyXG4gICAgICAgIH1cclxuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAgICAgJ2h0dHA6Ly9sb2NhbGhvc3Q6MTMzNy91c2VycycsXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcclxuICAgICAgICAgICAgICAgICAgICB1c2VybmFtZTogZXZlbnQudGFyZ2V0LnVzZXJuYW1lLnZhbHVlLFxyXG4gICAgICAgICAgICAgICAgICAgIGVtYWlsOiBldmVudC50YXJnZXQuZW1haWwudmFsdWUsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IGV2ZW50LnRhcmdldC5wYXNzd29yZC52YWx1ZSxcclxuICAgICAgICAgICAgICAgICAgICBjb25maXJtZWQ6IHRydWUsXHJcbiAgICAgICAgICAgICAgICAgICAgYmxvY2tlZDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICAgICAgcm9sZTogeyBpZDogMSB9XHJcbiAgICAgICAgICAgICAgICB9KSxcclxuICAgICAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnUE9TVCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDEpIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKGZhbHNlKVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHNldEVycm9Vc2VyKHRydWUpXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIGFzeW5jIGZ1bmN0aW9uIGRlbGV0ZVVzZXIodXNlcklEKSB7XHJcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goXHJcbiAgICAgICAgICAgICdodHRwOi8vbG9jYWxob3N0OjEzMzcvdXNlcnMvJyArIHVzZXJJRCxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgbWV0aG9kOiAnREVMRVRFJ1xyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgIClcclxuICAgICAgICBpZiAocmVzLnN0YXR1cyA9PSAyMDApIHtcclxuICAgICAgICAgICAgcmVsb2FkVXNlcnMoKVxyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICBjb25zb2xlLmxvZyh1c2VycylcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICAgICAgICA8dGl0bGU+RGVzYWZpbyAtIEFyZWEgUmVzdHJpdGE8L3RpdGxlPlxyXG4gICAgICAgICAgICA8L0hlYWQ+XHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdiZy1ncmF5LTUwIG1pbi1oLXNjcmVlbic+XHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggYmctZ3JlZW4tNTAgc2hhZG93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWJldHdlZW4gdy1mdWxsIGZsZXgganVzdGZ5LWJldHdlZW4gcC0zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nc2VsZi1jZW50ZXIgdGV4dC1sZyc+QmVtIHZpbmRvLCA8c3BhbiBjbGFzc05hbWU9J2ZvbnQtYm9sZCc+e3VzZXIudXNlcm5hbWV9PC9zcGFuPiE8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja1NhaXJ9IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcGwtNCBwci01IHB5LTIgZm9udC1ib2xkIGZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGNsYXNzTmFtZT1cImgtNiB3LTYgbXItM1wiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cIndoaXRlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTcgMTZsNC00bTAgMGwtNC00bTQgNEg3bTYgNHYxYTMgMyAwIDAxLTMgM0g2YTMgMyAwIDAxLTMtM1Y3YTMgMyAwIDAxMy0zaDRhMyAzIDAgMDEzIDN2MVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3N2Zz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNhaXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgtZ3Jvd1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm0tNVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0VXNlclRvRWRpdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJuYW1lOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW1haWw6ICcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZDogJydcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldEVycm9Vc2VyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbE5ld1VzZXIodHJ1ZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLWdyZWVuLTUwMCB0ZXh0LXdoaXRlIHJvdW5kZWQtbGcgcHgtNSBweS0yIGZvbnQtYm9sZFwiPk5vdm8gVXN1w6FyaW88L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibS01IGJvcmRlciBib3JkZXItZ3JheS0yMDAgZmxleC1ncm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0ndGV4dC1jZW50ZXIgYm9yZGVyLWIgYm9yZGVyLWdyYXktMjAwIHRleHQtbGcnPlVzdcOhcmlvczwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRhYmxlIGNsYXNzTmFtZT1cIm1pbi13LWZ1bGwgZGl2aWRlLXkgZGl2aWRlLWdyYXktMjAwXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoZWFkIGNsYXNzTmFtZT1cImJnLWdyYXktNTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTm9tZSBkZSBVc3XDoXJpb1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInB4LTYgcHktMyB0ZXh0LWxlZnQgdGV4dC14cyBmb250LW1lZGl1bSB0ZXh0LWdyYXktNTAwIHVwcGVyY2FzZSB0cmFja2luZy13aWRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEUtbWFpbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0aCBzY29wZT1cImNvbFwiIGNsYXNzTmFtZT1cInJlbGF0aXZlIHB4LTYgcHktM1wiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGhlYWQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRib2R5IGNsYXNzTmFtZT1cImJnLXdoaXRlIGRpdmlkZS15IGRpdmlkZS1ncmF5LTIwMFwiPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9jYWxVc2Vycy5tYXAoKHVzcikgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1zaHJpbmstMCBoLTEwIHctMTBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzdmcgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIGZpbGw9XCJub25lXCIgdmlld0JveD1cIjAgMCAyNCAyNFwiIHN0cm9rZT1cImJsYWNrXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHBhdGggc3Ryb2tlTGluZWNhcD1cInJvdW5kXCIgc3Ryb2tlTGluZWpvaW49XCJyb3VuZFwiIHN0cm9rZVdpZHRoPVwiMlwiIGQ9XCJNMTYgN2E0IDQgMCAxMS04IDAgNCA0IDAgMDE4IDB6TTEyIDE0YTcgNyAwIDAwLTcgN2gxNGE3IDcgMCAwMC03LTd6XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3ZnPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtbC0zXCI+e3Vzci51c2VybmFtZX08L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicHgtNiBweS00IHdoaXRlc3BhY2Utbm93cmFwIGl0ZW1zLWNlbnRlclwiPnt1c3IuZW1haWx9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+PGEgaHJlZj0nIycgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFVzZXJUb0VkaXQodXNyKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRVc2VyKHRydWUpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5FZGl0YXI8L2E+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3Vzci51c2VybmFtZSA9PSB1c2VyLnVzZXJuYW1lID8gbnVsbCA6IDw+PGEgaHJlZj0nIycgb25DbGljaz17KCkgPT4gZGVsZXRlVXNlcih1c3IuaWQpfT5FeGNsdWlyPC9hPjwvPn08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcblxyXG5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZVRvRWRpdCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZWxlZm9uZTogJycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBub21lOiAnJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkOiAnJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRQaG9uZShudWxsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZSh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH0gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+Tm92byBUZWxlZm9uZTwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtLTUgYm9yZGVyIGJvcmRlci1ncmF5LTIwMCBmbGV4LWdyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd0ZXh0LWNlbnRlciBib3JkZXItYiBib3JkZXItZ3JheS0yMDAgdGV4dC1sZyc+VGVsZWZvbmVzPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGFibGUgY2xhc3NOYW1lPVwibWluLXctZnVsbCBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGhlYWQgY2xhc3NOYW1lPVwiYmctZ3JheS01MFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dHI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJweC02IHB5LTMgdGV4dC1sZWZ0IHRleHQteHMgZm9udC1tZWRpdW0gdGV4dC1ncmF5LTUwMCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBOb21lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicHgtNiBweS0zIHRleHQtbGVmdCB0ZXh0LXhzIGZvbnQtbWVkaXVtIHRleHQtZ3JheS01MDAgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgVGVsZWZvbmVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8dGggc2NvcGU9XCJjb2xcIiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBweC02IHB5LTNcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRoIHNjb3BlPVwiY29sXCIgY2xhc3NOYW1lPVwicmVsYXRpdmUgcHgtNiBweS0zXCI+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RoZWFkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0Ym9keSBjbGFzc05hbWU9XCJiZy13aGl0ZSBkaXZpZGUteSBkaXZpZGUtZ3JheS0yMDBcIj5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxvY2FsVGVscy5tYXAoKHRlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0cj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXBcIj57dGVsLm5vbWV9PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+e3RlbC50ZWxlZm9uZX08L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHRkIGNsYXNzTmFtZT1cInB4LTYgcHktNCB3aGl0ZXNwYWNlLW5vd3JhcCBpdGVtcy1jZW50ZXJcIj48YSBocmVmPScjJyBvbkNsaWNrPXsoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0UGhvbmVUb0VkaXQodGVsKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFBob25lKCcrNTUnICsgdGVsLnRlbGVmb25lKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFNob3dNb2RhbEVkaXRQaG9uZSh0cnVlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfT5FZGl0YXI8L2E+PC90ZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJweC02IHB5LTQgd2hpdGVzcGFjZS1ub3dyYXAgaXRlbXMtY2VudGVyXCI+PGEgaHJlZj0nIycgb25DbGljaz17KCkgPT4gZGVsZXRlUGhvbmUodGVsLmlkKX0+RXhjbHVpcjwvYT48L3RkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3RyPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3Rib2R5PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC90YWJsZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgICB7LyogTW9kYWwgTmV3VXNlciAqL31cclxuICAgICAgICAgICAge3Nob3dNb2RhbE5ld1VzZXIgfHwgc2hvd01vZGFsRWRpdFVzZXIgPyAoXHJcbiAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwianVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyIGZsZXggb3ZlcmZsb3cteC1oaWRkZW4gb3ZlcmZsb3cteS1hdXRvIGZpeGVkIGluc2V0LTAgei01MCBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgdy1hdXRvIG15LTIgbXgtYXV0byBtYXgtdy0zeGxcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYm9yZGVyLTAgcm91bmRlZC1sZyBzaGFkb3ctbGcgcmVsYXRpdmUgZmxleCBmbGV4LWNvbCB3LWZ1bGwgYmctd2hpdGUgb3V0bGluZS1ub25lIGZvY3VzOm91dGxpbmUtbm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1zdGFydCBqdXN0aWZ5LWJldHdlZW4gcC01IGJvcmRlci1iIGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtdFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LXNlbWlib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsTmV3VXNlciA/ICdOb3ZvIFVzdcOhcmlvJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsRWRpdFVzZXIgPyAnRWRpdGFyIFVzdcOhcmlvJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvc3Bhbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIHAtNiBmbGV4LWF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGZvcm0gb25TdWJtaXQ9e3Nob3dNb2RhbE5ld1VzZXIgPyBhZGROZXdVc2VyIDogZWRpdFVzZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2Vycm9Vc2VyID9cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXJlZC0xMDAgYm9yZGVyIGJvcmRlci1yZWQtNDAwIHRleHQtcmVkLTcwMCBweC00IHB5LTMgcm91bmRlZCByZWxhdGl2ZSBzcGFjZS14LTEgbWItNCB0ZXh0LWNlbnRlclwiIHJvbGU9XCJhbGVydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3Ryb25nIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPkVycm8hPC9zdHJvbmc+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImJsb2NrIHNtOmlubGluZVwiPk8gbm9tZSBkZSB1c3XDoXJpbyBqw6EgZXhpc3RlPC9zcGFuPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXJuYW1lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+Tm9tZSBkZSBVc3XDoXJpbzo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIGlkPVwidXNlcm5hbWVcIiB2YWx1ZT17dXNlclRvRWRpdC51c2VybmFtZX0gb25DaGFuZ2U9e3NldFVzZXJUb0VkaXR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiTm9tZSBkZSBVc3XDoXJpb1wiIHJlcXVpcmVkPXshc2hvd01vZGFsRWRpdFVzZXJ9IGRpc2FibGVkPXtzaG93TW9kYWxFZGl0VXNlcn0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi02XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJlbWFpbFwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPkUtbWFpbDo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBpZD1cImVtYWlsXCIgdmFsdWU9e3VzZXJUb0VkaXQuZW1haWx9IG9uQ2hhbmdlPXtzZXRVc2VyVG9FZGl0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIkUtbWFpbFwiIHJlcXVpcmVkPXshc2hvd01vZGFsRWRpdFVzZXJ9IGRpc2FibGVkPXtzaG93TW9kYWxFZGl0VXNlcn0gLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtYi02Jz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggZmxleC1yb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J21yLTInPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwYXNzd29yZFwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPlNlbmhhOjwvbGFiZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgaWQ9XCJwYXNzd29yZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIlNlbmhhXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdtbC0yJz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRyZXBlYXRcIiBjbGFzc05hbWU9XCJtYi0zIGJsb2NrIHRleHQtZ3JheS03MDBcIj5SZXBpdGEgYSBzZW5oYTo8L2xhYmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJwYXNzd29yZFwiIGlkPVwicGFzc3dvcmRyZXBlYXRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImJnLXdoaXRlIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTQwMCBwLTMgZm9jdXM6b3V0bGluZS1ub25lIHctZnVsbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJSZXBpdGEgYSBlbmhhXCIgcmVxdWlyZWQgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2ludmFsaWRQYXNzd29yZCA/XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtMSB0ZXh0LXJlZC00MDBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCI+QXMgc2VuaGFzIGRpZ2l0YWRhcyBzw6NvIGRpZmVyZW50ZXM8L2E+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PiA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpbnB1dCB0eXBlPSdoaWRkZW4nIGlkPSd1c2VyaWRIaWRkZW4nIHZhbHVlPXt1c2VyVG9FZGl0LmlkfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10IGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdVc2VyKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxFZGl0VXNlcihmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fSBjbGFzc05hbWU9XCJiZy1yZWQtNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgbXgtMiBmb250LWJvbGRcIj5GZWNoYXI8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIHR5cGU9J3N1Ym1pdCcgY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+U2FsdmFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3BhY2l0eS0yNSBmaXhlZCBpbnNldC0wIHotNDAgYmctYmxhY2tcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApIDogbnVsbH1cclxuXHJcbiAgICAgICAgICAgIHsvKiBNb2RhbCBOZXdQaG9uZSAqL31cclxuICAgICAgICAgICAge3Nob3dNb2RhbE5ld1Bob25lIHx8IHNob3dNb2RhbEVkaXRQaG9uZSA/IChcclxuICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXIgZmxleCBvdmVyZmxvdy14LWhpZGRlbiBvdmVyZmxvdy15LWF1dG8gZml4ZWQgaW5zZXQtMCB6LTUwIG91dGxpbmUtbm9uZSBmb2N1czpvdXRsaW5lLW5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSB3LWF1dG8gbXktMiBteC1hdXRvIG1heC13LTN4bFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJib3JkZXItMCByb3VuZGVkLWxnIHNoYWRvdy1sZyByZWxhdGl2ZSBmbGV4IGZsZXgtY29sIHctZnVsbCBiZy13aGl0ZSBvdXRsaW5lLW5vbmUgZm9jdXM6b3V0bGluZS1ub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLXN0YXJ0IGp1c3RpZnktYmV0d2VlbiBwLTUgYm9yZGVyLWIgYm9yZGVyLXNvbGlkIGJvcmRlci1ibHVlR3JheS0yMDAgcm91bmRlZC10XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtc2VtaWJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93TW9kYWxOZXdQaG9uZSA/ICdOb3ZvIFRlbGVmb25lJyA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7c2hvd01vZGFsRWRpdFBob25lID8gJ0VkaXRhciBUZWxlZm9uZScgOiBudWxsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBwLTYgZmxleC1hdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxmb3JtIG9uU3VibWl0PXtzaG93TW9kYWxOZXdQaG9uZSA/IGFkZE5ld1Bob25lIDogZWRpdFBob25lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwibmFtZVwiIGNsYXNzTmFtZT1cIm1iLTMgYmxvY2sgdGV4dC1ncmF5LTcwMFwiPk5vbWU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBpZD1cIm5hbWVcIiB2YWx1ZT17cGhvbmVUb0VkaXQubm9tZX0gb25DaGFuZ2U9e3NldFBob25lVG9FZGl0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJiZy13aGl0ZSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS00MDAgcC0zIGZvY3VzOm91dGxpbmUtbm9uZSB3LWZ1bGxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwbGFjZWhvbGRlcj1cIk5vbWVcIiByZXF1aXJlZCAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTZcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInBob25lXCIgY2xhc3NOYW1lPVwibWItMyBibG9jayB0ZXh0LWdyYXktNzAwXCI+VGVsZWZvbmU6PC9sYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UGhvbmVJbnB1dCBpZD1cInBob25lXCIgY2xhc3NOYW1lPVwiYmctd2hpdGUgcm91bmRlZC1tZCBib3JkZXIgYm9yZGVyLWdyYXktNDAwIHAtMyBmb2N1czpvdXRsaW5lLW5vbmUgdy1mdWxsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJUZWxlZm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXtwaG9uZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY291bnRyeT1cIkJSXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e3NldFBob25lfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aW5wdXQgdHlwZT0naGlkZGVuJyBpZD0ncGhvbmVJZEhpZGRlbicgdmFsdWU9e3Bob25lVG9FZGl0LmlkfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWVuZCBwdC02IGJvcmRlci10IGJvcmRlci1zb2xpZCBib3JkZXItYmx1ZUdyYXktMjAwIHJvdW5kZWQtYlwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRTaG93TW9kYWxOZXdQaG9uZShmYWxzZSlcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2V0U2hvd01vZGFsRWRpdFBob25lKGZhbHNlKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19IGNsYXNzTmFtZT1cImJnLXJlZC01MDAgdGV4dC13aGl0ZSByb3VuZGVkLWxnIHB4LTUgcHktMiBteC0yIGZvbnQtYm9sZFwiPkZlY2hhcjwvYnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYmctZ3JlZW4tNTAwIHRleHQtd2hpdGUgcm91bmRlZC1sZyBweC01IHB5LTIgZm9udC1ib2xkXCI+U2FsdmFyPC9idXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9mb3JtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwib3BhY2l0eS0yNSBmaXhlZCBpbnNldC0wIHotNDAgYmctYmxhY2tcIj48L2Rpdj5cclxuICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuXHJcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRTZXJ2ZXJTaWRlUHJvcHMoY3R4LCByZXEpIHtcclxuICAgIGlmICghY3R4LnJlcS5jb29raWVzLnVzZXIpXHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgcmVkaXJlY3Q6IHtcclxuICAgICAgICAgICAgICAgIHBlcm1hbmVudDogZmFsc2UsXHJcbiAgICAgICAgICAgICAgICBkZXN0aW5hdGlvbjogXCIvXCIsXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHByb3BzOiB7fSxcclxuICAgICAgICB9O1xyXG4gICAgY29uc3QgdG9rZW4gPSBKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS50b2tlblxyXG4gICAgY29uc3QgdXNlcmlkID0gSlNPTi5wYXJzZShjdHgucmVxLmNvb2tpZXMudXNlcikudXNlcmlkXHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXJzJyxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgICAgICdBdXRob3JpemF0aW9uJzogJ0JlYXJlciAnICsgdG9rZW5cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgbWV0aG9kOiAnR0VUJ1xyXG4gICAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBpZiAocmVzLnN0YXR1cyAhPSAyMDApIHtcclxuICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICByZWRpcmVjdDoge1xyXG4gICAgICAgICAgICAgICAgcGVybWFuZW50OiBmYWxzZSxcclxuICAgICAgICAgICAgICAgIGRlc3RpbmF0aW9uOiBcIi9sb2dpblwiLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBwcm9wczoge30sXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCByZXNUZWwgPSBhd2FpdCBmZXRjaChcclxuICAgICAgICAnaHR0cDovL2xvY2FsaG9zdDoxMzM3L3VzZXItZGF0YT91c2Vyc19wZXJtaXNzaW9uc191c2VyLmlkPScgKyB1c2VyaWQsXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6ICdCZWFyZXIgJyArIHRva2VuXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIG1ldGhvZDogJ0dFVCdcclxuICAgICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgY29uc3QgdXNlcnMgPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICBjb25zdCB0ZWxzID0gYXdhaXQgcmVzVGVsLmpzb24oKVxyXG4gICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UoY3R4LnJlcS5jb29raWVzLnVzZXIpXHJcbiAgICBjb25zb2xlLmxvZyhKU09OLnBhcnNlKGN0eC5yZXEuY29va2llcy51c2VyKS50b2tlbilcclxuICAgIHJldHVybiB7XHJcbiAgICAgICAgcHJvcHM6IHtcclxuICAgICAgICAgICAgdXNlcnMsXHJcbiAgICAgICAgICAgIHVzZXIsXHJcbiAgICAgICAgICAgIHRlbHMsXHJcbiAgICAgICAgICAgIHRva2VuXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICB9XHJcbn0iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2hlYWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9yb3V0ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QtY29va2llXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXBob25lLW51bWJlci1pbnB1dC9pbnB1dFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7Il0sIm5hbWVzIjpbIkhlYWQiLCJ1c2VTdGF0ZSIsInVzZVJvdXRlciIsInVzZUNvb2tpZXMiLCJQaG9uZUlucHV0IiwiRGF0YSIsInVzZXJzIiwidXNlciIsInRlbHMiLCJ0b2tlbiIsInJvdXRlciIsImNvb2tpZSIsInNldENvb2tpZSIsInJlbW92ZUNvb2tpZSIsInNob3dNb2RhbE5ld1VzZXIiLCJzZXRTaG93TW9kYWxOZXdVc2VyIiwic2hvd01vZGFsTmV3UGhvbmUiLCJzZXRTaG93TW9kYWxOZXdQaG9uZSIsImludmFsaWRQYXNzd29yZCIsInNldEludmFsaWRQYXNzd29yZCIsInNob3dNb2RhbEVkaXRVc2VyIiwic2V0U2hvd01vZGFsRWRpdFVzZXIiLCJzaG93TW9kYWxFZGl0UGhvbmUiLCJzZXRTaG93TW9kYWxFZGl0UGhvbmUiLCJlcnJvVXNlciIsInNldEVycm9Vc2VyIiwibG9jYWxVc2VycyIsInNldExvY2FsVXNlcnMiLCJsb2NhbFRlbHMiLCJzZXRMb2NhbFRlbHMiLCJwaG9uZSIsInNldFBob25lIiwidXNlclRvRWRpdCIsInNldFVzZXJUb0VkaXQiLCJwaG9uZVRvRWRpdCIsInNldFBob25lVG9FZGl0Iiwib25DbGlja1NhaXIiLCJldmVudCIsImNvbnNvbGUiLCJsb2ciLCJwdXNoIiwicmVsb2FkVGVscyIsInJlc1RlbCIsImZldGNoIiwidXNlcmlkIiwiaGVhZGVycyIsIm1ldGhvZCIsImpzb24iLCJyZWxvYWRVc2VycyIsInJlcyIsInN0YXR1cyIsImVkaXRQaG9uZSIsInByZXZlbnREZWZhdWx0IiwidGFyZ2V0IiwicGhvbmVJZEhpZGRlbiIsInZhbHVlIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJub21lIiwibmFtZSIsInRlbGVmb25lIiwiYWRkTmV3UGhvbmUiLCJ1c2Vyc19wZXJtaXNzaW9uc191c2VyIiwiaWQiLCJkZWxldGVQaG9uZSIsInBob25lSUQiLCJlZGl0VXNlciIsInBhc3N3b3JkIiwicGFzc3dvcmRyZXBlYXQiLCJ1c2VyaWRIaWRkZW4iLCJhZGROZXdVc2VyIiwidXNlcm5hbWUiLCJlbWFpbCIsImNvbmZpcm1lZCIsImJsb2NrZWQiLCJyb2xlIiwiZGVsZXRlVXNlciIsInVzZXJJRCIsIm1hcCIsInVzciIsInRlbCIsImdldFNlcnZlclNpZGVQcm9wcyIsImN0eCIsInJlcSIsImNvb2tpZXMiLCJyZWRpcmVjdCIsInBlcm1hbmVudCIsImRlc3RpbmF0aW9uIiwicHJvcHMiLCJwYXJzZSJdLCJzb3VyY2VSb290IjoiIn0=